"""
Run the Cooking Assistant with HTTPS (self-signed certificate)
This allows camera/microphone access from mobile devices and remote access
"""

from app import app, socketio
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

if __name__ == '__main__':
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    
    print("=" * 70)
    print("🍳 COOKING ASSISTANT - HTTPS MODE (REMOTE ACCESS)")
    print("=" * 70)
    print()
    print("⚠️  IMPORTANT: Using self-signed SSL certificate")
    print()
    print("📱 MOBILE/REMOTE ACCESS INSTRUCTIONS:")
    print("-" * 70)
    print()
    print("1️⃣  Find your server IP address:")
    print("   - Run: hostname -I  (Linux/Raspberry Pi)")
    print("   - Run: ipconfig     (Windows)")
    print()
    print("2️⃣  On your phone/tablet browser, go to:")
    print(f"   https://YOUR_IP_ADDRESS:{port}")
    print()
    print("3️⃣  You will see a security warning - THIS IS NORMAL")
    print()
    print("   📱 On Chrome/Android:")
    print("      - Click 'Advanced'")
    print("      - Click 'Proceed to YOUR_IP_ADDRESS (unsafe)'")
    print()
    print("   📱 On Safari/iOS:")
    print("      - Tap 'Show Details'")
    print("      - Tap 'visit this website'")
    print("      - Confirm 'Visit Website'")
    print()
    print("   💻 On Desktop Chrome:")
    print("      - Click 'Advanced'")
    print("      - Click 'Proceed to localhost (unsafe)'")
    print()
    print("4️⃣  Browser will now ask for Camera and Microphone permissions")
    print("   - Click 'Allow' for both")
    print()
    print("5️⃣  Start cooking with full camera and microphone access!")
    print()
    print("=" * 70)
    print("🔒 SSL Certificate: Self-signed (Development)")
    print(f"🌐 Server starting on: https://{host}:{port}")
    print("=" * 70)
    print()
    print("⚡ QUICK ACCESS URLs:")
    print(f"   - Same device:  https://localhost:{port}")
    print(f"   - Local network: https://YOUR_IP:{port}")
    print()
    print("🔧 For production, use a real SSL certificate (Let's Encrypt)")
    print("=" * 70)
    print()
    
    # Check if pyopenssl is installed
    try:
        import OpenSSL
        print("✅ PyOpenSSL found - Generating SSL certificate...")
        print()
    except ImportError:
        print("❌ ERROR: PyOpenSSL not installed")
        print()
        print("📦 Install it with:")
        print("   pip install pyopenssl")
        print()
        print("Or run:")
        print("   pip install -r requirements.txt")
        print()
        exit(1)
    
    # Run with ad-hoc SSL certificate
    try:
        socketio.run(
            app, 
            host=host, 
            port=port, 
            debug=False,  # Disable debug in HTTPS mode
            ssl_context='adhoc',  # Creates temporary self-signed certificate
            allow_unsafe_werkzeug=True
        )
    except Exception as e:
        print()
        print("❌ ERROR:", str(e))
        print()
        if "adhoc" in str(e).lower():
            print("💡 Try installing pyopenssl:")
            print("   pip install pyopenssl")
        print()