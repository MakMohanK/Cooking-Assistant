#!/bin/bash
# Quick start script for Linux/Raspberry Pi

echo "============================================================"
echo "🍳 Starting Cooking Assistant..."
echo "============================================================"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ ERROR: Virtual environment not found"
    echo "Please run setup.sh first"
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ ERROR: .env file not found"
    echo "Please add your OpenAI API key to .env file"
    exit 1
fi

# Check if API key is set
if grep -q "your_openai_api_key_here" .env; then
    echo "❌ ERROR: Please add your OpenAI API key to .env file"
    echo "Edit .env and replace 'your_openai_api_key_here' with your actual key"
    exit 1
fi

# Activate virtual environment
source venv/bin/activate

# Start the application
echo "Starting application..."
echo ""
python3 app.py
