# 🎤 Microphone Permission Fix Guide

## ❌ Error You're Experiencing

```
Failed to start recording. Please check microphone permissions.
```

---

## ✅ **SOLUTION - Step by Step**

### **Solution 1: Grant Browser Permissions (Most Common)**

#### **For Chrome/Edge:**

1. **Click the lock icon** (🔒) or camera icon in the address bar (left of URL)
2. **Find "Microphone"** in the dropdown
3. **Change to "Allow"**
4. **Click "Reload"** or refresh the page (F5)

**OR**

1. Click the **"..." menu** (top right)
2. Go to **Settings** → **Privacy and security** → **Site settings**
3. Scroll to **Microphone**
4. Find `http://localhost:5000` in the list
5. Click it and change to **"Allow"**
6. Refresh the page

#### **For Firefox:**

1. **Click the lock icon** in the address bar
2. Click **"Connection secure"**
3. Click **"More information"**
4. Go to **"Permissions"** tab
5. Find **"Use the Microphone"**
6. Uncheck **"Use default"**
7. Check **"Allow"**
8. Refresh the page

#### **For Safari:**

1. Go to **Safari** → **Settings for localhost**
2. Find **"Microphone"**
3. Change to **"Allow"**
4. Refresh the page

---

### **Solution 2: Check Windows Microphone Settings**

#### **Step 1: Enable Microphone in Windows**

1. Press **Win + I** to open Settings
2. Go to **Privacy & Security** → **Microphone**
3. Toggle **"Microphone access"** to **ON**
4. Toggle **"Let apps access your microphone"** to **ON**
5. Scroll down and enable for **Desktop apps**

#### **Step 2: Set Microphone as Default**

1. Right-click the **speaker icon** in taskbar
2. Click **"Sound settings"**
3. Scroll to **"Input"**
4. Select your **microphone** from dropdown
5. Click **"Test your microphone"** and speak
6. You should see the volume bar moving

#### **Step 3: Test Microphone**

1. Open **Sound settings** (as above)
2. Under **Input**, speak into microphone
3. Volume bar should move
4. If not, try selecting a different microphone device

---

### **Solution 3: Reset Browser Permissions**

#### **Chrome/Edge - Reset Site Permissions:**

1. Press **F12** to open Developer Tools
2. Go to **Application** tab (or **Storage** in Firefox)
3. Click **"Clear site data"** button
4. Refresh page (F5)
5. When prompted, click **"Allow"** for microphone

#### **Complete Browser Reset (Nuclear Option):**

**Chrome:**
```
chrome://settings/content/microphone
```
1. Remove `http://localhost:5000` if blocked
2. Restart browser

**Edge:**
```
edge://settings/content/microphone
```
1. Remove `http://localhost:5000` if blocked
2. Restart browser

---

### **Solution 4: Check for Conflicting Applications**

Some apps lock the microphone:

**Close these if running:**
- ❌ Zoom
- ❌ Microsoft Teams
- ❌ Skype
- ❌ Discord
- ❌ OBS Studio
- ❌ Any other recording software

**Check Task Manager:**
1. Press **Ctrl + Shift + Esc**
2. Look for apps using microphone
3. Close them
4. Try again

---

### **Solution 5: Update Browser**

Make sure you're using the latest version:

**Chrome:** `chrome://settings/help`  
**Edge:** `edge://settings/help`  
**Firefox:** `Help` → `About Firefox`

---

### **Solution 6: Try HTTPS (Local Certificate)**

Some browsers require HTTPS for microphone access.

#### **Quick Test with Different Port:**

Create `run_https.bat`:
```batch
@echo off
set FLASK_RUN_CERT=adhoc
python app.py
```

This enables HTTPS with a self-signed certificate.

Then access: `https://localhost:5000` (note the 's' in https)

**Browser will show security warning:**
- Click **"Advanced"**
- Click **"Proceed to localhost"**
- Grant microphone permission

---

### **Solution 7: Test Microphone with Browser**

#### **Test if microphone works in browser:**

**Chrome/Edge:**
1. Go to: `chrome://settings/content/microphone`
2. Click **"Check microphone"**
3. Speak and see if it detects

**Firefox:**
1. Go to: `about:preferences#privacy`
2. Scroll to **Permissions** → **Microphone**
3. Click **"Settings"**

**Online Test:**
1. Go to: https://webcammictest.com/check-mic.html
2. Click **"Allow"** when prompted
3. Speak and verify it works

If microphone works on other sites but not localhost, it's a permission issue.

---

## 🔧 **Modified Code for Better Error Handling**

I'll update the JavaScript to provide better feedback...

---

## 🎯 **Quick Troubleshooting Checklist**

Check each item:

- [ ] **Browser shows microphone permission prompt?**
  - If NO: Refresh page and try again
  - If YES: Click "Allow"

- [ ] **Microphone is plugged in and working?**
  - Test in Windows Sound settings
  - Speak and watch volume bar

- [ ] **Browser is up to date?**
  - Check for updates
  - Restart browser

- [ ] **Other apps using microphone?**
  - Close Zoom, Teams, Skype, etc.
  - Check Task Manager

- [ ] **Microphone enabled in Windows Privacy?**
  - Settings → Privacy → Microphone → ON

- [ ] **Using correct browser?**
  - Chrome, Edge, or Firefox recommended
  - Safari on Mac should work

- [ ] **Accessing via localhost?**
  - URL should be `http://localhost:5000`
  - Not IP address

---

## 🎤 **Testing Microphone in the App**

### **Step-by-Step Test:**

1. **Open the app:** `http://localhost:5000`

2. **Open Browser Console:**
   - Press **F12**
   - Go to **Console** tab

3. **Click "Start Continuous Conversation"**

4. **Watch for prompts:**
   - Browser should ask for microphone permission
   - Click **"Allow"**

5. **Check console for errors:**
   - Look for red error messages
   - Share them if you see any

6. **Try speaking:**
   - Say "Hello" or "Test"
   - Watch for visual feedback

---

## 🆘 **Still Not Working?**

### **Diagnostic Information Needed:**

1. **Which browser are you using?**
   - Chrome / Edge / Firefox / Safari / Other?

2. **Check browser console (F12):**
   - Any red error messages?
   - Copy and share them

3. **Test microphone elsewhere:**
   - Does it work in Zoom/Teams?
   - Does it work on webcammictest.com?

4. **Check microphone type:**
   - Built-in laptop microphone?
   - USB microphone?
   - Bluetooth headset?

5. **Operating System:**
   - Windows 10 / Windows 11?
   - Any antivirus software?

---

## 🔍 **Common Error Messages & Fixes**

### **"NotAllowedError: Permission denied"**
→ Click "Allow" when browser asks for permission

### **"NotFoundError: Requested device not found"**
→ No microphone detected, check if plugged in

### **"NotReadableError: Could not start audio source"**
→ Microphone in use by another app, close other apps

### **"SecurityError: Only secure origins are allowed"**
→ Use https:// instead of http:// (or use localhost)

---

## ✅ **Expected Behavior When Working**

When microphone permission is granted correctly:

1. ✅ Browser shows microphone icon in address bar
2. ✅ No error alert appears
3. ✅ Button changes to "Stop Listening" (red)
4. ✅ Status shows "🎤 Listening..."
5. ✅ When you speak, it transcribes and responds

---

## 📞 **Get Immediate Help**

If still not working, provide:

1. **Screenshot** of the browser permission prompt
2. **Screenshot** of browser console (F12)
3. **Browser name and version**
4. **Error message** (exact text)
5. **Microphone type** (built-in/USB/Bluetooth)

---

**Most Common Fix: Just click "Allow" when browser asks for microphone permission!** 🎤✅
