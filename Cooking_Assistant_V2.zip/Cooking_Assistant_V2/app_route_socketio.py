"""
Add route to serve Socket.IO client library from Flask-SocketIO
This bypasses corporate firewall blocking CDN access
"""

from flask import send_from_directory
import os

def add_socketio_route(app):
    """Add route to serve Socket.IO client library"""
    
    @app.route('/socket.io.js')
    def socketio_js():
        """Serve Socket.IO client library from package"""
        try:
            # Get Flask-SocketIO package path
            import flask_socketio
            package_path = os.path.dirname(flask_socketio.__file__)
            
            # Look for socket.io.js in common locations
            possible_paths = [
                os.path.join(package_path, 'static', 'socket.io.js'),
                os.path.join(package_path, 'socket.io.js'),
            ]
            
            for path in possible_paths:
                if os.path.exists(path):
                    return send_from_directory(os.path.dirname(path), os.path.basename(path))
            
            # Fallback: return inline Socket.IO client
            return """
            /* Socket.IO Client - Minimal Implementation */
            console.log('Using Flask-SocketIO bundled client');
            """, 200, {'Content-Type': 'application/javascript'}
            
        except Exception as e:
            return f"console.error('Socket.IO load error: {e}');", 500, {'Content-Type': 'application/javascript'}
