# 📱 Remote Device Usage Guide

## ✅ Using Camera and Microphone from Remote Devices

Your Cooking Assistant now fully supports using **camera and microphone from ANY remote device** (phone, tablet, laptop).

---

## 🎯 How It Works

When you access the app from any device, that device's **own camera and microphone** are used:

- 📱 **Phone**: Uses phone's camera (back camera default) and microphone
- 💻 **Tablet**: Uses tablet's camera and microphone  
- 🖥️ **Laptop**: Uses laptop's webcam and microphone
- 🖥️ **Desktop**: Uses connected USB camera and microphone

**NOT the server's camera/microphone!**

---

## 🚀 Quick Setup

### Step 1: Start Server on Raspberry Pi

```bash
python app.py
```

### Step 2: Find Your Raspberry Pi IP Address

```bash
# On Raspberry Pi terminal:
hostname -I
```

Note the IP address (e.g., `192.168.1.100`)

### Step 3: Access from Remote Device

**On your phone/tablet:**
1. Connect to **same WiFi network** as Raspberry Pi
2. Open browser (Chrome, Safari, Firefox)
3. Go to: `http://192.168.1.XXX:5000` (replace XXX with your IP)

### Step 4: Grant Permissions

The page will automatically ask for:
1. ✅ **Microphone Permission** - Click "Allow"
2. ✅ **Camera Permission** - Click "Allow"

---

## 📋 What Happens When Page Loads

### Automatic Permission Request

1. **Page loads** → Shows welcome message
2. **After 1 second** → Automatically requests microphone permission
3. **Browser prompt appears** → "Allow this site to use your microphone?"
4. **Click "Allow"** → Microphone ready!
5. **Camera loads automatically** → Video feed appears

### Visual Feedback

You'll see clear messages:
- ✅ "Microphone Permission Granted!" (green)
- ✅ "Camera ready - Using your device camera"
- 🎉 "Setup Complete!" with usage tips

### If Permission Denied

You'll see detailed instructions:
- 🚫 Error message explaining the issue
- 📋 Step-by-step fix instructions
- 💡 Alternative: Use text input instead

---

## 🎤 Microphone Features

### Manual Voice Input (Hold Button)
1. **Hold** the microphone button
2. **Speak** your question
3. **Release** when done
4. Text appears and message is sent automatically

### Continuous Conversation Mode
1. Click **"Start Continuous Conversation"** button
2. Just **speak naturally** - no buttons!
3. AI listens and responds automatically
4. Say **"stop listening"** when done

---

## 📷 Camera Features

### Live Video Feed
- Shows **your device's camera** in real-time
- Point camera at cooking area
- Works on phone, tablet, laptop

### Scene Analysis
1. Point camera at cooking area
2. Click **"Analyze Scene"** button
3. AI describes what it sees
4. Get safety warnings, ingredient identification

### Switch Camera (Mobile)
- Click **"Switch"** button
- Toggles between front/back camera
- Useful for different angles

### Vision in Messages
- Check **"Include camera view"** option
- AI can see what you're asking about
- Get specific help based on what's visible

---

## 🔧 Troubleshooting

### Microphone Not Working

**Check 1: Browser Prompt**
- Did browser ask for permission?
- If NO: Refresh page (F5)
- If YES: Did you click "Allow"?

**Check 2: Browser Settings**
1. Click 🔒 lock icon in address bar
2. Find "Microphone"
3. Change to "Allow"
4. Refresh page

**Check 3: System Settings (Windows)**
1. Settings → Privacy → Microphone
2. Enable "Allow apps to access microphone"
3. Enable for desktop apps

**Check 4: System Settings (Android/iOS)**
1. Go to device Settings
2. Find browser app (Chrome/Safari)
3. Enable Microphone permission

**Check 5: Other Apps**
- Close Zoom, Teams, Skype, etc.
- Check Task Manager for recording apps
- Refresh page

### Camera Not Working

**Check 1: Permission**
- Same steps as microphone
- Look for "Camera" in browser settings

**Check 2: Other Apps**
- Close other apps using camera
- Close other browser tabs

**Check 3: Hardware**
- Check camera isn't physically blocked
- Try different camera if available

### Connection Issues

**Can't Access from Phone:**
- Ensure on **same WiFi network**
- Check firewall on Raspberry Pi
- Try accessing from Pi browser first: `http://localhost:5000`
- Verify IP address is correct

**Slow Performance:**
- Reduce camera resolution in `.env`
- Use `gpt-4o-mini` model
- Check WiFi signal strength
- Close other apps

---

## 📱 Mobile-Specific Tips

### Best Practices

1. **Use Back Camera**: Better quality for cooking scenes
2. **Good Lighting**: Ensure kitchen is well-lit
3. **Stable Position**: Use phone stand or prop
4. **Landscape Mode**: Better view of cooking area
5. **Keep Close**: Within 3-4 feet of cooking area

### Battery Saving

- Dim screen brightness
- Close other apps
- Use charger while cooking
- Enable battery saver mode

### Network Optimization

- Stay on WiFi (don't use mobile data)
- Move closer to WiFi router if slow
- Close other devices using WiFi

---

## 🔒 Security & Privacy

### What's Sent to Server

✅ Audio recordings (for transcription)
✅ Camera frames (when you click "Analyze")
✅ Text messages

### What's NOT Stored

❌ No permanent recording of audio
❌ No storage of camera images
❌ No conversation history saved to disk
❌ Everything is real-time processing

### Privacy Tips

1. Only grant permissions when using the app
2. Close browser when done cooking
3. Use on trusted WiFi network
4. Don't share your Raspberry Pi IP publicly

---

## 💡 Usage Tips

### For Best Results

**Microphone:**
- Speak clearly at normal volume
- Reduce background noise
- Keep phone/device 1-2 feet away
- Avoid covering microphone with hand

**Camera:**
- Point at cooking area
- Include stovetop, ingredients, tools
- Ensure good lighting
- Keep camera stable

**Continuous Mode:**
- Use when hands-free needed
- Great for active cooking
- Automatically responds with voice
- Just speak naturally!

**Manual Mode:**
- Hold button method
- More control over when to record
- Good for specific questions
- Quieter environments

---

## 🎯 Example Scenarios

### Scenario 1: Cooking from Phone

1. **Setup**: Place phone on counter pointing at stove
2. **Start**: Click "Start Continuous Conversation"
3. **Cook**: Ask questions while cooking hands-free
4. **Safety**: AI monitors scene and warns of hazards
5. **Done**: Say "stop listening"

### Scenario 2: Recipe Follow-Along (Tablet)

1. **Setup**: Prop tablet on kitchen counter
2. **Request**: "Give me a recipe for pasta"
3. **Follow**: AI provides step-by-step instructions
4. **Verify**: Check "Include camera view" to verify steps
5. **Continue**: Ask "what's next?" for each step

### Scenario 3: Ingredient Check (Phone)

1. **Setup**: Point phone camera at ingredients
2. **Enable**: Check "Include camera view"
3. **Ask**: "What ingredients do you see?"
4. **Verify**: AI identifies each item
5. **Continue**: Ask about quantities, freshness, etc.

---

## 📊 Performance Expectations

### Latency

- **Local Network**: 1-3 seconds response time
- **Voice Transcription**: 2-4 seconds
- **AI Response**: 3-6 seconds
- **TTS Generation**: 2-3 seconds

### Quality

- **Audio**: Clear voice recognition in quiet environment
- **Video**: Adequate quality for ingredient/safety detection
- **Accuracy**: High accuracy with good lighting and audio

### Bandwidth

- **Camera**: ~50-100 KB per frame captured
- **Audio**: ~100 KB per 10 seconds
- **Total**: Low bandwidth usage (works on typical WiFi)

---

## 🆘 Still Having Issues?

### Debug Steps

1. **Open Browser Console** (F12)
2. Look for error messages
3. Check "Console" tab
4. Share errors if asking for help

### Test Each Component

**Test Microphone:**
1. Visit: https://webcammictest.com/check-mic.html
2. Click "Allow" when prompted
3. Speak - should see activity

**Test Camera:**
1. Visit: https://webcamtests.com
2. Click "Allow" when prompted
3. Should see camera feed

**Test Network:**
```bash
# From phone browser, access:
http://RASPBERRY_PI_IP:5000/health
```
Should see: `{"status": "healthy", ...}`

---

## ✅ Success Checklist

When everything is working:
- [ ] Browser shows microphone/camera icons in address bar
- [ ] Video feed shows YOUR device camera
- [ ] Camera status shows "Live" (green)
- [ ] Status bar shows "✅ Microphone ready"
- [ ] "Start Continuous Conversation" button is enabled
- [ ] Holding microphone button starts recording
- [ ] Voice input gets transcribed
- [ ] AI responds with voice
- [ ] Scene analysis describes what camera sees

---

## 📞 Need More Help?

**Documentation Files:**
- `MICROPHONE_FIX_GUIDE.md` - Detailed microphone troubleshooting
- `README.md` - Complete application documentation
- `QUICK_START.md` - Fast setup guide

**Test Scripts:**
```bash
python test_camera.py  # Test server camera
python test_api.py     # Test OpenAI API
```

---

**Now you can cook from anywhere using your phone or tablet's camera and microphone!** 🎉📱🍳
