# ⚙️ Configuration Guide - .env File

This guide explains all configuration options available in the `.env` file.

---

## 🔑 Required Configuration

### OpenAI API Key (REQUIRED)

```bash
OPENAI_API_KEY=sk-your-actual-api-key-here
```

**How to get your API key:**
1. Go to https://platform.openai.com/api-keys
2. Sign up or log in to your OpenAI account
3. Click "Create new secret key"
4. Copy the key and paste it in your `.env` file
5. **Important:** Keep this key secret and never share it

**Test your API key:**
```bash
python test_api.py
```

---

## 🎛️ Flask Configuration

### Server Settings

```bash
HOST=0.0.0.0          # Listen on all network interfaces
PORT=5000             # Port number (5000 is default)
FLASK_ENV=development # Environment: development or production
FLASK_DEBUG=True      # Enable debug mode (True/False)
```

**For production deployment:**
```bash
FLASK_ENV=production
FLASK_DEBUG=False
```

**To change port (if 5000 is in use):**
```bash
PORT=8080  # Or any other available port
```

---

## 🤖 AI Model Configuration

### Vision Model (Scene Analysis)

```bash
VISION_MODEL=gpt-4o
```

**Options:**
- `gpt-4o` - Best quality, higher cost (~$0.01 per image)
- `gpt-4o-mini` - Good quality, 10x cheaper (~$0.001 per image)

**Recommendation:** Start with `gpt-4o`, switch to `gpt-4o-mini` if costs are high

### Chat Model (Conversation)

```bash
CHAT_MODEL=gpt-4o
```

**Options:**
- `gpt-4o` - Best understanding, higher cost
- `gpt-4o-mini` - Good for most conversations, much cheaper
- `gpt-4-turbo` - Alternative high-quality model

**Cost comparison (per 1M tokens):**
- gpt-4o: $5 input / $15 output
- gpt-4o-mini: $0.15 input / $0.60 output

### Speech Models

```bash
STT_MODEL=whisper-1          # Speech-to-Text
TTS_MODEL=tts-1              # Text-to-Speech
TTS_VOICE=alloy              # TTS Voice
```

**TTS_MODEL options:**
- `tts-1` - Faster, lower latency (recommended)
- `tts-1-hd` - Higher quality, slightly slower

**TTS_VOICE options:**
- `alloy` - Neutral, clear (recommended for instructions)
- `echo` - Male voice, warm
- `fable` - British accent, expressive
- `onyx` - Deep male voice, authoritative
- `nova` - Female voice, friendly
- `shimmer` - Soft female voice, gentle

**Listen to voice samples:** https://platform.openai.com/docs/guides/text-to-speech

### AI Response Settings

```bash
MAX_TOKENS_VISION=500        # Max tokens for vision responses
MAX_TOKENS_CHAT=800          # Max tokens for chat responses
TEMPERATURE=0.7              # Creativity (0.0-1.0)
```

**MAX_TOKENS:**
- Higher = longer responses, more detail, higher cost
- Lower = shorter responses, less detail, lower cost
- Vision: 500 is good for scene descriptions
- Chat: 800 allows detailed cooking instructions

**TEMPERATURE:**
- `0.0` - More focused, deterministic, factual
- `0.5` - Balanced
- `0.7` - Default, good balance (recommended)
- `1.0` - More creative, varied responses

---

## 📷 Camera Configuration

```bash
CAMERA_INDEX=0               # Camera device index
CAMERA_WIDTH=640             # Frame width in pixels
CAMERA_HEIGHT=480            # Frame height in pixels
CAMERA_FPS=30                # Frames per second
```

### Camera Index

**If camera doesn't work, try different indices:**
```bash
CAMERA_INDEX=0  # Usually built-in webcam
CAMERA_INDEX=1  # Usually first USB camera
CAMERA_INDEX=2  # Second USB camera
```

**Find your camera:**
- Windows: Check Device Manager > Cameras
- Linux: `ls /dev/video*`
- macOS: System Preferences > Camera

### Resolution

**Common resolutions:**
```bash
# Low (better performance on Raspberry Pi)
CAMERA_WIDTH=320
CAMERA_HEIGHT=240

# Medium (recommended)
CAMERA_WIDTH=640
CAMERA_HEIGHT=480

# High (may be slow on Raspberry Pi)
CAMERA_WIDTH=1280
CAMERA_HEIGHT=720
```

**Performance tip:** Lower resolution = faster processing

### Frame Rate

```bash
CAMERA_FPS=15   # Lower, saves bandwidth
CAMERA_FPS=30   # Default, smooth
CAMERA_FPS=60   # High (may not be supported)
```

---

## 💬 Conversation Settings

```bash
CONVERSATION_HISTORY_LENGTH=10
```

**This controls:**
- How many past messages are sent to AI for context
- Memory of the conversation

**Trade-offs:**
- Higher = Better context, remembers more, higher API cost
- Lower = Less context, may lose track, lower API cost

**Recommendations:**
- `5` - Minimal context, cheapest
- `10` - Good balance (recommended)
- `20` - Maximum context, most expensive

---

## 🔐 Security Configuration

```bash
SECRET_KEY=cooking-assistant-secret-key-change-this-in-production
CORS_ORIGINS=*
```

### Secret Key

**For production, generate a random key:**
```bash
# On Linux/Mac:
openssl rand -hex 32

# On Windows (PowerShell):
[System.Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Maximum 256 }))
```

Then update `.env`:
```bash
SECRET_KEY=your-generated-random-key-here
```

### CORS Origins

**Development (allow all):**
```bash
CORS_ORIGINS=*
```

**Production (restrict to specific domains):**
```bash
CORS_ORIGINS=https://yourdomain.com,https://app.yourdomain.com
```

---

## 🐛 Debug & Logging

```bash
DEBUG_MODE=True                    # Enable debug output
LOG_LEVEL=INFO                     # Logging level
LOG_FILE=cooking_assistant.log     # Log file name
SAVE_DEBUG_FRAMES=False            # Save captured frames
DEBUG_FRAMES_DIR=debug_frames      # Where to save frames
```

### Debug Mode

**Enable for troubleshooting:**
```bash
DEBUG_MODE=True
```

**Disable in production:**
```bash
DEBUG_MODE=False
```

**What it does:**
- Prints detailed logs to console
- Shows API request/response info
- Displays error messages

### Save Debug Frames

**Enable to save captured images:**
```bash
SAVE_DEBUG_FRAMES=True
DEBUG_FRAMES_DIR=debug_frames
```

**Use cases:**
- Verify camera is capturing correctly
- Debug vision analysis issues
- Create test dataset

**Note:** Images will accumulate, delete periodically

### Log Level

```bash
LOG_LEVEL=DEBUG   # Most verbose
LOG_LEVEL=INFO    # Standard (recommended)
LOG_LEVEL=WARNING # Only warnings and errors
LOG_LEVEL=ERROR   # Only errors
```

---

## ⚡ Performance Optimization

### For Raspberry Pi (Limited Resources)

```bash
# Use smaller models
VISION_MODEL=gpt-4o-mini
CHAT_MODEL=gpt-4o-mini

# Lower camera resolution
CAMERA_WIDTH=320
CAMERA_HEIGHT=240
CAMERA_FPS=15

# Reduce conversation memory
CONVERSATION_HISTORY_LENGTH=5

# Shorter AI responses
MAX_TOKENS_VISION=300
MAX_TOKENS_CHAT=500

# Disable debug features
DEBUG_MODE=False
SAVE_DEBUG_FRAMES=False
```

### For Powerful Hardware (Better Experience)

```bash
# Use best models
VISION_MODEL=gpt-4o
CHAT_MODEL=gpt-4o

# Higher camera quality
CAMERA_WIDTH=1280
CAMERA_HEIGHT=720
CAMERA_FPS=30

# More conversation context
CONVERSATION_HISTORY_LENGTH=20

# Detailed AI responses
MAX_TOKENS_VISION=800
MAX_TOKENS_CHAT=1200
```

---

## 💰 Cost Optimization

### Minimize API Costs

```bash
# Use mini models (10x cheaper)
VISION_MODEL=gpt-4o-mini
CHAT_MODEL=gpt-4o-mini

# Shorter responses
MAX_TOKENS_VISION=300
MAX_TOKENS_CHAT=400

# Less context
CONVERSATION_HISTORY_LENGTH=5

# Faster TTS
TTS_MODEL=tts-1
```

**Estimated savings:**
- Regular: ~$0.30 per cooking session
- Optimized: ~$0.03 per cooking session
- **10x cost reduction!**

---

## 🧪 Testing Your Configuration

### Test Individual Components

**Test API connection:**
```bash
python test_api.py
```

**Test camera:**
```bash
python test_camera.py
```

**Test with different camera index:**
```bash
python test_camera.py 1
```

### Verify Configuration

**Check .env is loaded:**
```bash
python -c "from dotenv import load_dotenv; import os; load_dotenv(); print('API Key:', os.getenv('OPENAI_API_KEY')[:10] + '...')"
```

**Check camera settings:**
```bash
python -c "from dotenv import load_dotenv; import os; load_dotenv(); print(f'Camera: {os.getenv(\"CAMERA_INDEX\", 0)} at {os.getenv(\"CAMERA_WIDTH\", 640)}x{os.getenv(\"CAMERA_HEIGHT\", 480)}')"
```

---

## 📋 Configuration Templates

### Template: Development (Testing)

```bash
OPENAI_API_KEY=sk-your-key-here
FLASK_ENV=development
FLASK_DEBUG=True
VISION_MODEL=gpt-4o-mini
CHAT_MODEL=gpt-4o-mini
CAMERA_INDEX=0
CAMERA_WIDTH=640
CAMERA_HEIGHT=480
DEBUG_MODE=True
SAVE_DEBUG_FRAMES=True
```

### Template: Production (Raspberry Pi)

```bash
OPENAI_API_KEY=sk-your-key-here
FLASK_ENV=production
FLASK_DEBUG=False
VISION_MODEL=gpt-4o-mini
CHAT_MODEL=gpt-4o-mini
CAMERA_INDEX=0
CAMERA_WIDTH=320
CAMERA_HEIGHT=240
CAMERA_FPS=15
DEBUG_MODE=False
SAVE_DEBUG_FRAMES=False
CONVERSATION_HISTORY_LENGTH=5
MAX_TOKENS_VISION=400
MAX_TOKENS_CHAT=600
TTS_MODEL=tts-1
TTS_VOICE=alloy
```

### Template: High-Quality Experience

```bash
OPENAI_API_KEY=sk-your-key-here
FLASK_ENV=production
FLASK_DEBUG=False
VISION_MODEL=gpt-4o
CHAT_MODEL=gpt-4o
CAMERA_INDEX=0
CAMERA_WIDTH=1280
CAMERA_HEIGHT=720
CAMERA_FPS=30
CONVERSATION_HISTORY_LENGTH=15
MAX_TOKENS_VISION=800
MAX_TOKENS_CHAT=1200
TTS_MODEL=tts-1-hd
TTS_VOICE=nova
TEMPERATURE=0.7
```

---

## 🔄 Dynamic Configuration Changes

Most settings require restarting the application:

```bash
# Stop application (Ctrl+C)
# Edit .env file
# Restart application
python app.py
```

**Settings that DON'T require restart:**
- None - all settings are loaded at startup

**Best practice:** Test configuration changes in development before production

---

## ❓ Troubleshooting Configuration

### API Key Not Working

1. Check format: `OPENAI_API_KEY=sk-proj-...`
2. No spaces around `=`
3. No quotes needed
4. Run `python test_api.py`

### Camera Not Found

1. Try different `CAMERA_INDEX` values (0, 1, 2)
2. Check camera is connected
3. Run `python test_camera.py`

### Poor Performance

1. Lower `CAMERA_WIDTH` and `CAMERA_HEIGHT`
2. Reduce `CAMERA_FPS`
3. Use `gpt-4o-mini` models
4. Reduce `MAX_TOKENS_*` values

### High Costs

1. Switch to `gpt-4o-mini` models
2. Reduce `CONVERSATION_HISTORY_LENGTH`
3. Lower `MAX_TOKENS_*` values
4. Use `tts-1` instead of `tts-1-hd`

---

## 📞 Getting Help

If configuration issues persist:

1. Check all syntax in `.env` file
2. Run test scripts (`test_api.py`, `test_camera.py`)
3. Enable `DEBUG_MODE=True` to see detailed logs
4. Check README.md for common issues
5. Verify OpenAI API status: https://status.openai.com

---

**Configuration complete! Start your application:**

```bash
# Windows
start.bat

# Linux/Raspberry Pi
./start.sh
```
