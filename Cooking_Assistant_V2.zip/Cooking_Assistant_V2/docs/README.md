# 📚 Documentation Index

Welcome to the Cooking Assistant documentation!

---

## 🚀 Quick Start

**New Users - Start Here:**
1. [START_HERE.md](START_HERE.md) - Quick 3-step setup guide
2. [QUICK_START.md](QUICK_START.md) - Detailed setup instructions
3. [START_STREAMING_CONVERSATION.md](START_STREAMING_CONVERSATION.md) - Testing the conversation feature

---

## 📖 User Guides

### Conversation Features
- [STREAMING_CONVERSATION_GUIDE.md](STREAMING_CONVERSATION_GUIDE.md) - **Main guide for ChatGPT-style conversation**
- [CHATGPT_STYLE_CONVERSATION_GUIDE.md](CHATGPT_STYLE_CONVERSATION_GUIDE.md) - Natural voice interaction guide
- [CONTINUOUS_CONVERSATION_GUIDE.md](CONTINUOUS_CONVERSATION_GUIDE.md) - Hands-free operation guide

### Access & Deployment
- [REMOTE_ACCESS_HTTPS_GUIDE.md](REMOTE_ACCESS_HTTPS_GUIDE.md) - **Required for phone/tablet access**
- [REMOTE_DEVICE_GUIDE.md](REMOTE_DEVICE_GUIDE.md) - Using camera/microphone from mobile devices
- [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) - Production deployment on Raspberry Pi

---

## 🔧 Configuration

- [CONFIGURATION_GUIDE.md](CONFIGURATION_GUIDE.md) - All .env settings explained
- [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) - Technical architecture overview

---

## 🐛 Troubleshooting

- [MICROPHONE_FIX_GUIDE.md](MICROPHONE_FIX_GUIDE.md) - Microphone permission issues
- [SSL_FIX_GUIDE.md](SSL_FIX_GUIDE.md) - SSL certificate errors
- [HANDS_FREE_TESTING_GUIDE.md](HANDS_FREE_TESTING_GUIDE.md) - Testing voice features

---

## 🧪 Testing Tools

- [test_socketio.html](test_socketio.html) - Test WebSocket connection
- [fix_ssl.py](fix_ssl.py) - SSL diagnostic tool

---

## 📋 Recommended Reading Order

### For Setup:
1. START_HERE.md
2. QUICK_START.md
3. REMOTE_ACCESS_HTTPS_GUIDE.md (if using phone/tablet)

### For Usage:
1. STREAMING_CONVERSATION_GUIDE.md
2. CHATGPT_STYLE_CONVERSATION_GUIDE.md

### For Troubleshooting:
1. MICROPHONE_FIX_GUIDE.md
2. SSL_FIX_GUIDE.md
3. HANDS_FREE_TESTING_GUIDE.md

### For Advanced:
1. CONFIGURATION_GUIDE.md
2. DEPLOYMENT_GUIDE.md
3. PROJECT_STRUCTURE.md

---

**All documentation is now organized in this folder!** 📚
