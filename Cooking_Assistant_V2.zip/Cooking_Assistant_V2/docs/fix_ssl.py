"""
SSL Certificate Fix Script
Run this to diagnose and fix SSL certificate issues
"""

import ssl
import certifi
import sys
import os

print("=" * 60)
print("SSL Certificate Diagnostic Tool")
print("=" * 60)
print()

# Check Python version
print(f"Python Version: {sys.version}")
print()

# Check certifi
try:
    import certifi
    print(f"✅ certifi installed: {certifi.__version__}")
    print(f"   Certificate bundle location: {certifi.where()}")
except ImportError:
    print("❌ certifi not installed")
    print("   Run: pip install certifi")

print()

# Check SSL
print(f"✅ SSL Version: {ssl.OPENSSL_VERSION}")
print(f"   Default verify paths:")
print(f"   - {ssl.get_default_verify_paths()}")

print()
print("=" * 60)
print("Recommended Fixes:")
print("=" * 60)
print()
print("1. Install/Update certifi:")
print("   pip install --upgrade certifi")
print()
print("2. Install/Update CA certificates:")
print("   pip install --upgrade certifi urllib3 requests")
print()
print("3. Set SSL_CERT_FILE environment variable:")
print(f"   set SSL_CERT_FILE={certifi.where()}")
print()
