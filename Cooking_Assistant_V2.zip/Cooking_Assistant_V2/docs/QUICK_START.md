# 🚀 Quick Start Guide - Cooking Assistant

## For Raspberry Pi Users

### 1️⃣ Automatic Setup (Recommended)

```bash
# Make setup script executable
chmod +x setup.sh

# Run the setup script
./setup.sh
```

The script will automatically install all dependencies.

### 2️⃣ Configure API Key

```bash
# Edit the .env file
nano .env

# Add your OpenAI API key:
OPENAI_API_KEY=sk-your-actual-api-key-here

# Save and exit (Ctrl+X, then Y, then Enter)
```

**Get your API key**: https://platform.openai.com/api-keys

### 3️⃣ Start the Application

```bash
# Activate virtual environment
source venv/bin/activate

# Run the application
python3 app.py
```

### 4️⃣ Access the Application

Open your browser and go to:
- **On Raspberry Pi**: http://localhost:5000
- **From another device**: http://YOUR_PI_IP:5000

To find your Raspberry Pi IP:
```bash
hostname -I
```

---

## Manual Setup (If Automatic Setup Fails)

### Step 1: Install System Dependencies
```bash
sudo apt-get update
sudo apt-get install python3 python3-pip python3-venv -y
sudo apt-get install libopencv-dev python3-opencv -y
sudo apt-get install portaudio19-dev python3-pyaudio -y
```

### Step 2: Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Python Packages
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 4: Configure Environment
```bash
cp .env.example .env
nano .env  # Add your OpenAI API key
```

### Step 5: Run Application
```bash
python3 app.py
```

---

## 🎯 Using the Application

### Camera Setup
1. Position webcam to show cooking area (stovetop, countertop)
2. Ensure good lighting
3. Keep camera stable

### Voice Commands
1. Hold microphone button to speak
2. Say your command clearly
3. Release button when done
4. Wait for transcription and response

### Example Questions

**Recipe Help:**
- "How do I make scrambled eggs?"
- "What's a recipe for pasta?"
- "How do I boil rice?"

**Ingredient Identification:**
- Click "Ingredients" button
- "What ingredients do you see?"
- "How many eggs are there?"

**Safety Checks:**
- Click "Safety" button
- "Is it safe to reach for the pot?"
- "Are there any hot surfaces?"

**Cooking Progress:**
- "Are my eggs done?"
- "How does the pasta look?"
- "Is my food burning?"

---

## ⚡ Quick Commands

| Action | Method |
|--------|--------|
| Analyze scene | Click "Analyze Scene" button |
| Safety check | Click "Safety" button |
| Identify ingredients | Click "Ingredients" button |
| Get recipe | Click "Recipe" button |
| Voice input | Hold microphone button |
| Clear chat | Click "Clear" button |

---

## 🔧 Troubleshooting Quick Fixes

### Camera not working?
```bash
# Check camera
ls /dev/video*

# Try different camera index in app.py
# Change: cv2.VideoCapture(0)
# To: cv2.VideoCapture(1)
```

### Microphone not working?
```bash
# Test microphone
arecord -d 3 test.wav && aplay test.wav

# Adjust volume
alsamixer
```

### API not working?
- Check your API key in `.env`
- Verify internet connection
- Check OpenAI API status: https://status.openai.com

### Application won't start?
```bash
# Reinstall dependencies
source venv/bin/activate
pip install -r requirements.txt --force-reinstall
```

---

## 💡 Pro Tips

1. **Battery Backup**: Use a UPS for Raspberry Pi to prevent shutdown during cooking
2. **Remote Access**: Set up VNC to access from phone/tablet
3. **Voice-Only Mode**: Enable auto-speak and use keyboard shortcuts
4. **Better Microphone**: USB microphone provides better voice recognition
5. **Multiple Cameras**: Use different angles for better scene understanding

---

## 🆘 Need Help?

- Read full documentation: `README.md`
- Check API usage: https://platform.openai.com/usage
- Test components individually using the test scripts

---

## 🎓 Learning Resources

**For Caregivers/Family:**
- Position camera at good angle showing cooking area
- Ensure adequate lighting
- Test voice input clarity
- Practice safety checks together

**For Users:**
- Start with simple recipes
- Use safety checks frequently
- Ask for step-by-step guidance
- Don't hesitate to ask questions

---

**Ready to cook! 🍳**
