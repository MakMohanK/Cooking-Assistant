# 🚀 Deployment Guide - Cooking Assistant for Raspberry Pi

## ✅ Pre-Deployment Checklist

Before deploying, ensure you have:
- [ ] Raspberry Pi 4 (16GB RAM) with Raspberry Pi OS installed
- [ ] USB Webcam or Raspberry Pi Camera Module connected
- [ ] USB Microphone connected
- [ ] Internet connection active
- [ ] OpenAI API key ready
- [ ] Power supply and cooling for Raspberry Pi

---

## 📦 Step-by-Step Deployment on Raspberry Pi

### Step 1: Transfer Files to Raspberry Pi

**Option A: Using Git (Recommended)**
```bash
cd ~
git clone <your-repository-url> cooking-assistant
cd cooking-assistant
```

**Option B: Using SCP from your computer**
```bash
# On your computer (Windows PowerShell or Linux/Mac terminal)
scp -r cooking-assistant/ pi@<raspberry-pi-ip>:~/
```

**Option C: Using USB Drive**
1. Copy entire project folder to USB drive
2. Insert USB into Raspberry Pi
3. Copy to home directory:
```bash
cp -r /media/pi/USB/cooking-assistant ~/
cd ~/cooking-assistant
```

### Step 2: Run Automated Setup

```bash
# Make setup script executable
chmod +x setup.sh

# Run setup (will take 10-15 minutes)
sudo ./setup.sh
```

The setup script will:
- Update system packages
- Install Python and dependencies
- Install OpenCV and camera support
- Install audio libraries
- Create virtual environment
- Install Python packages
- Test camera and microphone

### Step 3: Configure API Key

```bash
# Copy environment template
cp .env.example .env

# Edit environment file
nano .env
```

Add your OpenAI API key:
```
OPENAI_API_KEY=sk-proj-your-actual-api-key-here
```

Save and exit: `Ctrl+X`, then `Y`, then `Enter`

### Step 4: Test Components

**Test Camera:**
```bash
source venv/bin/activate
python3 test_camera.py
```

Expected output:
```
✅ Camera opened successfully!
✅ Frame captured successfully!
✅ Test image saved as 'test_frame.jpg'
✅ Camera test PASSED!
```

**Test API:**
```bash
python3 test_api.py
```

Expected output:
```
✅ API Key found
✅ API Response: API test successful
✅ OpenAI API test PASSED!
```

### Step 5: Start Application

```bash
# Activate virtual environment
source venv/bin/activate

# Run application
python3 app.py
```

Expected output:
```
============================================================
🍳 COOKING ASSISTANT FOR VISUALLY IMPAIRED
============================================================
Starting Flask server...
Access the application at: http://localhost:5000
============================================================
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
 * Running on http://192.168.1.xxx:5000
```

### Step 6: Access Application

**On Raspberry Pi:**
Open Chromium browser and go to: `http://localhost:5000`

**From another device on same network:**
1. Find Raspberry Pi IP: `hostname -I`
2. On other device, open browser: `http://<raspberry-pi-ip>:5000`

---

## 🔄 Auto-Start on Boot (Optional but Recommended)

### Create Systemd Service

```bash
sudo nano /etc/systemd/system/cooking-assistant.service
```

Add this content (adjust paths if needed):
```ini
[Unit]
Description=Cooking Assistant for Visually Impaired
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/cooking-assistant
Environment="PATH=/home/pi/cooking-assistant/venv/bin"
Environment="PYTHONUNBUFFERED=1"
ExecStart=/home/pi/cooking-assistant/venv/bin/python3 /home/pi/cooking-assistant/app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Save and exit: `Ctrl+X`, then `Y`, then `Enter`

### Enable and Start Service

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable service (auto-start on boot)
sudo systemctl enable cooking-assistant

# Start service now
sudo systemctl start cooking-assistant

# Check status
sudo systemctl status cooking-assistant
```

### Service Management Commands

```bash
# Start service
sudo systemctl start cooking-assistant

# Stop service
sudo systemctl stop cooking-assistant

# Restart service
sudo systemctl restart cooking-assistant

# View logs
sudo journalctl -u cooking-assistant -f

# Disable auto-start
sudo systemctl disable cooking-assistant
```

---

## 🌐 Remote Access Setup

### Option 1: Port Forwarding (Access from anywhere)

1. Log into your router admin panel
2. Find "Port Forwarding" settings
3. Add new rule:
   - External Port: 5000
   - Internal IP: `<raspberry-pi-ip>`
   - Internal Port: 5000
   - Protocol: TCP
4. Access from internet: `http://<your-public-ip>:5000`

⚠️ **Security Warning**: Use HTTPS and authentication for internet access!

### Option 2: VNC for Full Desktop Access

```bash
# Enable VNC on Raspberry Pi
sudo raspi-config
# Navigate to: Interface Options > VNC > Enable

# Install VNC viewer on your computer/phone
# Connect to: <raspberry-pi-ip>:5900
```

### Option 3: SSH Tunnel (Secure)

```bash
# On your computer, create SSH tunnel
ssh -L 5000:localhost:5000 pi@<raspberry-pi-ip>

# Then access: http://localhost:5000 on your computer
```

---

## 🔧 Performance Optimization

### For Better Performance

**1. Reduce Camera Resolution**
Edit `app.py` line 24-26:
```python
self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 320)  # Lower resolution
self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
```

**2. Use Lighter AI Model**
Edit `services/ai_service.py` line 80:
```python
"model": "gpt-4o-mini",  # Faster and cheaper
```

**3. Increase Swap Space**
```bash
sudo dphys-swapfile swapoff
sudo nano /etc/dphys-swapfile
# Change: CONF_SWAPSIZE=2048
sudo dphys-swapfile setup
sudo dphys-swapfile swapon
```

**4. Overclock Raspberry Pi (Careful!)**
```bash
sudo raspi-config
# Performance Options > Overclock > Modest
```

### For Better Reliability

**1. Add Cooling**
- Install heatsinks on CPU
- Use cooling fan
- Keep Raspberry Pi in ventilated area

**2. Use Quality Power Supply**
- Official Raspberry Pi power supply (5V/3A)
- Or quality USB-C power supply

**3. Add UPS/Battery Backup**
- Prevents data corruption from power loss
- Allows safe shutdown

---

## 📊 Monitoring & Maintenance

### Check System Resources

```bash
# CPU and memory usage
htop

# Temperature
vcgencmd measure_temp

# Disk space
df -h

# Network connectivity
ping -c 4 google.com
```

### View Application Logs

```bash
# If running as service
sudo journalctl -u cooking-assistant -f

# If running manually
# Logs appear in terminal
```

### Update Application

```bash
cd ~/cooking-assistant
git pull  # If using git
source venv/bin/activate
pip install -r requirements.txt --upgrade
sudo systemctl restart cooking-assistant
```

---

## 🐛 Troubleshooting Production Issues

### Application Won't Start

```bash
# Check service status
sudo systemctl status cooking-assistant

# View detailed logs
sudo journalctl -u cooking-assistant -n 50

# Test manually
cd ~/cooking-assistant
source venv/bin/activate
python3 app.py
```

### Camera Not Working

```bash
# Check camera connection
vcgencmd get_camera

# Check video devices
ls -l /dev/video*

# Test camera
python3 test_camera.py
```

### High CPU Usage

- Reduce camera resolution
- Lower FPS in app.py
- Use gpt-4o-mini instead of gpt-4o
- Check for unnecessary background processes

### Out of Memory

```bash
# Check memory
free -h

# Increase swap space (see optimization section)
# Close other applications
# Restart Raspberry Pi
```

### API Errors

```bash
# Test API
python3 test_api.py

# Check API usage and billing
# Visit: https://platform.openai.com/usage

# Verify internet connection
ping -c 4 api.openai.com
```

---

## 💰 Cost Management

### Monitor API Usage

1. Visit https://platform.openai.com/usage
2. Set usage limits in OpenAI dashboard
3. Enable email notifications for usage thresholds

### Reduce Costs

- Use `gpt-4o-mini` instead of `gpt-4o` (10x cheaper)
- Disable auto-speak to reduce TTS calls
- Use text chat instead of vision when possible
- Cache common responses
- Set daily spending limits

### Estimated Monthly Costs

**Light usage** (1 hour/day):
- 30 cooking sessions
- ~300 API calls
- **~$8-15/month**

**Heavy usage** (3 hours/day):
- 90 cooking sessions
- ~900 API calls
- **~$25-45/month**

---

## 🔐 Security Best Practices

1. **Change Default Password**
```bash
passwd  # Change pi user password
```

2. **Update Regularly**
```bash
sudo apt-get update && sudo apt-get upgrade -y
```

3. **Firewall Setup**
```bash
sudo apt-get install ufw
sudo ufw allow 5000
sudo ufw enable
```

4. **Secure API Keys**
- Never commit .env to git
- Rotate API keys periodically
- Use environment variables only

5. **HTTPS Setup** (Advanced)
- Use nginx reverse proxy with Let's Encrypt
- Or use Cloudflare Tunnel

---

## 📱 Mobile Access

### Access from Phone/Tablet

1. Ensure phone/tablet on same WiFi network
2. Open browser on mobile device
3. Navigate to: `http://<raspberry-pi-ip>:5000`
4. Add to home screen for app-like experience

**iOS**: Safari > Share > Add to Home Screen
**Android**: Chrome > Menu > Add to Home Screen

---

## 🎓 Training Users

### For Caregivers/Family

1. Test all features together
2. Practice voice commands
3. Set up optimal camera position
4. Create emergency procedures
5. Keep Raspberry Pi accessible but safe

### For Visually Impaired Users

1. Learn keyboard shortcuts
2. Practice voice commands
3. Understand safety features
4. Start with simple recipes
5. Build confidence gradually

---

## 📞 Support & Resources

### Quick Reference Card

Print and keep near Raspberry Pi:

```
🍳 COOKING ASSISTANT QUICK REFERENCE

Start Application:
  cd ~/cooking-assistant
  source venv/bin/activate
  python3 app.py

Access: http://localhost:5000

Quick Actions:
  📖 Recipe - Get cooking instructions
  🥕 Ingredients - Identify items
  ⚠️ Safety - Check hazards
  ⏰ Timer - Timing help

Voice: Hold microphone button, speak, release

Emergency Stop:
  Ctrl+C (in terminal)
  OR: sudo systemctl stop cooking-assistant

Restart:
  sudo systemctl restart cooking-assistant

Support: [Your contact info]
```

---

## ✅ Post-Deployment Checklist

- [ ] Application starts successfully
- [ ] Camera feed visible
- [ ] Voice input working
- [ ] TTS audio playing
- [ ] Scene analysis working
- [ ] Chat responses received
- [ ] Auto-start configured
- [ ] Remote access tested
- [ ] Backup power in place
- [ ] Users trained
- [ ] Emergency procedures documented

---

**Deployment Complete! 🎉**

Your Cooking Assistant is now ready to help visually impaired individuals cook safely and confidently!
