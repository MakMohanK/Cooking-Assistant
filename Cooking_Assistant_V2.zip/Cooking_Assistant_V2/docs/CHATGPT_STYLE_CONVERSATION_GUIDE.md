# 🎙️ ChatGPT-Style Continuous Conversation Guide

## ✨ **What's New**

Your Cooking Assistant now works **exactly like ChatGPT's voice mode**:

✅ **Natural conversation flow** - Talk like you're talking to a real person  
✅ **Vision ALWAYS active** - AI can see your camera during the entire conversation  
✅ **Real voice responses** - Natural TTS that sounds human  
✅ **Completely hands-free** - No buttons to press while talking  
✅ **Automatic voice detection** - Knows when you start and stop speaking  

---

## 🚀 **How to Use**

### Step 1: Start the Server

**With HTTPS (for remote devices):**
```bash
python run_https.py
```

**Access from phone/tablet:**
```
https://YOUR_IP:5000
```

### Step 2: Allow Permissions

When page loads:
1. ✅ **Camera permission** - Click "Allow"
2. ✅ **Microphone permission** - Click "Allow"

### Step 3: Position Your Camera

Point your camera at:
- Cooking area (stovetop, countertop)
- Ingredients you're using
- Food you're cooking

**The AI will automatically see everything while you talk!**

### Step 4: Start Conversation

Click the big green button:
**"Start Conversation"**

You'll hear the AI say:
> "Hi! I'm your cooking assistant. I can see your camera and I'm listening. Just speak naturally - ask me anything about cooking!"

### Step 5: Talk Naturally!

Just speak like you're talking to ChatGPT:

**You:** "What ingredients do you see?"

**AI:** (Looks at camera) "I can see eggs, butter, a bowl, and a whisk on your counter..."

**You:** "How do I make scrambled eggs with those?"

**AI:** "Great! Here's how to make scrambled eggs. First, crack those eggs into the bowl..."

**You:** "How many eggs should I use?"

**AI:** "I see 4 eggs there. For one person, use 2-3 eggs. For two people, use all 4..."

---

## 🎯 **Key Features**

### 1. **Vision Always Active** 👁️

The AI can **always see** your camera during conversation:

- No need to check "Include camera view"
- Automatically analyzes what's in front of camera
- Gives context-aware responses based on what it sees

**Example:**
```
You: "Is the pan hot enough?"
AI: (Looking at camera) "I can see steam rising from the pan, 
     so yes, it's ready for the eggs!"
```

### 2. **Natural Voice Flow** 🗣️

Works exactly like ChatGPT voice mode:

- Speak naturally
- AI detects when you stop talking
- Responds automatically with voice
- Waits for your next question

**Example conversation:**
```
You: "What should I cook for dinner?"
AI: "Based on what I see, you have eggs and vegetables. 
     How about a veggie omelet?"
     
You: "That sounds good! How do I start?"
AI: "Great choice! First, let's prep the vegetables..."
```

### 3. **Automatic Voice Detection** 🎤

The system automatically:
- Detects when you start speaking
- Records your voice
- Stops recording after 1.8 seconds of silence
- Sends to AI for processing
- Plays response with voice

**No buttons to press - it just works!**

### 4. **Context Awareness** 🧠

The AI remembers the conversation:

```
You: "How do I make pasta?"
AI: "I'll guide you through making pasta..."

You: "What's the next step?"
AI: "Now that the water is boiling, add the pasta..."

You: "How long should I cook it?"
AI: "For the type of pasta I see, cook for 8-10 minutes..."
```

---

## 💡 **Example Conversations**

### Scenario 1: Recipe Guidance with Vision

```
👤 You: "I want to cook something, what do you see?"

🤖 AI: "I can see eggs, milk, cheese, and bread on your 
       counter. How about making a cheese omelet or 
       French toast?"

👤 You: "Let's make an omelet. What do I do first?"

🤖 AI: "Great! I see you have everything. First, crack 
       2-3 eggs into that bowl I see..."

👤 You: "Done. What's next?"

🤖 AI: "Now add a splash of milk - about 2 tablespoons..."
```

### Scenario 2: Safety Check with Vision

```
👤 You: "Is it safe to reach for the pot?"

🤖 AI: "Let me check... I can see the stove burner is on 
       and there's steam coming from the pot. The handle 
       is pointing toward you, so yes, you can safely 
       grab it from the left side. Use a pot holder!"

👤 You: "Can I touch the pan next to it?"

🤖 AI: "No, wait! That pan is on a hot burner. I can see 
       it's very close to the lit burner. Don't touch it 
       without a pot holder."
```

### Scenario 3: Cooking Progress with Vision

```
👤 You: "Are my eggs done cooking?"

🤖 AI: "Looking at your pan... The eggs look fluffy and 
       golden yellow with no liquid remaining. Yes, 
       they're perfectly done! Turn off the heat now."

👤 You: "Should I add anything?"

🤖 AI: "I see salt and pepper nearby. A pinch of each 
       would be perfect. The eggs look great as they are!"
```

### Scenario 4: Ingredient Substitution

```
👤 You: "I don't have butter, what can I use?"

🤖 AI: "Looking at your counter, I can see olive oil. 
       That works perfectly! Use about 1 tablespoon 
       instead of the butter."

👤 You: "Will it taste different?"

🤖 AI: "It will have a slightly different flavor - 
       more savory. But it's actually healthier and 
       works great for cooking eggs!"
```

---

## 🎛️ **How It Works (Technical)**

### Voice Activity Detection (VAD)

1. **Continuously monitors** microphone input
2. **Detects speech** when volume exceeds threshold
3. **Starts recording** automatically
4. **Detects silence** (1.8 seconds of quiet)
5. **Stops recording** and processes

### Vision Integration

1. **Captures camera frame** every time you speak
2. **Sends to GPT-4 Vision** along with your audio
3. **AI analyzes** both what you said AND what it sees
4. **Responds** based on visual context

### Natural Flow

```
[You speak] 
  ↓
[Voice detected - Recording starts]
  ↓
[1.8s silence - Recording stops]
  ↓
[Audio + Camera frame sent to AI]
  ↓
[AI processes with vision context]
  ↓
[Response generated]
  ↓
[TTS converts to speech]
  ↓
[You hear response]
  ↓
[System ready - listening for next question]
```

---

## 🔧 **Troubleshooting**

### Issue: AI doesn't respond

**Check:**
1. Console (F12) - Look for errors
2. Status shows "🎤 Listening continuously with vision..."
3. Microphone volume is adequate
4. OpenAI API key is set in `.env`

**Test:**
```javascript
// In browser console:
console.log('Conversation active:', window.chatGPTConversation.isActive());
```

### Issue: AI can't see camera

**Check:**
1. Camera permission granted?
2. Camera feed showing on page?
3. Console shows: "📷 Camera frame captured"

**Test:**
```javascript
// In browser console:
console.log('Camera active:', window.cameraCapture.isActive());
window.cameraCapture.captureFrame(); // Should return base64 string
```

### Issue: Voice not detected

**Adjust sensitivity** in `chatgpt-style-conversation.js`:

```javascript
const VAD_CONFIG = {
    volumeThreshold: 0.020,  // Lower = more sensitive (try 0.015)
    silenceDuration: 1800,   // Longer = more patient (try 2500)
    minRecordingTime: 600,   // Minimum recording time
};
```

### Issue: Responses too slow

**Optimize:**
1. Use `gpt-4o-mini` instead of `gpt-4o` (10x faster)
2. Reduce camera resolution
3. Check internet speed

**Edit `.env`:**
```bash
VISION_MODEL=gpt-4o-mini
CHAT_MODEL=gpt-4o-mini
```

---

## 📊 **Performance Expectations**

**Typical Response Times:**

- Voice detection: < 100ms
- Recording: 1-5 seconds (depends on speech)
- Audio upload: 1-2 seconds
- Transcription: 2-3 seconds
- Vision analysis: 3-5 seconds
- AI response: 4-6 seconds
- TTS generation: 2-3 seconds

**Total: 12-20 seconds** per interaction

**This feels natural because:**
- Voice starts immediately after you stop talking
- Visual status shows what's happening
- Natural pause mimics real conversation

---

## 💰 **Cost Per Conversation**

**Typical 30-minute cooking session:**

- 20 voice inputs: $0.10 (Whisper STT)
- 20 vision analyses: $0.20 (GPT-4 Vision - always on)
- 20 AI responses: $0.15 (GPT-4)
- 20 voice outputs: $0.10 (TTS)

**Total: ~$0.55 per 30-minute session**

**Cost reduction:**
- Use `gpt-4o-mini`: ~$0.12 per session (78% savings!)

---

## ✅ **Success Checklist**

When everything is working:

- [ ] Click "Start Conversation" - button turns red
- [ ] Status shows "🎤 Listening continuously with vision..."
- [ ] Speak: "Hello" - Console shows "🎤 Voice detected!"
- [ ] After 1.8s silence - Recording stops automatically
- [ ] Console shows "📷 Camera frame captured"
- [ ] Your transcribed text appears in chat
- [ ] AI analyzes and responds based on camera view
- [ ] AI response is spoken with natural voice
- [ ] Status returns to "🎤 Listening..."
- [ ] Can immediately speak again - cycle repeats

---

## 🎉 **It's That Simple!**

Just click "Start Conversation" and talk naturally!

**The AI will:**
- ✅ Hear everything you say
- ✅ See everything in your camera
- ✅ Respond with natural voice
- ✅ Remember the conversation context
- ✅ Help you cook safely and successfully

**Exactly like talking to ChatGPT with vision! 🎙️👁️**

---

## 🆘 **Need Help?**

1. **Check browser console** (F12) for detailed logs
2. **Review server terminal** for processing info
3. **Test components:**
   ```javascript
   // Test conversation system
   window.chatGPTConversation.toggle();
   
   // Test camera
   window.cameraCapture.captureFrame();
   
   // Test WebSocket
   console.log('Socket connected:', socket.connected);
   ```

---

**Enjoy cooking with your AI assistant! It's like having a professional chef watching and guiding you through voice! 🍳👨‍🍳**
