"""
Streaming Service for Real-Time AI Responses
Enables ChatGPT-style streaming with immediate TTS
"""

import os
import requests
import json
from typing import Generator

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

def stream_chat_response(messages: list, image_base64: str = None) -> Generator[str, None, None]:
    """
    Stream AI response word by word for natural conversation
    
    Args:
        messages: Conversation history
        image_base64: Optional image for vision
        
    Yields:
        Text chunks as they're generated
    """
    if not OPENAI_API_KEY:
        yield "Please set OPENAI_API_KEY environment variable"
        return
    
    url = "https://api.openai.com/v1/chat/completions"
    
    headers = {
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    # Build the final message
    if image_base64:
        user_content = [
            {"type": "text", "text": messages[-1]["content"]},
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
            }
        ]
        messages[-1]["content"] = user_content
    
    data = {
        "model": "gpt-4o",
        "messages": messages,
        "max_tokens": 800,
        "temperature": 0.7,
        "stream": True  # Enable streaming!
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, stream=True, verify=False)
        
        if response.status_code == 200:
            buffer = ""
            
            for line in response.iter_lines():
                if line:
                    line = line.decode('utf-8')
                    
                    if line.startswith('data: '):
                        data_str = line[6:]  # Remove 'data: ' prefix
                        
                        if data_str == '[DONE]':
                            break
                        
                        try:
                            chunk_data = json.loads(data_str)
                            
                            if 'choices' in chunk_data and len(chunk_data['choices']) > 0:
                                delta = chunk_data['choices'][0].get('delta', {})
                                content = delta.get('content', '')
                                
                                if content:
                                    buffer += content
                                    
                                    # Yield when we have a complete sentence or phrase
                                    if any(punct in content for punct in ['.', '!', '?', '\n', ',', ';', ':']):
                                        if buffer.strip():
                                            yield buffer.strip()
                                            buffer = ""
                                    
                        except json.JSONDecodeError:
                            continue
            
            # Yield any remaining buffer
            if buffer.strip():
                yield buffer.strip()
        else:
            yield f"Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        yield f"Streaming error: {str(e)}"


def generate_speech_chunk(text: str, voice: str = "nova") -> bytes:
    """
    Generate speech for a text chunk
    
    Args:
        text: Text to convert to speech
        voice: Voice to use
        
    Returns:
        Audio bytes
    """
    if not OPENAI_API_KEY:
        return b''
    
    url = "https://api.openai.com/v1/audio/speech"
    
    headers = {
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'model': 'tts-1',
        'input': text,
        'voice': voice,
        'response_format': 'mp3',
        'speed': 1.0
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        if response.status_code == 200:
            return response.content
        else:
            print(f"TTS Error: {response.status_code}")
            return b''
            
    except Exception as e:
        print(f"TTS error: {str(e)}")
        return b''
