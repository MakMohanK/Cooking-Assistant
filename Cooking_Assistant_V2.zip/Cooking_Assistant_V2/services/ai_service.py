"""
AI Service: Conversational cooking assistant with recipe guidance
Using OpenAI GPT-4 for intelligent cooking assistance
"""

import os
import requests
import json
import urllib3

# Disable SSL warnings (for SSL certificate issues)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# API Configuration
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

SYSTEM_PROMPT = """You are an expert cooking assistant specifically designed to help visually impaired people cook safely and successfully. Your role is to:

1. **Recipe Guidance**: Provide step-by-step cooking instructions with clear, detailed descriptions
2. **Ingredient Information**: Describe ingredients, quantities, and measurements in detail
3. **Safety First**: Always prioritize safety - warn about hot surfaces, sharp objects, and hazards
4. **Sensory Descriptions**: Use touch, sound, smell, and temperature cues since the user cannot see
5. **Location Guidance**: Be specific about locations (e.g., "on your left", "front burner", "12 o'clock position")
6. **Substitutions**: Suggest ingredient substitutions when needed
7. **Timing & Doneness**: Provide time estimates and non-visual ways to check if food is done

Communication Style:
- Be clear, patient, and encouraging
- Use descriptive language that doesn't rely on sight
- Break complex tasks into simple steps
- Confirm understanding before moving to next steps
- Ask clarifying questions when needed

Safety Guidelines:
- Always warn about heat sources and sharp objects
- Remind about turning off appliances
- Suggest using timers and temperature indicators
- Provide tips for avoiding burns and cuts
"""

def get_cooking_assistance(user_message, image_base64=None, conversation_history=None):
    """
    Get AI-powered cooking assistance
    
    Args:
        user_message: User's question or request
        image_base64: Optional image for visual context
        conversation_history: Previous conversation for context
        
    Returns:
        AI response text
    """
    try:
        if not OPENAI_API_KEY:
            return "Please set OPENAI_API_KEY environment variable to use AI assistance"
        
        url = "https://api.openai.com/v1/chat/completions"
        
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        # Build messages array
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]
        
        # Add relevant conversation history (last 10 messages)
        if conversation_history:
            recent_history = conversation_history[-10:]
            for item in recent_history:
                if item.get('type') == 'chat':
                    messages.append({"role": "user", "content": item.get('user', '')})
                    messages.append({"role": "assistant", "content": item.get('assistant', '')})
        
        # Add current message with optional image
        if image_base64:
            messages.append({
                "role": "user",
                "content": [
                    {"type": "text", "text": user_message},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                    }
                ]
            })
        else:
            messages.append({"role": "user", "content": user_message})
        
        data = {
            "model": "gpt-4o",
            "messages": messages,
            "max_tokens": 800,
            "temperature": 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        if response.status_code == 200:
            result = response.json()
            return result['choices'][0]['message']['content']
        else:
            return f"AI Service Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return f"AI assistance error: {str(e)}"

def get_recipe_instructions(recipe_name):
    """
    Get detailed recipe instructions for visually impaired cooking
    
    Args:
        recipe_name: Name of the recipe
        
    Returns:
        Detailed recipe instructions
    """
    prompt = f"""Provide detailed cooking instructions for {recipe_name} specifically adapted for someone who is visually impaired. Include:

1. **Ingredients List**: With exact quantities and how to identify each ingredient by touch/smell
2. **Equipment Needed**: List all tools and where to place them
3. **Prep Work**: Detailed steps for preparation
4. **Cooking Steps**: Step-by-step with sensory cues (sounds, smells, textures, temperatures)
5. **Safety Notes**: Specific warnings about hot surfaces, sharp objects
6. **Timing**: How long each step takes
7. **Doneness Checks**: Non-visual ways to tell when food is ready
8. **Serving Suggestions**: How to plate and serve safely

Make each step very clear and actionable."""
    
    return get_cooking_assistance(prompt)

def check_ingredient_substitution(ingredient, reason="not available"):
    """
    Suggest ingredient substitutions
    
    Args:
        ingredient: The ingredient to substitute
        reason: Why substitution is needed
        
    Returns:
        Substitution suggestions
    """
    prompt = f"""I need to substitute {ingredient} in a recipe because it's {reason}. 

Please suggest:
1. Best substitute options (at least 3)
2. How each substitute affects the dish
3. Measurement conversions if needed
4. Any recipe adjustments required
5. How to identify the substitute by touch/smell/texture

Prioritize common household ingredients."""
    
    return get_cooking_assistance(prompt)

def get_safety_guidance(situation):
    """
    Get safety guidance for specific cooking situations
    
    Args:
        situation: Description of the situation
        
    Returns:
        Safety guidance
    """
    prompt = f"""I'm a visually impaired person cooking and I'm in this situation: {situation}

Please provide:
1. Immediate safety concerns
2. Step-by-step safety instructions
3. What to touch and what to avoid
4. How to check if it's safe to proceed
5. Prevention tips for the future

Prioritize my safety above all else."""
    
    return get_cooking_assistance(prompt)

def estimate_cooking_time(dish, method):
    """
    Estimate cooking time and provide timing guidance
    
    Args:
        dish: What is being cooked
        method: Cooking method (baking, frying, etc.)
        
    Returns:
        Timing guidance
    """
    prompt = f"""I'm cooking {dish} using {method}. 

Please tell me:
1. Expected cooking time
2. How to check doneness without seeing (touch, sound, smell, temperature)
3. Signs that it's undercooked
4. Signs that it's overcooked
5. Best practices for timing this dish
6. When to set timers and for how long"""
    
    return get_cooking_assistance(prompt)

def describe_technique(technique_name):
    """
    Explain cooking techniques in detail for visually impaired
    
    Args:
        technique_name: Name of the cooking technique
        
    Returns:
        Detailed technique description
    """
    prompt = f"""Explain the cooking technique '{technique_name}' for someone who is visually impaired.

Include:
1. What the technique is and why it's used
2. Step-by-step how to perform it
3. What it should feel like (hand position, pressure, movement)
4. What it should sound like
5. Common mistakes and how to avoid them
6. Safety considerations
7. How to know you're doing it correctly (non-visual feedback)"""
    
    return get_cooking_assistance(prompt)

def meal_planning_assistance(preferences, dietary_restrictions=None):
    """
    Help with meal planning
    
    Args:
        preferences: User's meal preferences
        dietary_restrictions: Any dietary restrictions
        
    Returns:
        Meal suggestions
    """
    restrictions_text = f" with these dietary restrictions: {dietary_restrictions}" if dietary_restrictions else ""
    
    prompt = f"""Help me plan meals. I prefer {preferences}{restrictions_text}.

Please suggest:
1. 3-5 meal ideas that are safe and practical for visually impaired cooking
2. Why each meal is a good choice
3. Difficulty level for each
4. Approximate cooking time
5. Key ingredients needed
6. Any special equipment required

Focus on meals that minimize safety risks."""
    
    return get_cooking_assistance(prompt)