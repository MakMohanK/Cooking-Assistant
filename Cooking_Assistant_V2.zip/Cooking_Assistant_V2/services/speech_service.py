"""
Speech Services: STT (Speech-to-Text) and TTS (Text-to-Speech)
Using OpenAI Whisper API for STT and OpenAI TTS for speech synthesis
"""

import os
import base64
import requests
from pathlib import Path
import urllib3

# Disable SSL warnings (for SSL certificate issues)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# API Configuration
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

def transcribe_audio(audio_path):
    """
    Convert audio to text using OpenAI Whisper API
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Transcribed text
    """
    try:
        if not OPENAI_API_KEY:
            return "Please set OPENAI_API_KEY environment variable"
        
        url = "https://api.openai.com/v1/audio/transcriptions"
        
        with open(audio_path, 'rb') as audio_file:
            files = {
                'file': audio_file,
                'model': (None, 'whisper-1'),
            }
            headers = {
                'Authorization': f'Bearer {OPENAI_API_KEY}'
            }
            
            response = requests.post(url, headers=headers, files=files, verify=False)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('text', '')
            else:
                return f"Error: {response.status_code} - {response.text}"
                
    except Exception as e:
        return f"Transcription error: {str(e)}"

def text_to_speech_base64(text, voice="alloy"):
    """
    Convert text to speech using OpenAI TTS API
    
    Args:
        text: Text to convert to speech
        voice: Voice to use (alloy, echo, fable, onyx, nova, shimmer)
        
    Returns:
        Base64 encoded audio data
    """
    try:
        if not OPENAI_API_KEY:
            return ""
        
        url = "https://api.openai.com/v1/audio/speech"
        
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'model': 'tts-1',
            'input': text,
            'voice': voice,
            'response_format': 'mp3'
        }
        
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        if response.status_code == 200:
            audio_data = response.content
            audio_base64 = base64.b64encode(audio_data).decode('utf-8')
            return audio_base64
        else:
            print(f"TTS Error: {response.status_code} - {response.text}")
            return ""
            
    except Exception as e:
        print(f"TTS error: {str(e)}")
        return ""

def text_to_speech_file(text, output_path, voice="alloy"):
    """
    Convert text to speech and save to file
    
    Args:
        text: Text to convert
        output_path: Path to save audio file
        voice: Voice to use
        
    Returns:
        True if successful, False otherwise
    """
    try:
        if not OPENAI_API_KEY:
            return False
        
        url = "https://api.openai.com/v1/audio/speech"
        
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'model': 'tts-1',
            'input': text,
            'voice': voice,
            'response_format': 'mp3'
        }
        
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        if response.status_code == 200:
            with open(output_path, 'wb') as f:
                f.write(response.content)
            return True
        else:
            print(f"TTS Error: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"TTS error: {str(e)}")
        return False

# Alternative: Use Google Cloud Speech-to-Text (if OpenAI not available)
def transcribe_audio_google(audio_path):
    """
    Alternative STT using Google Cloud Speech-to-Text API
    Requires: pip install google-cloud-speech
    """
    try:
        from google.cloud import speech
        
        client = speech.SpeechClient()
        
        with open(audio_path, 'rb') as audio_file:
            content = audio_file.read()
        
        audio = speech.RecognitionAudio(content=content)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            language_code="en-US",
            enable_automatic_punctuation=True,
        )
        
        response = client.recognize(config=config, audio=audio)
        
        transcript = ""
        for result in response.results:
            transcript += result.alternatives[0].transcript
        
        return transcript
        
    except Exception as e:
        return f"Google STT error: {str(e)}"

# Alternative: Use gTTS for offline TTS (simpler but less natural)
def text_to_speech_gtts(text, output_path):
    """
    Alternative TTS using gTTS (Google Text-to-Speech)
    Requires: pip install gtts
    """
    try:
        from gtts import gTTS
        
        tts = gTTS(text=text, lang='en', slow=False)
        tts.save(output_path)
        return True
        
    except Exception as e:
        print(f"gTTS error: {str(e)}")
        return False