"""
Vision Service: AI-powered scene analysis for cooking assistance
Using OpenAI GPT-4 Vision API for image understanding
"""

import os
import base64
import requests
import json
import urllib3

# Disable SSL warnings (for SSL certificate issues)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# API Configuration
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

def analyze_cooking_scene(image_base64, user_query=None):
    """
    Analyze cooking scene using GPT-4 Vision
    
    Args:
        image_base64: Base64 encoded image
        user_query: Optional specific question about the scene
        
    Returns:
        Analysis result as text
    """
    try:
        if not OPENAI_API_KEY:
            return "Please set OPENAI_API_KEY environment variable for vision analysis"
        
        # Default prompt for cooking assistance
        if not user_query:
            user_query = """Analyze this cooking scene and provide helpful information for a visually impaired person. Include:
1. What ingredients or cooking items do you see?
2. Are there any safety concerns (hot surfaces, sharp objects, spills)?
3. What cooking activity appears to be happening?
4. Any recommendations or guidance?
Be specific and descriptive to help someone who cannot see the scene."""
        
        url = "https://api.openai.com/v1/chat/completions"
        
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        data = {
            "model": "gpt-4o",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a helpful cooking assistant for visually impaired people. Provide clear, detailed, and safety-focused descriptions of cooking scenes. Be specific about locations, quantities, and potential hazards."
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_query
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_base64}"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": 500
        }
        
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        if response.status_code == 200:
            result = response.json()
            analysis = result['choices'][0]['message']['content']
            return analysis
        else:
            return f"Vision API Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        return f"Vision analysis error: {str(e)}"

def identify_ingredients(image_base64):
    """
    Specifically identify ingredients in the image
    
    Args:
        image_base64: Base64 encoded image
        
    Returns:
        List of identified ingredients
    """
    query = """List all the ingredients you can see in this image. 
For each ingredient, provide:
- Name of the ingredient
- Approximate quantity or size
- Location in the frame (left, right, center, front, back)
- State/condition (fresh, cooked, chopped, whole, etc.)

Format as a clear list."""
    
    return analyze_cooking_scene(image_base64, query)

def check_cooking_safety(image_base64):
    """
    Check for safety concerns in cooking scene
    
    Args:
        image_base64: Base64 encoded image
        
    Returns:
        Safety analysis
    """
    query = """Analyze this cooking scene for safety concerns. Report:
1. Hot surfaces (stove burners, pots, pans) - are they on or off?
2. Sharp objects (knives, graters) - where are they located?
3. Spills or liquid hazards on surfaces
4. Fire hazards or open flames
5. Proper placement of items (stable vs unstable)
6. Any immediate dangers

Be very specific about locations and urgency of any safety issues."""
    
    return analyze_cooking_scene(image_base64, query)

def verify_recipe_step(image_base64, recipe_step):
    """
    Verify if a recipe step has been completed correctly
    
    Args:
        image_base64: Base64 encoded image
        recipe_step: Description of the recipe step
        
    Returns:
        Verification result
    """
    query = f"""The user is trying to complete this cooking step: "{recipe_step}"

Analyze the image and:
1. Confirm if the step appears to be completed correctly
2. Describe what you see related to this step
3. Provide guidance on what to do next
4. Point out any issues or corrections needed"""
    
    return analyze_cooking_scene(image_base64, query)

def measure_quantities(image_base64):
    """
    Help estimate quantities and measurements in the scene
    
    Args:
        image_base64: Base64 encoded image
        
    Returns:
        Quantity analysis
    """
    query = """Help estimate quantities in this cooking scene:
1. Look for measuring cups, spoons, or containers
2. Estimate amounts of visible ingredients
3. Describe sizes and portions
4. Help with any measurements visible in the scene

Provide practical guidance for measuring without being able to see."""
    
    return analyze_cooking_scene(image_base64, query)

def describe_cooking_progress(image_base64):
    """
    Describe the current state of food being cooked
    
    Args:
        image_base64: Base64 encoded image
        
    Returns:
        Progress description
    """
    query = """Describe the current state of the food being cooked:
1. Color and appearance (is it browning, golden, burnt, etc.?)
2. Cooking stage (raw, partially cooked, done, overcooked)
3. Any signs of readiness or doneness
4. Recommendations for next steps (continue cooking, reduce heat, remove from heat, etc.)
5. Estimated time remaining if applicable

Help the person understand how their cooking is progressing."""
    
    return analyze_cooking_scene(image_base64, query)

# Alternative: Use Google Cloud Vision API
def analyze_scene_google(image_base64):
    """
    Alternative vision analysis using Google Cloud Vision API
    Requires: pip install google-cloud-vision
    """
    try:
        from google.cloud import vision
        
        client = vision.ImageAnnotatorClient()
        
        image = vision.Image(content=base64.b64decode(image_base64))
        
        # Perform label detection
        labels_response = client.label_detection(image=image)
        labels = labels_response.label_annotations
        
        # Perform object detection
        objects_response = client.object_localization(image=image)
        objects = objects_response.localized_object_annotations
        
        result = "Detected items:\n"
        for obj in objects:
            result += f"- {obj.name} (confidence: {obj.score:.2f})\n"
        
        result += "\nLabels:\n"
        for label in labels:
            result += f"- {label.description} (confidence: {label.score:.2f})\n"
        
        return result
        
    except Exception as e:
        return f"Google Vision error: {str(e)}"