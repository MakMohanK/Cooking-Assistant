# 📁 Project Structure

```
cooking-assistant/
│
├── 📄 app.py                          # Main Flask application
│   ├── Video streaming endpoints
│   ├── Camera management
│   ├── API routes for chat, STT, TTS
│   └── Scene analysis endpoints
│
├── 📁 services/                       # Backend services
│   ├── __init__.py                    # Package initializer
│   ├── ai_service.py                  # GPT-4 conversational AI
│   │   ├── get_cooking_assistance()   # Main chat function
│   │   ├── get_recipe_instructions()  # Recipe guidance
│   │   ├── check_ingredient_substitution()
│   │   ├── get_safety_guidance()      # Safety checks
│   │   └── describe_technique()       # Cooking techniques
│   │
│   ├── vision_service.py              # GPT-4 Vision analysis
│   │   ├── analyze_cooking_scene()    # General scene analysis
│   │   ├── identify_ingredients()     # Ingredient detection
│   │   ├── check_cooking_safety()     # Safety hazard detection
│   │   ├── verify_recipe_step()       # Recipe step verification
│   │   └── describe_cooking_progress() # Doneness checking
│   │
│   └── speech_service.py              # STT and TTS services
│       ├── transcribe_audio()         # Whisper STT
│       ├── text_to_speech_base64()    # OpenAI TTS
│       └── text_to_speech_file()      # TTS to file
│
├── 📁 templates/                      # HTML templates
│   └── index.html                     # Main web interface
│       ├── Camera feed panel (left)
│       ├── Chat interface (right)
│       ├── Quick action buttons
│       ├── Voice input controls
│       └── Status indicators
│
├── 📁 static/                         # Static assets
│   ├── style.css                      # Beautiful styling
│   │   ├── Responsive design
│   │   ├── Accessibility features
│   │   ├── High contrast support
│   │   └── Animation effects
│   │
│   └── script.js                      # Client-side JavaScript
│       ├── Voice recording (STT)
│       ├── Message handling
│       ├── Scene analysis triggers
│       ├── TTS playback
│       └── Quick action handlers
│
├── 📄 requirements.txt                # Python dependencies
├── 📄 .env.example                    # Environment template
├── 📄 .gitignore                      # Git ignore rules
│
├── 📄 setup.sh                        # Automated setup script
├── 📄 test_camera.py                  # Camera test utility
├── 📄 test_api.py                     # API test utility
│
├── 📄 README.md                       # Complete documentation
├── 📄 QUICK_START.md                  # Quick setup guide
└── 📄 PROJECT_STRUCTURE.md            # This file

```

## 🔄 Data Flow

### 1. Camera Feed Flow
```
Camera → app.py (VideoCamera) → MJPEG Stream → Browser
```

### 2. Scene Analysis Flow
```
User clicks "Analyze" 
→ Capture frame (base64)
→ vision_service.analyze_cooking_scene()
→ GPT-4 Vision API
→ Response to user
→ TTS (if auto-speak enabled)
```

### 3. Voice Input Flow
```
User holds microphone button
→ Browser records audio
→ Send to /speech_to_text
→ speech_service.transcribe_audio()
→ Whisper API
→ Text returned
→ Auto-send as message
```

### 4. Chat Flow
```
User sends message
→ /chat endpoint
→ ai_service.get_cooking_assistance()
→ GPT-4 API (with optional vision)
→ Response
→ Display + TTS
```

### 5. TTS Flow
```
Assistant response
→ /text_to_speech endpoint
→ speech_service.text_to_speech_base64()
→ OpenAI TTS API
→ Base64 audio
→ Browser plays audio
```

## 🎯 Key Features by File

### app.py (Main Application)
- Flask web server setup
- Camera singleton management
- Video streaming with MJPEG
- RESTful API endpoints
- Conversation history tracking
- CORS support

### services/ai_service.py (Conversational AI)
- Context-aware cooking assistance
- Recipe instructions adapted for visual impairment
- Ingredient substitution suggestions
- Safety guidance with priority
- Cooking technique explanations
- Meal planning assistance
- Uses sensory cues (touch, sound, smell)

### services/vision_service.py (Computer Vision)
- Real-time scene understanding
- Ingredient identification with quantities
- Safety hazard detection
- Cooking progress monitoring
- Recipe step verification
- Measurement assistance
- Location-specific guidance

### services/speech_service.py (Voice I/O)
- High-accuracy speech recognition (Whisper)
- Natural TTS with multiple voices
- Audio format handling
- Base64 encoding for web delivery
- Alternative API support (Google Cloud)

### templates/index.html (User Interface)
- Split-panel design (camera + chat)
- Quick action shortcuts
- Voice input with visual feedback
- Real-time conversation display
- Accessible controls
- Status indicators

### static/style.css (Styling)
- Modern gradient design
- Responsive layout (desktop/mobile)
- High contrast mode support
- Animation effects
- Accessibility enhancements
- Focus indicators for keyboard navigation

### static/script.js (Client Logic)
- Real-time camera interaction
- Voice recording with MediaRecorder API
- AJAX communication with backend
- Audio playback control
- Quick action handlers
- Keyboard shortcuts
- Status management

## 🔐 Security Considerations

1. **API Keys**: Stored in `.env`, never committed to git
2. **No Data Storage**: Images and audio processed in real-time only
3. **CORS**: Configured for secure cross-origin requests
4. **User Privacy**: No conversation history persisted to disk
5. **Input Validation**: All user inputs sanitized

## 🚀 Performance Optimizations

1. **Lazy Camera Loading**: Camera initialized only when needed
2. **Efficient Streaming**: MJPEG for low-latency video
3. **Base64 Encoding**: Efficient image transmission
4. **Conversation Limiting**: Only last 10 messages sent to API
5. **Async Operations**: Non-blocking API calls
6. **Resource Cleanup**: Proper camera and audio stream release

## 🎨 Design Philosophy

**Accessibility First**:
- Large, clear buttons
- High contrast colors
- Keyboard shortcuts
- Screen reader friendly
- Focus indicators
- Voice-first interaction

**Safety Priority**:
- Always warn about hazards
- Location-specific guidance
- Temperature awareness
- Sharp object detection
- Clear emergency instructions

**Sensory Adaptation**:
- Touch cues (texture, temperature)
- Sound cues (sizzling, bubbling)
- Smell cues (doneness indicators)
- Time-based guidance
- Non-visual verification methods

## 📊 API Usage Overview

| Feature | API Used | Cost per Use |
|---------|----------|--------------|
| Scene Analysis | GPT-4 Vision | ~$0.01 |
| Voice Input | Whisper | ~$0.006/min |
| Text-to-Speech | TTS-1 | ~$0.015/1K chars |
| Chat Assistant | GPT-4 | ~$0.03/1K tokens |

**Optimization Tips**:
- Use text chat when vision not needed
- Enable auto-speak selectively
- Batch questions when possible
- Use quick actions for common tasks

## 🔧 Customization Points

**Camera Settings** (app.py line 24-26):
```python
self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
```

**TTS Voice** (services/speech_service.py line 45):
```python
voice="alloy"  # Options: alloy, echo, fable, onyx, nova, shimmer
```

**AI Model** (services/ai_service.py line 80):
```python
"model": "gpt-4o"  # Or gpt-4o-mini for lower cost
```

**Conversation History** (app.py line 110):
```python
recent_history = conversation_history[-10:]  # Last 10 messages
```

## 🎓 Extension Ideas

1. **Recipe Database**: Add local recipe storage
2. **Shopping Lists**: Generate ingredient lists
3. **Nutrition Info**: Add nutritional analysis
4. **Multiple Languages**: I18n support
5. **Offline Mode**: Local model integration
6. **Smart Devices**: Control kitchen IoT devices
7. **Voice Commands**: Hands-free operation
8. **Family Sharing**: Multi-user support

---

**Project Status**: ✅ Complete and Production Ready
