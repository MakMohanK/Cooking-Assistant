# 🎤 Hands-Free Conversation Testing Guide

## ✅ What Was Fixed

The continuous conversation (hands-free) mode has been completely rebuilt with:

1. ✅ **Better Voice Activity Detection (VAD)**
   - Improved volume threshold (0.02 instead of 0.01)
   - RMS calculation for accurate volume detection
   - Adjustable sensitivity

2. ✅ **Improved Timing**
   - 2 seconds silence before auto-stop (was 1.5s)
   - Minimum 0.5 second recording duration
   - Better response to natural speech patterns

3. ✅ **Enhanced Debugging**
   - Detailed console logs for every action
   - Visual feedback for voice detection
   - Error tracking and reporting

4. ✅ **Better MediaRecorder Compatibility**
   - Tries multiple audio formats (webm, mp4, default)
   - Handles browser-specific limitations
   - Error recovery mechanisms

5. ✅ **Improved User Feedback**
   - Status updates show exactly what's happening
   - Recording indicator changes to red
   - Clear messages during processing

---

## 🧪 How to Test Hands-Free Conversation

### Step 1: Open Browser Console (IMPORTANT!)

**Press F12** to open Developer Tools and go to **Console** tab.

This shows detailed logs of what's happening:
- Voice detection events
- Recording start/stop
- Audio sending
- Server responses

### Step 2: Start the Application

```bash
python app.py
```

Access at: `http://localhost:5000`

### Step 3: Grant Permissions

Watch the console for:
```
🎤 Requesting microphone permission...
✅ Microphone permission granted!
```

Click **"Allow"** when browser prompts.

### Step 4: Start Continuous Mode

Click the green **"Start Continuous Conversation"** button.

**Watch console for:**
```
🚀 Starting continuous mode...
🎤 Requesting microphone access...
✅ Microphone stream obtained
🔊 Initializing audio context...
✅ Audio context initialized
📡 Sent start_continuous_mode to server
👂 Starting voice detection loop...
```

**Look for on page:**
- Button changes to red **"Stop Listening"**
- Status shows: **"🎤 Listening - Speak naturally"**
- Message appears: **"✅ Continuous listening started!"**

### Step 5: Test Voice Detection

**Speak clearly:** "Hello, can you hear me?"

**Watch console for:**
```
🎤 VOICE DETECTED! Volume: 0.0234 (threshold: 0.02)
🎙️ Starting MediaRecorder...
📼 MediaRecorder created with mimeType: audio/webm
✅ Recording started successfully
```

**Look for on page:**
- Status changes to: **"🔴 Recording..."**

### Step 6: Watch Silence Detection

**Stop speaking and wait 2 seconds.**

**Watch console for:**
```
🤫 Silence detected, starting 2000ms timer...
⏹️ Silence timer expired, stopping recording
⏹️ Recording stopped. Duration: 3245ms, Chunks: 3
🎵 Audio blob created: 45678 bytes
📤 Sending audio to server...
```

### Step 7: Verify Transcription

**Watch console for:**
```
📨 Audio converted to base64: 61234 chars
📡 Emitting voice_input event...
✅ Audio sent to server
```

**On server terminal, you should see:**
```
🎤 Receiving voice input from [session_id]
📝 Transcribed: Hello, can you hear me?
🤖 Response: Yes, I can hear you! How can I help you with cooking today?
```

**Look for on page:**
- Your message appears: **"Hello, can you hear me?"**
- AI response appears
- TTS voice speaks the response

### Step 8: Test Full Conversation

Try these test phrases:

1. **"What ingredients do I need for scrambled eggs?"**
2. **Wait 2 seconds** (let it detect silence and stop)
3. **Wait for response**
4. **"How do I cook them?"**
5. **Wait for response**

---

## 🔍 Troubleshooting

### Issue 1: "Voice not detected"

**Console shows:** No "🎤 VOICE DETECTED!" messages

**Solutions:**

1. **Check microphone input level**
   - Windows: Sound settings → Input → Test microphone
   - Speak and watch the volume bar move

2. **Adjust volume threshold** in `.env`:
   ```bash
   # Add to .env file:
   VAD_VOLUME_THRESHOLD=0.015  # Lower = more sensitive
   ```

3. **Test microphone volume in console:**
   ```javascript
   // Paste in browser console:
   navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
       const audioContext = new AudioContext();
       const analyser = audioContext.createAnalyser();
       const source = audioContext.createMediaStreamSource(stream);
       source.connect(analyser);
       analyser.fftSize = 2048;
       
       setInterval(() => {
           const dataArray = new Uint8Array(analyser.frequencyBinCount);
           analyser.getByteFrequencyData(dataArray);
           let sum = 0;
           for (let i = 0; i < dataArray.length; i++) {
               const normalized = dataArray[i] / 255;
               sum += normalized * normalized;
           }
           const rms = Math.sqrt(sum / dataArray.length);
           console.log('Current volume:', rms.toFixed(4));
       }, 100);
   });
   ```
   
   Speak and watch the values. They should go above 0.02 when speaking.

### Issue 2: "Recording starts but doesn't stop"

**Console shows:** Recording started but no "⏹️ Silence timer expired"

**Solutions:**

1. **Reduce silence duration** - Edit `static/continuous-fixed.js`:
   ```javascript
   const SILENCE_DURATION = 1000; // Try 1 second
   ```

2. **Check for background noise:**
   - Move to quieter location
   - Turn off fans, music, TV
   - Check if microphone picking up echo

### Issue 3: "Audio not reaching server"

**Console shows:** Audio sent but no server response

**Solutions:**

1. **Check WebSocket connection:**
   ```javascript
   // In browser console:
   console.log('Socket connected:', socket.connected);
   ```

2. **Check server logs** for errors

3. **Verify OpenAI API key** is set in `.env`

4. **Test with simple message:**
   ```javascript
   // In browser console:
   socket.emit('voice_input', { audio: 'test' });
   ```

### Issue 4: "MediaRecorder not supported"

**Console shows:** MediaRecorder errors

**Solutions:**

1. **Update your browser** to latest version
2. **Try different browser:**
   - Chrome (best support)
   - Firefox
   - Edge
3. **Check browser support:**
   ```javascript
   // In browser console:
   console.log('MediaRecorder supported:', typeof MediaRecorder !== 'undefined');
   console.log('audio/webm supported:', MediaRecorder.isTypeSupported('audio/webm'));
   ```

### Issue 5: "TTS not playing"

**Console shows:** TTS complete but no audio

**Solutions:**

1. **Check system volume**
2. **Check browser audio permissions**
3. **Test TTS manually:**
   ```javascript
   // In browser console:
   fetch('/text_to_speech', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({ text: 'This is a test' })
   }).then(r => r.json()).then(d => {
       const audio = new Audio('data:audio/mp3;base64,' + d.audio);
       audio.play();
   });
   ```

---

## 📊 Expected Console Output (Full Flow)

```
✅ Continuous conversation module loaded (FIXED VERSION)
🔐 Requesting permissions...
🎤 Requesting microphone permission...
✅ Microphone permission granted!
🔌 Connecting to WebSocket: ws://localhost:5000
✅ WebSocket connected
✅ Continuous button event listener attached

[User clicks "Start Continuous Conversation"]

🚀 Starting continuous mode...
🎤 Requesting microphone access...
✅ Microphone stream obtained
🔊 Initializing audio context...
✅ Audio context initialized
📡 Sent start_continuous_mode to server
👂 Starting voice detection loop...

[User speaks: "Hello"]

🎤 VOICE DETECTED! Volume: 0.0234 (threshold: 0.02)
🎙️ Starting MediaRecorder...
📼 MediaRecorder created with mimeType: audio/webm
✅ Recording started successfully
📦 Audio chunk received: 4096 bytes
📦 Audio chunk received: 4096 bytes

[User stops speaking]

🤫 Silence detected, starting 2000ms timer...
⏹️ Silence timer expired, stopping recording
🛑 Stopping recorder...
⏹️ Recording stopped. Duration: 2345ms, Chunks: 2
🎵 Audio blob created: 8192 bytes
📤 Sending audio to server...
📨 Audio converted to base64: 10923 chars
📡 Emitting voice_input event...
✅ Audio sent to server
👤 User message received: Hello
🤖 Assistant message received: Hello! How can I help you...
🔊 Speaking: "Hello! How can I help you..."
▶️ TTS playback started
✅ TTS playback ended
```

---

## 🎯 Performance Benchmarks

**Normal Operation:**
- Voice detection: < 100ms
- Recording start: < 200ms
- Silence detection: 2 seconds
- Audio upload: 1-2 seconds
- Transcription: 2-4 seconds
- AI response: 3-6 seconds
- TTS generation: 2-3 seconds
- **Total response time: 8-15 seconds**

---

## ⚙️ Advanced Configuration

### Adjust Sensitivity

Edit `static/continuous-fixed.js`:

```javascript
// Make MORE sensitive (detects softer speech):
const VOLUME_THRESHOLD = 0.015;

// Make LESS sensitive (ignores background noise):
const VOLUME_THRESHOLD = 0.03;
```

### Adjust Silence Duration

```javascript
// Faster cutoff (interrupts less):
const SILENCE_DURATION = 1500; // 1.5 seconds

// Slower cutoff (better for pauses):
const SILENCE_DURATION = 3000; // 3 seconds
```

### Adjust Response Rate

```javascript
// Check volume more frequently (more CPU):
const VAD_CHECK_INTERVAL = 25; // 25ms

// Check less frequently (less CPU):
const VAD_CHECK_INTERVAL = 100; // 100ms
```

---

## ✅ Success Checklist

When everything is working correctly:

- [ ] Browser console shows "✅ Continuous conversation module loaded (FIXED VERSION)"
- [ ] Microphone permission granted without errors
- [ ] WebSocket connects successfully
- [ ] Click "Start Continuous Conversation" - button turns red
- [ ] Status shows "🎤 Listening - Speak naturally"
- [ ] When you speak, console shows "🎤 VOICE DETECTED!"
- [ ] Status changes to "🔴 Recording..."
- [ ] After 2 seconds silence, recording stops automatically
- [ ] Console shows "📤 Sending audio to server..."
- [ ] Your transcribed text appears in chat
- [ ] AI response appears in chat
- [ ] AI response is spoken aloud via TTS
- [ ] After TTS ends, status returns to "🎤 Listening"
- [ ] Can speak again and repeat the cycle

---

## 🆘 Still Not Working?

### Collect Debug Information

1. **Export console log:**
   - Right-click in console → Save as...
   - Share the log file

2. **Check server logs:**
   ```bash
   # Server should show:
   🎤 Receiving voice input from [session_id]
   📝 Transcribed: [your text]
   🤖 Response: [AI response]
   ```

3. **Test components individually:**
   
   **Test WebSocket:**
   ```javascript
   socket.emit('start_continuous_mode');
   // Should see welcome message
   ```
   
   **Test voice input manually:**
   ```javascript
   // Record audio then:
   navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
       const recorder = new MediaRecorder(stream);
       const chunks = [];
       recorder.ondataavailable = e => chunks.push(e.data);
       recorder.onstop = () => {
           const blob = new Blob(chunks);
           const reader = new FileReader();
           reader.onloadend = () => {
               socket.emit('voice_input', { audio: reader.result });
           };
           reader.readAsDataURL(blob);
       };
       recorder.start();
       setTimeout(() => recorder.stop(), 3000);
   });
   ```

---

## 📞 Get Help

Share these details:

1. Browser name and version
2. Console logs (full output)
3. Server terminal output
4. What you said vs what was transcribed
5. Any error messages

---

**The hands-free conversation should now work properly with detailed debugging! Check the console (F12) to see exactly what's happening.** 🎤✅
