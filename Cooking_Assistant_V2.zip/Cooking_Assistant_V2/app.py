"""
Cooking Assistant for Visually Impaired People
Flask Web Application with AI Vision, STT, and TTS
Enhanced with Continuous Conversation Support
"""

from flask import Flask, render_template, Response, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import cv2
import base64
import os
from datetime import datetime
import json
import threading
import queue
from dotenv import load_dotenv
import time

# Load environment variables from .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configuration from environment variables
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'cooking-assistant-secret-key')
app.config['DEBUG'] = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'

# Initialize SocketIO for real-time communication
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Camera configuration
CAMERA_INDEX = int(os.getenv('CAMERA_INDEX', 0))
CAMERA_WIDTH = int(os.getenv('CAMERA_WIDTH', 640))
CAMERA_HEIGHT = int(os.getenv('CAMERA_HEIGHT', 480))
CAMERA_FPS = int(os.getenv('CAMERA_FPS', 30))

# Conversation configuration
CONVERSATION_HISTORY_LENGTH = int(os.getenv('CONVERSATION_HISTORY_LENGTH', 10))
CONTINUOUS_MODE_ENABLED = os.getenv('CONTINUOUS_MODE_ENABLED', 'True').lower() == 'true'

# Debug configuration
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
SAVE_DEBUG_FRAMES = os.getenv('SAVE_DEBUG_FRAMES', 'False').lower() == 'true'
DEBUG_FRAMES_DIR = os.getenv('DEBUG_FRAMES_DIR', 'debug_frames')

# Global variables
camera = None
camera_lock = threading.Lock()
conversation_history = []
continuous_mode_active = {}  # Track active sessions
speech_queue = queue.Queue()  # Queue for TTS processing

class VideoCamera:
    """Handle video camera operations"""
    def __init__(self, camera_index=CAMERA_INDEX):
        print(f"🎥 Initializing camera (index: {camera_index})...")
        self.video = cv2.VideoCapture(camera_index)
        
        if not self.video.isOpened():
            print(f"⚠️  Warning: Could not open camera at index {camera_index}")
            # Try alternative camera indices
            for alt_index in [0, 1, 2]:
                if alt_index != camera_index:
                    print(f"Trying camera index {alt_index}...")
                    self.video = cv2.VideoCapture(alt_index)
                    if self.video.isOpened():
                        print(f"✅ Camera opened at index {alt_index}")
                        break
        
        if self.video.isOpened():
            self.video.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
            self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
            self.video.set(cv2.CAP_PROP_FPS, CAMERA_FPS)
            print(f"✅ Camera configured: {CAMERA_WIDTH}x{CAMERA_HEIGHT} @ {CAMERA_FPS}fps")
        else:
            print("❌ ERROR: Could not initialize any camera")
        
    def __del__(self):
        if hasattr(self, 'video'):
            self.video.release()
        
    def get_frame(self):
        """Capture frame from camera"""
        if not self.video.isOpened():
            return None
            
        success, frame = self.video.read()
        if not success:
            return None
            
        # Encode frame as JPEG
        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes()
    
    def get_frame_base64(self):
        """Get frame as base64 for API calls"""
        if not self.video.isOpened():
            return None
            
        success, frame = self.video.read()
        if not success:
            return None
            
        # Save debug frame if enabled
        if SAVE_DEBUG_FRAMES:
            os.makedirs(DEBUG_FRAMES_DIR, exist_ok=True)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            debug_path = os.path.join(DEBUG_FRAMES_DIR, f'frame_{timestamp}.jpg')
            cv2.imwrite(debug_path, frame)
        
        ret, buffer = cv2.imencode('.jpg', frame)
        jpg_as_text = base64.b64encode(buffer).decode('utf-8')
        return jpg_as_text

def get_camera():
    """Singleton camera instance"""
    global camera
    with camera_lock:
        if camera is None:
            camera = VideoCamera()
        return camera

def gen_frames():
    """Generate video frames for streaming"""
    camera = get_camera()
    while True:
        frame = camera.get_frame()
        if frame is None:
            continue
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# ============================================================
# WebSocket Events for Continuous Conversation
# ============================================================

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    session_id = request.sid
    continuous_mode_active[session_id] = False
    if DEBUG_MODE:
        print(f"🔌 Client connected: {session_id}")
    emit('connection_status', {'status': 'connected', 'session_id': session_id})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    session_id = request.sid
    if session_id in continuous_mode_active:
        del continuous_mode_active[session_id]
    if DEBUG_MODE:
        print(f"🔌 Client disconnected: {session_id}")

@socketio.on('start_continuous_mode')
def handle_start_continuous():
    """Start continuous conversation mode"""
    session_id = request.sid
    continuous_mode_active[session_id] = True
    if DEBUG_MODE:
        print(f"🎤 Continuous mode started for {session_id}")
    
    # Send welcome message with TTS
    welcome_msg = "Hello! I'm your cooking assistant. I'm listening continuously. Just speak naturally and I'll help you. Say 'stop listening' when you're done."
    emit('assistant_message', {
        'text': welcome_msg,
        'timestamp': datetime.now().isoformat(),
        'speak': True
    })

@socketio.on('stop_continuous_mode')
def handle_stop_continuous():
    """Stop continuous conversation mode"""
    session_id = request.sid
    continuous_mode_active[session_id] = False
    if DEBUG_MODE:
        print(f"🎤 Continuous mode stopped for {session_id}")
    
    goodbye_msg = "Continuous listening stopped. Click the microphone button to start again."
    emit('assistant_message', {
        'text': goodbye_msg,
        'timestamp': datetime.now().isoformat(),
        'speak': True
    })

@socketio.on('voice_input')
def handle_voice_input(data):
    """Handle continuous voice input"""
    session_id = request.sid
    
    if not continuous_mode_active.get(session_id, False):
        emit('error', {'message': 'Continuous mode not active'})
        return
    
    audio_data = data.get('audio')
    include_vision = data.get('include_vision', False)
    client_image = data.get('image')  # NEW: Accept image from client
    
    if DEBUG_MODE:
        print(f"🎤 Receiving voice input from {session_id}")
    
    try:
        # Emit processing status
        emit('processing_status', {'status': 'transcribing'})
        
        # Save audio temporarily
        audio_bytes = base64.b64decode(audio_data.split(',')[1] if ',' in audio_data else audio_data)
        audio_path = f'temp_audio_{session_id}.wav'
        with open(audio_path, 'wb') as f:
            f.write(audio_bytes)
        
        # Transcribe audio
        from services.speech_service import transcribe_audio
        text = transcribe_audio(audio_path)
        
        # Clean up
        if os.path.exists(audio_path):
            os.remove(audio_path)
        
        if not text or text.strip() == '':
            emit('processing_status', {'status': 'ready'})
            return
        
        if DEBUG_MODE:
            print(f"📝 Transcribed: {text}")
        
        # Check for stop commands
        stop_commands = ['stop listening', 'stop conversation', 'goodbye', 'that\'s all']
        if any(cmd in text.lower() for cmd in stop_commands):
            handle_stop_continuous()
            return
        
        # Emit transcription
        emit('user_message', {
            'text': text,
            'timestamp': datetime.now().isoformat()
        })
        
        # Process with AI
        emit('processing_status', {'status': 'thinking'})
        
        from services.ai_service import get_cooking_assistance
        
        # Use client-provided image if available, otherwise use server camera
        image_data = None
        if include_vision:
            if client_image:
                # Use image from client device
                image_data = client_image
                if DEBUG_MODE:
                    print("📷 Using client-provided camera image")
            else:
                # Fallback to server camera
                camera = get_camera()
                image_data = camera.get_frame_base64()
                if DEBUG_MODE:
                    print("📷 Using server camera image (fallback)")

        response = get_cooking_assistance(text, image_data, conversation_history)
        
        # Add to conversation history
        conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'chat',
            'user': text,
            'assistant': response
        })
        
        # Limit conversation history length
        if len(conversation_history) > CONVERSATION_HISTORY_LENGTH * 2:
            conversation_history[:] = conversation_history[-CONVERSATION_HISTORY_LENGTH * 2:]
        if DEBUG_MODE:
            print(f"🤖 Response: {response[:100]}...")
        
        # Send response with TTS
        emit('assistant_message', {
            'text': response,
            'timestamp': datetime.now().isoformat(),
            'speak': True
        })
        
        emit('processing_status', {'status': 'ready'})
        
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ Voice input error: {str(e)}")
        emit('error', {'message': str(e)})
        emit('processing_status', {'status': 'ready'})

@socketio.on('text_input')
def handle_text_input(data):
    """Handle text input in continuous mode"""
    session_id = request.sid
    message = data.get('message', '')
    include_vision = data.get('include_vision', False)
    
    if not message:
        return
    
    if DEBUG_MODE:
        print(f"💬 Text input: {message[:50]}...")
    
    try:
        # Emit user message
        emit('user_message', {
            'text': message,
        'timestamp': datetime.now().isoformat()
    })

        emit('processing_status', {'status': 'thinking'})
        
        from services.ai_service import get_cooking_assistance
        
        # Optionally include current frame
        image_data = None
        if include_vision:
            camera = get_camera()
            image_data = camera.get_frame_base64()
        
        response = get_cooking_assistance(message, image_data, conversation_history)
        
        # Add to conversation history
        conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'chat',
            'user': message,
            'assistant': response
        })
        
        # Limit conversation history length
        if len(conversation_history) > CONVERSATION_HISTORY_LENGTH * 2:
            conversation_history[:] = conversation_history[-CONVERSATION_HISTORY_LENGTH * 2:]
        
        # Send response with TTS
        auto_speak = continuous_mode_active.get(session_id, False)
        emit('assistant_message', {
            'text': response,
            'timestamp': datetime.now().isoformat(),
            'speak': auto_speak
        })
        
        emit('processing_status', {'status': 'ready'})
        
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ Text input error: {str(e)}")
        emit('error', {'message': str(e)})
        emit('processing_status', {'status': 'ready'})

# ============================================================
# Traditional HTTP Routes (Keep for compatibility)
# ============================================================

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    """Video streaming route"""
    return Response(gen_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture_frame', methods=['POST'])
def capture_frame():
    """Capture current frame for analysis"""
    try:
        camera = get_camera()
        frame_base64 = camera.get_frame_base64()
        if frame_base64:
            if DEBUG_MODE:
                print(f"📸 Frame captured (size: {len(frame_base64)} chars)")
            return jsonify({
                'success': True,
                'image': frame_base64
            })
        return jsonify({'success': False, 'error': 'Failed to capture frame'})
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ Capture error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/analyze_scene', methods=['POST'])
def analyze_scene():
    """Analyze scene using AI vision"""
    try:
        data = request.json
        image_data = data.get('image')
        user_query = data.get('query', 'What do you see in this cooking scene?')
        
        if DEBUG_MODE:
            print(f"🔍 Analyzing scene: {user_query[:50]}...")
        
        # Import vision analysis module
        from services.vision_service import analyze_cooking_scene
        
        result = analyze_cooking_scene(image_data, user_query)
        
        # Add to conversation history
        conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'analysis',
            'query': user_query,
            'response': result
        })
        
        # Limit conversation history length
        if len(conversation_history) > CONVERSATION_HISTORY_LENGTH * 2:
            conversation_history[:] = conversation_history[-CONVERSATION_HISTORY_LENGTH * 2:]
        
        if DEBUG_MODE:
            print(f"✅ Analysis complete ({len(result)} chars)")
        
        return jsonify({
            'success': True,
            'analysis': result
        })
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ Analysis error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/speech_to_text', methods=['POST'])
def speech_to_text():
    """Convert speech to text"""
    try:
        audio_file = request.files.get('audio')
        if not audio_file:
            return jsonify({'success': False, 'error': 'No audio file provided'})
        
        # Save audio temporarily
        audio_path = 'temp_audio.wav'
        audio_file.save(audio_path)
        
        if DEBUG_MODE:
            print(f"🎤 Transcribing audio ({os.path.getsize(audio_path)} bytes)...")
        
        # Import STT service
        from services.speech_service import transcribe_audio
        
        text = transcribe_audio(audio_path)
        
        # Clean up
        if os.path.exists(audio_path):
            os.remove(audio_path)
        
        if DEBUG_MODE:
            print(f"✅ Transcription: {text[:100]}...")
        
        return jsonify({
            'success': True,
            'text': text
        })
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ STT error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/text_to_speech', methods=['POST'])
def text_to_speech():
    """Convert text to speech"""
    try:
        data = request.json
        text = data.get('text')
        
        if not text:
            return jsonify({'success': False, 'error': 'No text provided'})
        
        if DEBUG_MODE:
            print(f"🔊 Generating speech ({len(text)} chars)...")
        
        # Import TTS service
        from services.speech_service import text_to_speech_base64
        
        audio_base64 = text_to_speech_base64(text)
        
        if DEBUG_MODE:
            print(f"✅ TTS complete ({len(audio_base64)} chars)")
        
        return jsonify({
            'success': True,
            'audio': audio_base64
        })
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ TTS error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/chat', methods=['POST'])
def chat():
    """Chat with cooking assistant"""
    try:
        data = request.json
        message = data.get('message')
        include_vision = data.get('include_vision', False)
        image_data = data.get('image')  # NEW: Accept image from client
        
        if DEBUG_MODE:
            print(f"💬 Chat message: {message[:50]}... (vision: {include_vision})")
        
        # Import AI service
        from services.ai_service import get_cooking_assistance
        
        # Use client-provided image if available, otherwise use server camera
        if include_vision and not image_data:
            # Fallback to server camera if no client image provided
            camera = get_camera()
            image_data = camera.get_frame_base64()
        
        response = get_cooking_assistance(message, image_data, conversation_history)
        
        # Add to conversation history
        conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'chat',
            'user': message,
            'assistant': response
        })
        
        # Limit conversation history length
        if len(conversation_history) > CONVERSATION_HISTORY_LENGTH * 2:
            conversation_history[:] = conversation_history[-CONVERSATION_HISTORY_LENGTH * 2:]
        
        if DEBUG_MODE:
            print(f"✅ Chat response ({len(response)} chars)")
        
        return jsonify({
            'success': True,
            'response': response
        })
    except Exception as e:
        if DEBUG_MODE:
            print(f"❌ Chat error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/conversation_history', methods=['GET'])
def get_conversation_history():
    """Get conversation history"""
    return jsonify({
        'success': True,
        'history': conversation_history[-50:]  # Last 50 messages
    })

@app.route('/clear_history', methods=['POST'])
def clear_history():
    """Clear conversation history"""
    global conversation_history
    conversation_history = []
    if DEBUG_MODE:
        print("🗑️  Conversation history cleared")
    return jsonify({'success': True})

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'camera_available': camera is not None and camera.video.isOpened() if camera else False,
        'conversation_count': len(conversation_history),
        'continuous_mode': CONTINUOUS_MODE_ENABLED,
        'active_sessions': len(continuous_mode_active),
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('services', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    if SAVE_DEBUG_FRAMES:
        os.makedirs(DEBUG_FRAMES_DIR, exist_ok=True)
    
    # Get configuration
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    
    print("=" * 60)
    print("🍳 COOKING ASSISTANT FOR VISUALLY IMPAIRED")
    print("   Enhanced with Continuous Conversation")
    print("=" * 60)
    print(f"Environment: {os.getenv('FLASK_ENV', 'development')}")
    print(f"Debug mode: {debug}")
    print(f"Continuous mode: {CONTINUOUS_MODE_ENABLED}")
    print(f"Camera: Index {CAMERA_INDEX}, {CAMERA_WIDTH}x{CAMERA_HEIGHT}")
    print(f"Starting Flask server on {host}:{port}...")
    print(f"Access the application at: http://localhost:{port}")
    print("=" * 60)
    
    socketio.run(app, host=host, port=port, debug=debug, allow_unsafe_werkzeug=True)
