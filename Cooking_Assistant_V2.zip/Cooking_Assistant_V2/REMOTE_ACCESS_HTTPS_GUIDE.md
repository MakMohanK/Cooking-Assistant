# 🔒 Remote Access with HTTPS - Complete Guide

## ❌ **The Problem**

When accessing from a remote device (phone/tablet), the browser **does NOT ask for camera/microphone permissions** over HTTP.

### Why This Happens:

Modern browsers require **HTTPS (secure connection)** to access:
- 📷 Camera
- 🎤 Microphone
- 📍 Location
- Other sensitive APIs

| Connection Type | Works? | Permissions? |
|----------------|--------|--------------|
| `http://localhost:5000` | ✅ Yes | ✅ Asks |
| `http://192.168.1.100:5000` | ❌ No | ❌ Silent block |
| `https://192.168.1.100:5000` | ✅ Yes | ✅ Asks |

---

## ✅ **The Solution: Use HTTPS**

I've created an HTTPS version that works with remote devices!

---

## 🚀 **Quick Setup (5 Minutes)**

### Step 1: Install SSL Dependencies

```bash
# Activate virtual environment
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate     # Windows

# Install SSL support
pip install pyopenssl cryptography

# Or update all requirements
pip install -r requirements.txt
```

### Step 2: Run HTTPS Server

```bash
python run_https.py
```

You'll see:
```
🍳 COOKING ASSISTANT - HTTPS MODE (REMOTE ACCESS)
⚠️  IMPORTANT: Using self-signed SSL certificate
🔒 SSL Certificate: Self-signed (Development)
🌐 Server starting on: https://0.0.0.0:5000
```

### Step 3: Find Your IP Address

**On Raspberry Pi / Linux:**
```bash
hostname -I
# Output: 192.168.1.100 ...
```

**On Windows:**
```bash
ipconfig
# Look for "IPv4 Address"
```

Note your IP address (e.g., `192.168.1.100`)

### Step 4: Access from Phone/Tablet

On your mobile device browser, go to:
```
https://192.168.1.100:5000
```
(Replace with YOUR actual IP address)

---

## 📱 **Bypass Security Warning (REQUIRED)**

You **WILL** see a security warning. This is normal because we're using a self-signed certificate.

### On Chrome (Android)

1. You'll see: **"Your connection is not private"**
2. Click **"Advanced"**
3. Click **"Proceed to 192.168.1.100 (unsafe)"**
4. ✅ Page loads!

### On Safari (iOS/iPhone/iPad)

1. You'll see: **"This Connection Is Not Private"**
2. Tap **"Show Details"**
3. Tap **"visit this website"**
4. Enter device passcode if prompted
5. Tap **"Visit Website"** again
6. ✅ Page loads!

### On Desktop Chrome

1. You'll see: **"Your connection is not private"**
2. Click **"Advanced"**
3. Click **"Proceed to localhost (unsafe)"**
4. ✅ Page loads!

### On Firefox (Desktop/Mobile)

1. Click **"Advanced"**
2. Click **"Accept the Risk and Continue"**
3. ✅ Page loads!

---

## 🎉 **Now It Works!**

After bypassing the warning:

1. ✅ **Browser asks for camera permission** - Click "Allow"
2. ✅ **Browser asks for microphone permission** - Click "Allow"
3. ✅ **Camera feed shows from your phone!**
4. ✅ **Microphone works for voice input!**
5. ✅ **Continuous conversation mode works!**

---

## 🔧 **Troubleshooting**

### Issue 1: "pyopenssl not installed"

**Error:**
```
ModuleNotFoundError: No module named 'OpenSSL'
```

**Solution:**
```bash
pip install pyopenssl cryptography
```

### Issue 2: "Address already in use"

**Error:**
```
OSError: [Errno 98] Address already in use
```

**Solution:**
```bash
# Stop existing server (Ctrl+C)
# Or kill Python processes:
pkill -f python  # Linux
taskkill /F /IM python.exe  # Windows

# Then restart
python run_https.py
```

### Issue 3: Still no permission prompt

**Check these:**

1. ✅ Using **HTTPS** (not HTTP)?
   - URL should start with `https://`
   
2. ✅ Bypassed security warning?
   - Click "Advanced" → "Proceed"
   
3. ✅ Same WiFi network?
   - Phone and server on same network
   
4. ✅ Clear browser data
   - Settings → Privacy → Clear browsing data
   - Refresh page

5. ✅ Check browser console (F12)
   - Look for permission errors

### Issue 4: Cannot connect at all

**Check firewall:**

**Linux/Raspberry Pi:**
```bash
# Allow port 5000
sudo ufw allow 5000
# Or disable firewall temporarily
sudo ufw disable
```

**Windows:**
```bash
# Allow Python through firewall
netsh advfirewall firewall add rule name="Python Flask" dir=in action=allow program="C:\Python310\python.exe" enable=yes
```

### Issue 5: Self-signed certificate error persists

**Try this:**

1. **Clear browser SSL cache**
   - Chrome: `chrome://net-internals/#sslCertificates`
   - Clear all
   
2. **Use incognito/private mode**
   - May bypass certificate cache

3. **Try different browser**
   - Chrome usually works best
   - Firefox is also good

---

## 🔒 **Security Notes**

### Self-Signed Certificate (Development)

**What is it?**
- A temporary SSL certificate created by the server
- Not verified by a trusted authority
- Safe for local network use

**Is it secure?**
- ✅ Yes, for home/local network
- ✅ Encrypts data between device and server
- ❌ Not suitable for public internet

**When to use:**
- ✅ Testing on local network
- ✅ Home use
- ✅ Development

### For Production (Real Certificate)

If deploying publicly, use Let's Encrypt (free):

```bash
# Install certbot
sudo apt-get install certbot

# Get certificate (requires domain name)
sudo certbot certonly --standalone -d yourdomain.com

# Use real certificate
python app.py  # Configure in app.py
```

---

## 📊 **Comparison**

| Feature | HTTP | HTTPS (Self-signed) | HTTPS (Real cert) |
|---------|------|---------------------|-------------------|
| Local access | ✅ | ✅ | ✅ |
| Remote access | ❌ | ✅ | ✅ |
| Camera permission | ❌ | ✅ | ✅ |
| Microphone permission | ❌ | ✅ | ✅ |
| Security warning | ❌ | ⚠️ Yes | ✅ No |
| Public internet | ❌ | ❌ | ✅ |

---

## 🎯 **Complete Testing Checklist**

### Before Starting:
- [ ] Installed pyopenssl: `pip install pyopenssl`
- [ ] Server and device on same WiFi
- [ ] Know server IP address

### Server Side:
- [ ] Run: `python run_https.py`
- [ ] See: "Server starting on: https://0.0.0.0:5000"
- [ ] No errors in terminal

### Client Side (Phone/Tablet):
- [ ] Open browser
- [ ] Go to: `https://YOUR_IP:5000`
- [ ] See security warning
- [ ] Click "Advanced" → "Proceed"
- [ ] Page loads
- [ ] Browser asks for camera - Click "Allow"
- [ ] Browser asks for microphone - Click "Allow"
- [ ] Camera feed shows YOUR device camera
- [ ] Status shows: "✅ Microphone ready"

### Test Features:
- [ ] Click "Analyze Scene" - Works
- [ ] Hold microphone button and speak - Works
- [ ] Click "Start Continuous Conversation" - Works
- [ ] Speak naturally - Voice detected and transcribed
- [ ] AI responds with voice - TTS works

---

## 🔄 **Switching Between HTTP and HTTPS**

### Use HTTP (Local Only):
```bash
python app.py
# Access: http://localhost:5000
```

### Use HTTPS (Remote Access):
```bash
python run_https.py
# Access: https://YOUR_IP:5000
```

---

## 💡 **Pro Tips**

### 1. Bookmark the HTTPS URL
On your phone, bookmark:
```
https://192.168.1.100:5000
```
(Use your actual IP)

### 2. Add to Home Screen
**iOS:**
- Safari → Share → Add to Home Screen

**Android:**
- Chrome → Menu → Add to Home Screen

Creates app-like icon!

### 3. Use Static IP
Set a static IP for your Raspberry Pi so the URL doesn't change.

**On Raspberry Pi:**
Edit `/etc/dhcpcd.conf`:
```bash
sudo nano /etc/dhcpcd.conf

# Add at the end:
interface wlan0
static ip_address=192.168.1.100/24
static routers=192.168.1.1
static domain_name_servers=192.168.1.1 8.8.8.8
```

### 4. Use mDNS (Bonus)
Access by name instead of IP:

```bash
# On Raspberry Pi
sudo apt-get install avahi-daemon

# Now access as:
https://raspberrypi.local:5000
```

---

## 🆘 **Still Not Working?**

### Collect Debug Info:

1. **Server terminal output:**
   - Copy full output from `python run_https.py`

2. **Browser console (F12):**
   - Open DevTools
   - Copy any errors

3. **Network info:**
   ```bash
   # On server
   hostname -I
   ping YOUR_PHONE_IP
   ```

4. **Test HTTPS manually:**
   ```bash
   # From phone browser
   https://YOUR_SERVER_IP:5000/health
   
   # Should show JSON response
   ```

---

## 📋 **Quick Reference Card**

Print this:

```
═══════════════════════════════════════════════════════════
🍳 COOKING ASSISTANT - REMOTE ACCESS QUICK GUIDE
═══════════════════════════════════════════════════════════

1️⃣  START SERVER:
   python run_https.py

2️⃣  FIND IP:
   hostname -I  (Linux)
   ipconfig     (Windows)

3️⃣  ON PHONE, GO TO:
   https://YOUR_IP:5000

4️⃣  BYPASS WARNING:
   Advanced → Proceed to... (unsafe)

5️⃣  ALLOW PERMISSIONS:
   ✓ Camera
   ✓ Microphone

6️⃣  START COOKING!
   Click "Start Continuous Conversation"

═══════════════════════════════════════════════════════════
⚠️  IMPORTANT: Must use HTTPS, not HTTP!
🔒 Self-signed certificate warning is normal - click proceed
📱 Bookmark the URL for quick access
═══════════════════════════════════════════════════════════
```

---

## ✅ **Expected Result**

When everything is working:

1. ✅ Server shows: `🌐 Server starting on: https://0.0.0.0:5000`
2. ✅ Phone browser shows security warning (normal)
3. ✅ After bypass: Page loads completely
4. ✅ Camera permission prompt appears
5. ✅ Microphone permission prompt appears
6. ✅ Camera feed shows YOUR phone's camera
7. ✅ Status shows "✅ Microphone ready"
8. ✅ Continuous conversation works
9. ✅ Voice detection works
10. ✅ AI responds with voice

---

**Now your remote device camera and microphone will work properly!** 🎉📱🔒
