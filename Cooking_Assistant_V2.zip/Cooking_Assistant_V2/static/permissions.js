// Unified Permission Management for Camera and Microphone
// Handles proactive permission requests with user-friendly error messages

class PermissionManager {
    constructor() {
        this.microphoneGranted = false;
        this.cameraGranted = false;
        this.microphoneStream = null;
        this.statusCallback = null;
        this.messageCallback = null;
    }
    
    // Set callbacks for UI updates
    setCallbacks(statusCallback, messageCallback) {
        this.statusCallback = statusCallback;
        this.messageCallback = messageCallback;
    }
    
    // Update status
    updateStatus(message, duration = 0) {
        if (this.statusCallback) {
            this.statusCallback(message, duration);
        }
    }
    
    // Add message to conversation
    addMessage(content, type = 'info') {
        if (this.messageCallback) {
            this.messageCallback(content, type);
        }
    }
    
    // Request microphone permission
    async requestMicrophone() {
        if (this.microphoneGranted) {
            console.log('✅ Microphone already granted');
            return true;
        }
        
        try {
            console.log('🎤 Requesting microphone permission...');
            this.updateStatus('Requesting microphone permission...', 0);
            
            // Request microphone with optimal settings
            this.microphoneStream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: 16000
                }
            });
            
            console.log('✅ Microphone permission granted!');
            this.microphoneGranted = true;
            
            // Show success message
            this.addMessage(`
                <p><strong>✅ Microphone Permission Granted!</strong></p>
                <p>You can now use voice input and continuous conversation mode.</p>
            `, 'success');
            
            this.updateStatus('✅ Microphone ready');
            
            return true;
            
        } catch (error) {
            console.error('❌ Microphone permission error:', error);
            this.microphoneGranted = false;
            this.showMicrophoneError(error);
            return false;
        }
    }
    
    // Request camera permission
    async requestCamera() {
        if (this.cameraGranted) {
            console.log('✅ Camera already granted');
            return true;
        }
        
        try {
            console.log('📷 Requesting camera permission...');
            
            // Camera is handled by camera-capture.js
            // This is just for checking permission status
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: 'environment' }
            });
            
            console.log('✅ Camera permission granted!');
            this.cameraGranted = true;
            
            // Stop the test stream (camera-capture.js will handle actual camera)
            stream.getTracks().forEach(track => track.stop());
            
            return true;
            
        } catch (error) {
            console.error('❌ Camera permission error:', error);
            this.cameraGranted = false;
            return false;
        }
    }
    
    // Request all permissions
    async requestAllPermissions() {
        console.log('🔐 Requesting all permissions...');
        
        // Request microphone first (most important)
        const micResult = await this.requestMicrophone();
        
        // Request camera (handled by camera-capture.js, this is just for permission check)
        // const camResult = await this.requestCamera();
        
        if (micResult) {
            this.addMessage(`
                <p><strong>🎉 Setup Complete!</strong></p>
                <p>You're ready to start cooking with AI assistance!</p>
                <ul>
                    <li>✅ Microphone: Ready for voice input</li>
                    <li>✅ Camera: Point at your cooking area</li>
                </ul>
                <p><strong>Quick Tips:</strong></p>
                <ul>
                    <li>🎤 Hold the microphone button to speak (manual mode)</li>
                    <li>🔄 Click "Start Continuous Conversation" for hands-free mode</li>
                    <li>📷 Click "Analyze Scene" to see what the camera detects</li>
                </ul>
            `, 'success');
        }
        
        return micResult;
    }
    
    // Show microphone error with helpful instructions
    showMicrophoneError(error) {
        let errorMessage = '';
        let helpText = '';
        let iconColor = '#ef4444';
        
        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
            errorMessage = '🚫 Microphone Permission Denied';
            helpText = `
                <p><strong>The browser blocked microphone access.</strong></p>
                <p><strong>How to fix:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Click the 🔒 lock icon</strong> or <strong>camera/microphone icon</strong> in your browser's address bar (next to the URL)</li>
                    <li>Find <strong>"Microphone"</strong> in the permissions list</li>
                    <li>Change it to <strong>"Allow"</strong></li>
                    <li><strong>Refresh this page</strong> (press F5 or click browser refresh)</li>
                </ol>
                <p style="margin-top: 1rem;"><strong>On Mobile:</strong></p>
                <ul style="text-align: left; margin-left: 1rem;">
                    <li>Go to your phone's <strong>Settings</strong></li>
                    <li>Find <strong>Safari</strong> or <strong>Chrome</strong></li>
                    <li>Enable <strong>Microphone</strong> permission for this website</li>
                    <li>Return here and refresh</li>
                </ul>
            `;
        } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
            errorMessage = '🎤 No Microphone Detected';
            helpText = `
                <p><strong>Your device doesn't have a microphone, or it's not connected.</strong></p>
                <p><strong>How to fix:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Connect a microphone or headset</strong></li>
                    <li><strong>Windows:</strong> Right-click speaker icon → Sound settings → Input</li>
                    <li>Make sure microphone is <strong>enabled</strong> and set as <strong>default</strong></li>
                    <li><strong>Refresh this page</strong> (F5)</li>
                </ol>
                <p style="margin-top: 1rem;"><strong>Test your microphone:</strong></p>
                <ul style="text-align: left; margin-left: 1rem;">
                    <li>Windows: Settings → System → Sound → Test your microphone</li>
                    <li>Mac: System Preferences → Sound → Input tab</li>
                </ul>
            `;
        } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
            errorMessage = '⚠️ Microphone In Use';
            helpText = `
                <p><strong>Another application is using your microphone.</strong></p>
                <p><strong>How to fix:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Close other apps</strong> that might be using the microphone:<br>
                        Zoom, Teams, Skype, Discord, OBS, recording software, etc.</li>
                    <li><strong>Windows:</strong> Press <strong>Ctrl+Shift+Esc</strong> to open Task Manager</li>
                    <li>Look for apps with microphone access and close them</li>
                    <li><strong>Refresh this page</strong> (F5)</li>
                </ol>
            `;
        } else if (error.name === 'AbortError') {
            errorMessage = '⚠️ Hardware Error';
            helpText = `
                <p><strong>The microphone couldn't be accessed due to a hardware error.</strong></p>
                <p><strong>How to fix:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Unplug and reconnect</strong> your microphone/headset</li>
                    <li><strong>Restart your browser</strong></li>
                    <li>If using Bluetooth, <strong>disconnect and reconnect</strong></li>
                    <li><strong>Try a different browser</strong> (Chrome, Firefox, Edge)</li>
                    <li>As a last resort, <strong>restart your device</strong></li>
                </ol>
            `;
        } else if (error.name === 'OverconstrainedError') {
            errorMessage = '⚠️ Microphone Configuration Error';
            helpText = `
                <p><strong>Your microphone doesn't support the required settings.</strong></p>
                <p>This is usually a technical issue. Try:</p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Use a different microphone</strong> (built-in or external)</li>
                    <li><strong>Update your browser</strong> to the latest version</li>
                    <li><strong>Try a different browser</strong></li>
                </ol>
            `;
        } else if (error.name === 'SecurityError') {
            errorMessage = '🔒 Security Error';
            helpText = `
                <p><strong>Browser security settings are blocking microphone access.</strong></p>
                <p><strong>How to fix:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li>Make sure you're accessing this page via <strong>HTTPS</strong> (secure connection)</li>
                    <li>Some browsers require <strong>localhost</strong> or <strong>secure HTTPS</strong> for microphone access</li>
                    <li>Check browser settings: Settings → Privacy → Microphone</li>
                    <li>Try using <strong>http://localhost:5000</strong> if on same device</li>
                </ol>
            `;
        } else {
            errorMessage = `❌ Error: ${error.name || 'Unknown'}`;
            helpText = `
                <p><strong>An unexpected error occurred.</strong></p>
                <p><strong>Error details:</strong> ${error.message || 'No details available'}</p>
                <p><strong>General troubleshooting:</strong></p>
                <ol style="text-align: left; margin-left: 1rem;">
                    <li><strong>Refresh the page</strong> (F5) and click "Allow" when prompted</li>
                    <li>Check <strong>browser settings</strong>: Settings → Privacy → Microphone</li>
                    <li>Check <strong>system settings</strong>: Windows Settings → Privacy → Microphone</li>
                    <li><strong>Try a different browser</strong> (Chrome usually works best)</li>
                    <li><strong>Restart your device</strong></li>
                </ol>
            `;
        }
        
        this.addMessage(`
            <p><strong>${errorMessage}</strong></p>
            ${helpText}
            <div style="background: #fef3c7; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem;">
                <p style="margin: 0;"><strong>💡 Still having trouble?</strong></p>
                <p style="margin: 0.5rem 0 0 0;">The app will still work with typed text! Just type your questions in the input box below.</p>
            </div>
        `, 'error');
        
        this.updateStatus('❌ Microphone not available - Use text input', 0);
    }
    
    // Get microphone stream for recording
    getMicrophoneStream() {
        return this.microphoneStream;
    }
    
    // Check if microphone is available
    isMicrophoneAvailable() {
        return this.microphoneGranted;
    }
    
    // Check if camera is available
    isCameraAvailable() {
        return this.cameraGranted;
    }
    
    // Release microphone stream
    releaseMicrophone() {
        if (this.microphoneStream) {
            this.microphoneStream.getTracks().forEach(track => track.stop());
            this.microphoneStream = null;
        }
    }
}

// Create global instance
window.permissionManager = new PermissionManager();
