// Client-Side Camera Capture
// Captures video from the user's device camera (phone/tablet/laptop)

let videoStream = null;
let videoElement = null;
let canvasElement = null;
let captureInterval = null;
const CAPTURE_FPS = 2; // Capture 2 frames per second for analysis

// Initialize camera capture
async function initializeCamera() {
    try {
        console.log('📷 Requesting camera access...');
        
        // Request camera permission with specific constraints
        const constraints = {
            video: {
                facingMode: 'environment', // Use back camera on mobile
                width: { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false
        };
        
        videoStream = await navigator.mediaDevices.getUserMedia(constraints);
        
        console.log('✅ Camera access granted!');
        
        // Get video element
        videoElement = document.getElementById('videoFeed');
        if (!videoElement) {
            console.error('Video element not found!');
            return false;
        }
        
        // Create canvas for capturing frames
        canvasElement = document.createElement('canvas');
        
        // Set video source to the stream
        videoElement.srcObject = videoStream;
        videoElement.play();
        
        // Wait for video to be ready
        videoElement.onloadedmetadata = () => {
            canvasElement.width = videoElement.videoWidth;
            canvasElement.height = videoElement.videoHeight;
            console.log(`📷 Camera initialized: ${canvasElement.width}x${canvasElement.height}`);
            
            // Show success message
            showCameraSuccess();
        };
        
        return true;
        
    } catch (error) {
        console.error('❌ Camera access error:', error);
        showCameraError(error);
        return false;
    }
}

// Capture current frame as base64
function captureFrameBase64() {
    if (!videoElement || !canvasElement || !videoStream) {
        console.error('Camera not initialized');
        return null;
    }
    
    try {
        const context = canvasElement.getContext('2d');
        context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
        
        // Convert to base64 JPEG
        const base64Image = canvasElement.toDataURL('image/jpeg', 0.8);
        // Remove the "data:image/jpeg;base64," prefix
        return base64Image.split(',')[1];
        
    } catch (error) {
        console.error('Frame capture error:', error);
        return null;
    }
}

// Switch between front and back camera (mobile)
async function switchCamera() {
    if (!videoStream) return;
    
    try {
        // Stop current stream
        videoStream.getTracks().forEach(track => track.stop());
        
        // Get current facing mode
        const currentTrack = videoStream.getVideoTracks()[0];
        const currentSettings = currentTrack.getSettings();
        const currentFacingMode = currentSettings.facingMode || 'user';
        
        // Switch to opposite camera
        const newFacingMode = currentFacingMode === 'user' ? 'environment' : 'user';
        
        // Request new stream
        const constraints = {
            video: {
                facingMode: newFacingMode,
                width: { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false
        };
        
        videoStream = await navigator.mediaDevices.getUserMedia(constraints);
        videoElement.srcObject = videoStream;
        
        console.log(`📷 Switched to ${newFacingMode === 'environment' ? 'back' : 'front'} camera`);
        
    } catch (error) {
        console.error('Camera switch error:', error);
        // Try to reinitialize with original camera
        initializeCamera();
    }
}

// Stop camera
function stopCamera() {
    if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        videoStream = null;
        console.log('📷 Camera stopped');
    }
    
    if (captureInterval) {
        clearInterval(captureInterval);
        captureInterval = null;
    }
}

// Show camera success message
function showCameraSuccess() {
    updateStatus('✅ Camera ready - Using your device camera');
}

// Show camera error message
function showCameraError(error) {
    let errorMessage = '';
    let helpText = '';
    
    if (error.name === 'NotAllowedError') {
        errorMessage = 'Camera permission was denied';
        helpText = `
            <strong>How to fix:</strong>
            <ol>
                <li>Click the <strong>🔒 lock icon</strong> or <strong>camera icon</strong> in your browser's address bar</li>
                <li>Change <strong>Camera</strong> permission to <strong>"Allow"</strong></li>
                <li><strong>Refresh</strong> this page (F5)</li>
            </ol>
        `;
    } else if (error.name === 'NotFoundError') {
        errorMessage = 'No camera detected';
        helpText = `
            <strong>Possible issues:</strong>
            <ol>
                <li>Your device doesn't have a camera</li>
                <li>Camera is being used by another application</li>
                <li>Camera drivers are not installed</li>
            </ol>
        `;
    } else if (error.name === 'NotReadableError') {
        errorMessage = 'Camera is in use by another application';
        helpText = `
            <strong>How to fix:</strong>
            <ol>
                <li>Close other apps using the camera</li>
                <li>On mobile: Close other browser tabs</li>
                <li>Refresh this page</li>
            </ol>
        `;
    } else {
        errorMessage = `Camera error: ${error.name}`;
        helpText = `<p>Please try refreshing the page or check browser settings.</p>`;
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant-message';
    messageDiv.style.borderLeft = '4px solid #ef4444';
    messageDiv.innerHTML = `
        <div class="message-icon" style="background: #ef4444;">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="message-content">
            <p><strong>❌ ${errorMessage}</strong></p>
            ${helpText}
        </div>
    `;
    
    const conversationArea = document.getElementById('conversationArea');
    if (conversationArea) {
        conversationArea.appendChild(messageDiv);
        conversationArea.scrollTop = conversationArea.scrollHeight;
    }
    
    updateStatus('❌ Camera permission denied - See instructions above');
}

// Update status text
function updateStatus(message) {
    const statusText = document.getElementById('statusText');
    if (statusText) {
        statusText.textContent = message;
    }
}

// Auto-initialize camera on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('Camera capture module loaded');
    
    // Initialize camera after a short delay
    setTimeout(() => {
        initializeCamera();
    }, 1000);
});

// Export functions for use in other scripts
window.cameraCapture = {
    initialize: initializeCamera,
    captureFrame: captureFrameBase64,
    switchCamera: switchCamera,
    stop: stopCamera,
    isActive: () => videoStream !== null
};
