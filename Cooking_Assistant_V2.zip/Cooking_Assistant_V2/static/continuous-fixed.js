// FIXED Continuous Conversation System for Visually Impaired Users
// Enhanced with better VAD, debugging, and user feedback

// Global variables
let socket = null;
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let continuousMode = false;
let currentStream = null;
let silenceTimer = null;
let audioContext = null;
let analyser = null;
let isProcessing = false;
let isSpeaking = false;
let permissionsGranted = false;
let vadCheckTimer = null;

// IMPROVED Voice Activity Detection Settings
const VAD_CHECK_INTERVAL = 50; // Check every 50ms (more responsive)
const SILENCE_DURATION = 2000; // 2 seconds of silence to auto-stop (was too short)
const VOLUME_THRESHOLD = 0.02; // Increased threshold for better voice detection
const MIN_RECORDING_DURATION = 500; // Minimum 0.5 seconds before stopping

// Recording timing
let recordingStartTime = 0;

// DOM Elements
const continuousBtn = document.getElementById('continuousBtn');
const conversationArea = document.getElementById('conversationArea');
const statusText = document.getElementById('statusText');
const includeVisionCheck = document.getElementById('includeVisionCheck');
const ttsAudio = document.getElementById('ttsAudio');

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('🎤 Continuous conversation system initialized (FIXED VERSION)');
    
    // Initialize WebSocket
    initializeWebSocket();
    
    // Continuous mode button
    if (continuousBtn) {
        continuousBtn.addEventListener('click', toggleContinuousMode);
        console.log('✅ Continuous button event listener attached');
    }
    
    // Keyboard shortcut
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            toggleContinuousMode();
        }
    });
    
    // Handle page unload
    window.addEventListener('beforeunload', () => {
        if (continuousMode) {
            stopContinuousMode();
        }
        if (socket) {
            socket.disconnect();
        }
    });
});

// Initialize WebSocket connection
function initializeWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;
    
    console.log('🔌 Connecting to WebSocket:', wsUrl);
    
    socket = io(wsUrl, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionAttempts: 5
    });
    
    socket.on('connect', () => {
        console.log('✅ WebSocket connected');
        updateStatus('Connected - Ready to start');
        if (continuousBtn) {
            continuousBtn.disabled = false;
        }
    });
    
    socket.on('disconnect', () => {
        console.log('❌ WebSocket disconnected');
        updateStatus('Disconnected - Reconnecting...');
        if (continuousMode) {
            stopContinuousMode();
        }
    });
    
    socket.on('connection_status', (data) => {
        console.log('📡 Connection status:', data);
    });
    
    socket.on('user_message', (data) => {
        console.log('👤 User message received:', data.text);
        addMessage(data.text, true, data.timestamp);
    });
    
    socket.on('assistant_message', (data) => {
        console.log('🤖 Assistant message received:', data.text.substring(0, 50) + '...');
        addMessage(data.text, false, data.timestamp);
        if (data.speak && !isSpeaking) {
            speakText(data.text);
        }
    });
    
    socket.on('processing_status', (data) => {
        console.log('⚙️ Processing status:', data.status);
        updateProcessingStatus(data.status);
    });
    
    socket.on('error', (data) => {
        console.error('❌ Socket error:', data);
        updateStatus(`Error: ${data.message}`, 5000);
        addMessage(`Error: ${data.message}`, false);
    });
}

// Update processing status
function updateProcessingStatus(status) {
    isProcessing = status !== 'ready';
    
    switch (status) {
        case 'transcribing':
            updateStatus('🎤 Transcribing your speech...', 0);
            break;
        case 'thinking':
            updateStatus('🤔 AI is thinking...', 0);
            break;
        case 'ready':
            if (continuousMode) {
                updateStatus('🎤 Listening - Speak naturally', 0);
            } else {
                updateStatus('Ready');
            }
            break;
    }
}

// Start Continuous Conversation Mode
async function startContinuousMode() {
    console.log('🚀 Starting continuous mode...');
    
    if (continuousMode) {
        console.log('⚠️ Already in continuous mode');
        return;
    }
    
    // Check microphone permission
    if (window.permissionManager && !window.permissionManager.isMicrophoneAvailable()) {
        console.log('🎤 Requesting microphone permission...');
        const granted = await window.permissionManager.requestMicrophone();
        if (!granted) {
            console.error('❌ Microphone permission denied');
            alert('Microphone permission is required for continuous conversation mode.');
            return;
        }
    }
    
    try {
        console.log('🎤 Requesting microphone access...');
        
        // Request microphone with optimal settings
        currentStream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                sampleRate: 16000
            }
        });
        
        console.log('✅ Microphone stream obtained');
        
        // Initialize audio context for Voice Activity Detection
        console.log('🔊 Initializing audio context...');
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 2048;
        analyser.smoothingTimeConstant = 0.8;
        
        const source = audioContext.createMediaStreamSource(currentStream);
        source.connect(analyser);
        
        console.log('✅ Audio context initialized');
        
        // Set continuous mode active
        continuousMode = true;
        
        // Update UI
        continuousBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Listening';
        continuousBtn.classList.add('recording');
        
        // Notify server
        if (socket && socket.connected) {
            socket.emit('start_continuous_mode');
            console.log('📡 Sent start_continuous_mode to server');
        }
        
        // Show success message
        addMessage('✅ Continuous listening started! Speak naturally - I\'ll detect your voice automatically.', false);
        updateStatus('🎤 Listening - Speak naturally', 0);
        
        // Start the listening loop
        console.log('👂 Starting voice detection loop...');
        startListeningLoop();
        
    } catch (error) {
        console.error('❌ Failed to start continuous mode:', error);
        alert(`Failed to start continuous mode: ${error.message}`);
        continuousMode = false;
    }
}

// Stop Continuous Conversation Mode
function stopContinuousMode() {
    console.log('🛑 Stopping continuous mode...');
    
    if (!continuousMode) {
        console.log('⚠️ Not in continuous mode');
        return;
    }
    
    continuousMode = false;
    
    // Clear VAD timer
    if (vadCheckTimer) {
        clearTimeout(vadCheckTimer);
        vadCheckTimer = null;
    }
    
    // Stop recording if active
    if (isRecording) {
        console.log('⏹️ Stopping active recording...');
        stopRecording();
    }
    
    // Stop audio stream
    if (currentStream) {
        console.log('🔇 Releasing microphone stream...');
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
    }
    
    // Close audio context
    if (audioContext) {
        console.log('🔊 Closing audio context...');
        audioContext.close();
        audioContext = null;
    }
    
    // Update UI
    continuousBtn.innerHTML = '<i class="fas fa-microphone"></i> Start Continuous Conversation';
    continuousBtn.classList.remove('recording');
    
    // Notify server
    if (socket && socket.connected) {
        socket.emit('stop_continuous_mode');
        console.log('📡 Sent stop_continuous_mode to server');
    }
    
    addMessage('✅ Continuous listening stopped.', false);
    updateStatus('Continuous listening stopped');
    
    console.log('✅ Continuous mode stopped successfully');
}

// Voice Activity Detection Loop
function startListeningLoop() {
    if (!continuousMode) {
        console.log('⚠️ Listening loop stopped (mode inactive)');
        return;
    }
    
    const checkVoiceActivity = () => {
        if (!continuousMode) {
            console.log('👂 VAD loop ending (continuous mode off)');
            return;
        }
        
        // Don't record while processing or speaking
        if (isProcessing) {
            //console.log('⏸️ Skipping VAD check (processing)');
            vadCheckTimer = setTimeout(checkVoiceActivity, VAD_CHECK_INTERVAL);
            return;
        }
        
        if (isSpeaking) {
            //console.log('⏸️ Skipping VAD check (speaking)');
            vadCheckTimer = setTimeout(checkVoiceActivity, VAD_CHECK_INTERVAL);
            return;
        }
        
        // Get current audio volume
        const volume = getAudioVolume();
        
        // Voice detected!
        if (volume > VOLUME_THRESHOLD) {
            if (!isRecording) {
                console.log(`🎤 VOICE DETECTED! Volume: ${volume.toFixed(4)} (threshold: ${VOLUME_THRESHOLD})`);
                startRecording();
                updateStatus('🔴 Recording...', 0);
            }
            
            // Reset silence timer
            if (silenceTimer) {
                clearTimeout(silenceTimer);
                silenceTimer = null;
            }
        } 
        // Silence detected
        else {
            if (isRecording && !silenceTimer) {
                const recordingDuration = Date.now() - recordingStartTime;
                
                // Only stop if we've recorded for minimum duration
                if (recordingDuration >= MIN_RECORDING_DURATION) {
                    console.log(`🤫 Silence detected, starting ${SILENCE_DURATION}ms timer...`);
                    
                    silenceTimer = setTimeout(() => {
                        if (isRecording) {
                            console.log('⏹️ Silence timer expired, stopping recording');
                            stopRecording();
                        }
                        silenceTimer = null;
                    }, SILENCE_DURATION);
                }
            }
        }
        
        // Continue loop
        vadCheckTimer = setTimeout(checkVoiceActivity, VAD_CHECK_INTERVAL);
    };
    
    // Start the loop
    checkVoiceActivity();
}

// Get current audio volume level
function getAudioVolume() {
    if (!analyser) return 0;
    
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);
    
    // Calculate RMS (Root Mean Square) for better volume detection
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
        const normalized = dataArray[i] / 255;
        sum += normalized * normalized;
    }
    const rms = Math.sqrt(sum / dataArray.length);
    
    return rms;
}

// Start Recording
function startRecording() {
    if (isRecording || !currentStream || isProcessing || isSpeaking) {
        console.log('⚠️ Cannot start recording:', { isRecording, hasStream: !!currentStream, isProcessing, isSpeaking });
        return;
    }
    
    try {
        console.log('🎙️ Starting MediaRecorder...');
        
        audioChunks = [];
        recordingStartTime = Date.now();
        
        // Try different MIME types for compatibility
        let mimeType = 'audio/webm';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
            console.log('⚠️ audio/webm not supported, trying audio/mp4');
            mimeType = 'audio/mp4';
        }
        if (!MediaRecorder.isTypeSupported(mimeType)) {
            console.log('⚠️ audio/mp4 not supported, using default');
            mimeType = '';
        }
        
        const options = mimeType ? { mimeType } : {};
        mediaRecorder = new MediaRecorder(currentStream, options);
        
        console.log(`📼 MediaRecorder created with mimeType: ${mimeType || 'default'}`);
        
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                audioChunks.push(event.data);
                console.log(`📦 Audio chunk received: ${event.data.size} bytes`);
            }
        };
        
        mediaRecorder.onstop = async () => {
            const duration = Date.now() - recordingStartTime;
            console.log(`⏹️ Recording stopped. Duration: ${duration}ms, Chunks: ${audioChunks.length}`);
            
            if (audioChunks.length > 0) {
                const audioBlob = new Blob(audioChunks, { type: mimeType || 'audio/webm' });
                console.log(`🎵 Audio blob created: ${audioBlob.size} bytes`);
                await sendAudioToServer(audioBlob);
            } else {
                console.log('⚠️ No audio chunks to process');
            }
        };
        
        mediaRecorder.onerror = (error) => {
            console.error('❌ MediaRecorder error:', error);
        };
        
        mediaRecorder.start();
        isRecording = true;
        
        console.log('✅ Recording started successfully');
        
    } catch (error) {
        console.error('❌ Recording error:', error);
        updateStatus('⚠️ Recording failed', 3000);
    }
}

// Stop Recording
function stopRecording() {
    if (!isRecording || !mediaRecorder) {
        console.log('⚠️ Cannot stop recording: not recording');
        return;
    }
    
    try {
        console.log('🛑 Stopping recorder...');
        mediaRecorder.stop();
        isRecording = false;
        updateStatus('🎤 Listening - Speak naturally', 0);
        
    } catch (error) {
        console.error('❌ Stop recording error:', error);
    }
}

// Send audio to server
async function sendAudioToServer(audioBlob) {
    if (!socket || !socket.connected) {
        console.error('❌ Cannot send audio: socket not connected');
        updateStatus('⚠️ Not connected to server', 3000);
        return;
    }
    
    if (!continuousMode) {
        console.log('⚠️ Not sending audio: continuous mode inactive');
        return;
    }
    
    console.log('📤 Sending audio to server...');
    
    // Convert blob to base64
    const reader = new FileReader();
    reader.onloadend = () => {
        const base64Audio = reader.result;
        console.log(`📨 Audio converted to base64: ${base64Audio.length} chars`);
        
        // Prepare data
        const data = {
            audio: base64Audio,
            include_vision: includeVisionCheck.checked
        };
        
        // Add camera frame if vision enabled
        if (includeVisionCheck.checked && window.cameraCapture && window.cameraCapture.isActive()) {
            console.log('📷 Adding camera frame to request...');
            const frameBase64 = window.cameraCapture.captureFrame();
            if (frameBase64) {
                data.image = frameBase64;
                console.log('✅ Camera frame added');
            }
        }
        
        // Send via WebSocket
        console.log('📡 Emitting voice_input event...');
        socket.emit('voice_input', data);
        console.log('✅ Audio sent to server');
    };
    
    reader.onerror = (error) => {
        console.error('❌ FileReader error:', error);
    };
    
    reader.readAsDataURL(audioBlob);
}

// Text-to-Speech
async function speakText(text) {
    if (isSpeaking) {
        console.log('⏸️ Already speaking, skipping...');
        return;
    }
    
    console.log(`🔊 Speaking: "${text.substring(0, 50)}..."`);
    
    try {
        isSpeaking = true;
        updateStatus('🔊 Speaking...', 0);
        
        const response = await fetch('/text_to_speech', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (data.success && data.audio) {
            return new Promise((resolve) => {
                const audioSrc = `data:audio/mp3;base64,${data.audio}`;
                ttsAudio.src = audioSrc;
                
                ttsAudio.onended = () => {
                    console.log('✅ TTS playback ended');
                    isSpeaking = false;
                    if (continuousMode) {
                        updateStatus('🎤 Listening - Speak naturally', 0);
                    }
                    resolve();
                };
                
                ttsAudio.onerror = (error) => {
                    console.error('❌ TTS playback error:', error);
                    isSpeaking = false;
                    resolve();
                };
                
                ttsAudio.play();
                console.log('▶️ TTS playback started');
            });
        } else {
            console.error('❌ TTS failed:', data);
            isSpeaking = false;
        }
    } catch (error) {
        console.error('❌ TTS error:', error);
        isSpeaking = false;
    }
}

// Add message to conversation
function addMessage(content, isUser = false, timestamp = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'assistant-message'}`;
    
    const iconDiv = document.createElement('div');
    iconDiv.className = 'message-icon';
    iconDiv.innerHTML = isUser ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    let formattedContent = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');
    
    contentDiv.innerHTML = `<p>${formattedContent}</p>`;
    
    if (timestamp) {
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = new Date(timestamp).toLocaleTimeString();
        contentDiv.appendChild(timeDiv);
    }
    
    messageDiv.appendChild(iconDiv);
    messageDiv.appendChild(contentDiv);
    conversationArea.appendChild(messageDiv);
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

// Update status
function updateStatus(message, duration = 0) {
    if (statusText) {
        statusText.textContent = message;
        if (duration > 0) {
            setTimeout(() => {
                if (continuousMode) {
                    statusText.textContent = '🎤 Listening - Speak naturally';
                } else {
                    statusText.textContent = 'Ready';
                }
            }, duration);
        }
    }
}

// Toggle continuous mode
function toggleContinuousMode() {
    console.log('🔄 Toggle continuous mode. Current:', continuousMode);
    if (continuousMode) {
        stopContinuousMode();
    } else {
        startContinuousMode();
    }
}

// Export functions
window.continuousConversation = {
    start: startContinuousMode,
    stop: stopContinuousMode,
    isActive: () => continuousMode,
    toggle: toggleContinuousMode
};

console.log('✅ Continuous conversation module loaded (FIXED VERSION)');
