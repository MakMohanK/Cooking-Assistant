// Cooking Assistant for Visually Impaired - Client-Side JavaScript
// Updated to use client-side camera capture from remote devices

// Global variables
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let currentStream = null;

// DOM Elements
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const voiceBtn = document.getElementById('voiceBtn');
const conversationArea = document.getElementById('conversationArea');
const analyzeBtn = document.getElementById('analyzeBtn');
const switchCameraBtn = document.getElementById('switchCameraBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');
const includeVisionCheck = document.getElementById('includeVisionCheck');
const autoSpeakCheck = document.getElementById('autoSpeakCheck');
const statusText = document.getElementById('statusText');
const loadingOverlay = document.getElementById('loadingOverlay');
const loadingText = document.getElementById('loadingText');
const ttsAudio = document.getElementById('ttsAudio');
const cameraStatus = document.getElementById('cameraStatus');

// Quick action buttons
const quickBtns = document.querySelectorAll('.quick-btn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Cooking Assistant initialized');
    
    // Event listeners
    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
    
    voiceBtn.addEventListener('mousedown', startRecording);
    voiceBtn.addEventListener('mouseup', stopRecording);
    voiceBtn.addEventListener('touchstart', startRecording);
    voiceBtn.addEventListener('touchend', stopRecording);
    
    analyzeBtn.addEventListener('click', analyzeScene);
    if (switchCameraBtn) {
        switchCameraBtn.addEventListener('click', switchCamera);
    }
    clearHistoryBtn.addEventListener('click', clearHistory);
    
    // Quick actions
    quickBtns.forEach(btn => {
        btn.addEventListener('click', () => handleQuickAction(btn.dataset.action));
    });
    
    // Request microphone permission on first interaction
    voiceBtn.addEventListener('click', requestMicrophonePermission, { once: true });
    
    // Update camera status when camera is ready
    setTimeout(() => {
        if (window.cameraCapture && window.cameraCapture.isActive()) {
            updateCameraStatus('live');
        }
    }, 2000);
});

// Update camera status indicator
function updateCameraStatus(status) {
    if (!cameraStatus) return;
    
    if (status === 'live') {
        cameraStatus.innerHTML = '<i class="fas fa-circle"></i> Live';
        cameraStatus.style.background = 'rgba(16, 185, 129, 0.9)';
    } else if (status === 'error') {
        cameraStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error';
        cameraStatus.style.background = 'rgba(239, 68, 68, 0.9)';
    } else {
        cameraStatus.innerHTML = '<i class="fas fa-circle"></i> Initializing...';
        cameraStatus.style.background = 'rgba(245, 158, 11, 0.9)';
    }
}

// Switch between front and back camera
function switchCamera() {
    if (window.cameraCapture) {
        window.cameraCapture.switchCamera();
        updateStatus('Switching camera...', 2000);
    }
}

// Show/Hide Loading
function showLoading(message = 'Processing...') {
    loadingText.textContent = message;
    loadingOverlay.style.display = 'flex';
}

function hideLoading() {
    loadingOverlay.style.display = 'none';
}

// Update Status
function updateStatus(message, duration = 3000) {
    statusText.textContent = message;
    if (duration > 0) {
        setTimeout(() => {
            statusText.textContent = 'Ready';
        }, duration);
    }
}

// Add Message to Conversation
function addMessage(content, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'assistant-message'}`;
    
    const iconDiv = document.createElement('div');
    iconDiv.className = 'message-icon';
    iconDiv.innerHTML = isUser ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    // Convert markdown-style formatting to HTML
    let formattedContent = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');
    
    contentDiv.innerHTML = `<p>${formattedContent}</p>`;
    
    messageDiv.appendChild(iconDiv);
    messageDiv.appendChild(contentDiv);
    conversationArea.appendChild(messageDiv);
    
    // Scroll to bottom
    conversationArea.scrollTop = conversationArea.scrollHeight;
    
    // Auto-speak if enabled and it's an assistant message
    if (!isUser && autoSpeakCheck.checked) {
        speakText(content);
    }
}

// Send Message
async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Add user message to UI
    addMessage(message, true);
    messageInput.value = '';
    
    showLoading('Thinking...');
    
    try {
        const includeVision = includeVisionCheck.checked;
        
        // Prepare request data
        const requestData = {
            message: message,
            include_vision: includeVision
        };
        
        // If vision is included, capture frame from client camera
        if (includeVision && window.cameraCapture) {
            const frameBase64 = window.cameraCapture.captureFrame();
            if (frameBase64) {
                requestData.image = frameBase64;
            }
        }
        
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });
        
        const data = await response.json();
        hideLoading();
        
        if (data.success) {
            addMessage(data.response, false);
            updateStatus('Response received');
        } else {
            addMessage(`Error: ${data.error}`, false);
            updateStatus('Error occurred', 5000);
        }
    } catch (error) {
        hideLoading();
        addMessage(`Error: ${error.message}`, false);
        updateStatus('Connection error', 5000);
    }
}

// Analyze Scene
async function analyzeScene() {
    showLoading('Analyzing scene from YOUR camera...');
    
    try {
        // Capture frame from client-side camera
        if (!window.cameraCapture || !window.cameraCapture.isActive()) {
            throw new Error('Camera not initialized. Please allow camera access.');
        }
        
        const frameBase64 = window.cameraCapture.captureFrame();
        if (!frameBase64) {
            throw new Error('Failed to capture frame from camera');
        }
        
        // Send to server for analysis
        const analyzeResponse = await fetch('/analyze_scene', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                image: frameBase64,
                query: 'What do you see in this cooking scene? Describe ingredients, cooking activity, and any safety concerns.'
            })
        });
        
        const analyzeData = await analyzeResponse.json();
        hideLoading();
        
        if (analyzeData.success) {
            addMessage('🔍 Scene Analysis (from YOUR camera):', true);
            addMessage(analyzeData.analysis, false);
            updateStatus('Scene analyzed');
        } else {
            addMessage(`Analysis error: ${analyzeData.error}`, false);
            updateStatus('Analysis failed', 5000);
        }
    } catch (error) {
        hideLoading();
        addMessage(`Error: ${error.message}`, false);
        updateStatus('Analysis error', 5000);
    }
}

// Request Microphone Permission
async function requestMicrophonePermission() {
    // Use centralized permission manager
    if (window.permissionManager) {
        const granted = await window.permissionManager.requestMicrophone();
        if (granted) {
            currentStream = window.permissionManager.getMicrophoneStream();
        updateStatus('Microphone ready');
    }
        return granted;
}

    // Fallback
    try {
        currentStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        updateStatus('Microphone ready');
        return true;
    } catch (error) {
        console.error('Microphone permission denied:', error);
        if (window.permissionManager) {
            window.permissionManager.showMicrophoneError(error);
        } else {
            alert('Microphone access is required for voice input. Please allow microphone access.');
        }
        return false;
    }
}

// Start Recording
async function startRecording(e) {
        e.preventDefault();

    if (isRecording) return;
    
    try {
        // Check if we have microphone permission
        if (!currentStream) {
            if (window.permissionManager && window.permissionManager.isMicrophoneAvailable()) {
                currentStream = window.permissionManager.getMicrophoneStream();
    }
    
            if (!currentStream) {
                const granted = await requestMicrophonePermission();
                if (!granted) return;
    }
        }
        
        // If still no stream, request it
        if (!currentStream) {
            currentStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
});
        }

        audioChunks = [];
        mediaRecorder = new MediaRecorder(currentStream);
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            await transcribeAudio(audioBlob);
        };
        
        mediaRecorder.start();
        isRecording = true;
        voiceBtn.classList.add('recording');
        updateStatus('Recording... Release to stop', 0);
        
    } catch (error) {
        console.error('Recording error:', error);
        if (window.permissionManager) {
            window.permissionManager.showMicrophoneError(error);
        } else {
            alert('Failed to start recording. Please check microphone permissions.');
        }
    }
}

// Stop Recording
function stopRecording(e) {
    e.preventDefault();
    
    if (!isRecording || !mediaRecorder) return;
    
    mediaRecorder.stop();
    isRecording = false;
    voiceBtn.classList.remove('recording');
    updateStatus('Processing speech...');
}

// Transcribe Audio
async function transcribeAudio(audioBlob) {
    showLoading('Transcribing speech...');
    
    try {
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.wav');
        
        const response = await fetch('/speech_to_text', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        hideLoading();
        
        if (data.success && data.text) {
            messageInput.value = data.text;
            updateStatus('Speech transcribed');
            // Automatically send the message
            sendMessage();
        } else {
            updateStatus('Transcription failed', 5000);
            addMessage(`Transcription error: ${data.error || 'Unknown error'}`, false);
        }
    } catch (error) {
        hideLoading();
        updateStatus('Transcription error', 5000);
        addMessage(`Error: ${error.message}`, false);
    }
}

// Speak Text (TTS)
async function speakText(text) {
    try {
        const response = await fetch('/text_to_speech', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (data.success && data.audio) {
            const audioSrc = `data:audio/mp3;base64,${data.audio}`;
            ttsAudio.src = audioSrc;
            ttsAudio.play();
        }
    } catch (error) {
        console.error('TTS error:', error);
    }
}

// Handle Quick Actions
function handleQuickAction(action) {
    let message = '';
    
    switch (action) {
        case 'recipe':
            message = 'Can you help me with a recipe? What would you like to cook?';
            addMessage('📖 Recipe Assistant activated', true);
            addMessage(message, false);
            break;
            
        case 'ingredients':
            message = 'Let me identify the ingredients in front of you using YOUR camera.';
            addMessage('🥕 Ingredient Identification', true);
            includeVisionCheck.checked = true;
            analyzeScene();
            break;
            
        case 'safety':
            message = 'Let me check for any safety concerns using YOUR camera.';
            addMessage('⚠️ Safety Check', true);
            includeVisionCheck.checked = true;
            // Analyze with safety focus
            analyzeSafety();
            break;
            
        case 'timer':
            message = 'What would you like to set a timer for? Tell me the duration and what you\'re cooking.';
            addMessage('⏰ Timer Assistant', true);
            addMessage(message, false);
            break;
    }
}

// Analyze Safety
async function analyzeSafety() {
    showLoading('Checking safety from YOUR camera...');
    
    try {
        if (!window.cameraCapture || !window.cameraCapture.isActive()) {
            throw new Error('Camera not initialized');
        }
        
        const frameBase64 = window.cameraCapture.captureFrame();
        if (!frameBase64) {
            throw new Error('Failed to capture frame');
        }
        
        const analyzeResponse = await fetch('/analyze_scene', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                image: frameBase64,
                query: 'Perform a safety check of this cooking scene. Identify any hot surfaces, sharp objects, spills, fire hazards, or other safety concerns. Be very specific about locations and urgency.'
            })
        });
        
        const analyzeData = await analyzeResponse.json();
        hideLoading();
        
        if (analyzeData.success) {
            addMessage(analyzeData.analysis, false);
            updateStatus('Safety check complete');
        } else {
            addMessage(`Safety check error: ${analyzeData.error}`, false);
        }
    } catch (error) {
        hideLoading();
        addMessage(`Error: ${error.message}`, false);
    }
}

// Clear Conversation History
async function clearHistory() {
    if (!confirm('Are you sure you want to clear the conversation history?')) {
        return;
    }
    
    try {
        const response = await fetch('/clear_history', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Clear UI
            conversationArea.innerHTML = `
                <div class="message assistant-message">
                    <div class="message-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="message-content">
                        <p>Conversation history cleared. How can I help you?</p>
                    </div>
                </div>
            `;
            updateStatus('History cleared');

            // Speak the message if auto-speak is enabled
            if (autoSpeakCheck.checked) {
                speakText('Conversation history cleared. How can I help you?');
            }
        }
    } catch (error) {
        console.error('Clear history error:', error);
        updateStatus('Failed to clear history', 5000);
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K to focus input
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        messageInput.focus();
    }
    
    // Ctrl/Cmd + Enter to analyze scene
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        analyzeScene();
    }
});
