// Continuous Conversation System for Visually Impaired Users
// Real-time STT and TTS with WebSocket communication

// Global variables
let socket = null;
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let continuousMode = false;
let currentStream = null;
let silenceTimer = null;
let audioContext = null;
let analyser = null;
let silenceThreshold = -50; // dB
let silenceDelay = 1500; // ms
let isProcessing = false;
let isSpeaking = false;
let permissionsGranted = false;

// Voice Activity Detection
const VAD_CHECK_INTERVAL = 100; // ms
const SILENCE_DURATION = 1500; // ms of silence to auto-stop
const VOLUME_THRESHOLD = 0.01; // Minimum volume to consider as speech

// DOM Elements
const continuousBtn = document.getElementById('continuousBtn');
const conversationArea = document.getElementById('conversationArea');
const statusText = document.getElementById('statusText');
const includeVisionCheck = document.getElementById('includeVisionCheck');
const ttsAudio = document.getElementById('ttsAudio');

// Request permissions immediately on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('Continuous conversation system initialized');
    
    // Initialize WebSocket
    initializeWebSocket();
    
    // Continuous mode button
    if (continuousBtn) {
        continuousBtn.addEventListener('click', toggleContinuousMode);
    }
    
    // Request permissions proactively
    requestPermissionsProactively();
    
    // Handle page unload
    window.addEventListener('beforeunload', () => {
        if (continuousMode) {
            stopContinuousMode();
        }
        if (socket) {
            socket.disconnect();
        }
    });
    
    // Keyboard shortcut: Space bar to toggle continuous mode
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            toggleContinuousMode();
        }
    });
});

// Request permissions proactively
async function requestPermissionsProactively() {
    // Use the centralized permission manager
    if (window.permissionManager) {
        const granted = await window.permissionManager.requestMicrophone();
        permissionsGranted = granted;
        return granted;
    }

    // Fallback if permission manager not loaded
    try {
        console.log('🎤 Requesting microphone permission (fallback)...');
        updateStatus('Checking permissions...', 0);
        
        // Request microphone permission
        const stream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            },
            video: false
        });
        
        console.log('✅ Microphone permission granted!');
        permissionsGranted = true;
        
        // Stop the stream for now (we'll request again when needed)
        stream.getTracks().forEach(track => track.stop());
        
        // Update UI
        updateStatus('✅ Microphone ready - Click to start conversation');
        
        // Show success message
        showPermissionSuccess();
        
        return true;

    } catch (error) {
        console.error('❌ Permission denied or error:', error);
        permissionsGranted = false;
        
        // Show detailed error using permission manager if available
        if (window.permissionManager) {
            window.permissionManager.showMicrophoneError(error);
        } else {
        showPermissionError(error);
    }

        return false;
}
}

// Show permission success message
function showPermissionSuccess() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant-message';
    messageDiv.innerHTML = `
        <div class="message-icon">
            <i class="fas fa-check-circle" style="color: #10b981;"></i>
        </div>
        <div class="message-content">
            <p><strong>✅ Microphone Permission Granted!</strong></p>
            <p>You're all set! Click the green "Start Continuous Conversation" button above to begin hands-free cooking assistance.</p>
        </div>
    `;
    conversationArea.appendChild(messageDiv);
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

// Show permission error message
function showPermissionError(error) {
    let errorMessage = '';
    let helpText = '';
    
    if (error.name === 'NotAllowedError') {
        errorMessage = 'Microphone permission was denied';
        helpText = `
            <strong>How to fix:</strong>
            <ol>
                <li>Click the <strong>🔒 lock icon</strong> or <strong>camera icon</strong> in your browser's address bar</li>
                <li>Change <strong>Microphone</strong> permission to <strong>"Allow"</strong></li>
                <li><strong>Refresh</strong> this page (F5)</li>
            </ol>
        `;
    } else if (error.name === 'NotFoundError') {
        errorMessage = 'No microphone detected';
        helpText = `
            <strong>How to fix:</strong>
            <ol>
                <li>Connect a microphone or headset</li>
                <li>Check Windows Sound settings (right-click speaker icon → Sound settings)</li>
                <li>Make sure microphone is enabled and set as default</li>
                <li>Refresh this page (F5)</li>
            </ol>
        `;
    } else if (error.name === 'NotReadableError') {
        errorMessage = 'Microphone is in use by another application';
        helpText = `
            <strong>How to fix:</strong>
            <ol>
                <li>Close other apps that might be using the microphone (Zoom, Teams, Skype, Discord)</li>
                <li>Press Ctrl+Shift+Esc to open Task Manager</li>
                <li>Close any recording software</li>
                <li>Refresh this page (F5)</li>
            </ol>
        `;
    } else {
        errorMessage = `Permission error: ${error.name}`;
        helpText = `
            <strong>General troubleshooting:</strong>
            <ol>
                <li>Refresh the page (F5) and click "Allow" when prompted</li>
                <li>Check browser settings: Settings → Privacy → Microphone</li>
                <li>Make sure Windows allows microphone access: Settings → Privacy → Microphone</li>
            </ol>
        `;
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant-message';
    messageDiv.style.borderLeft = '4px solid #ef4444';
    messageDiv.innerHTML = `
        <div class="message-icon" style="background: #ef4444;">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="message-content">
            <p><strong>❌ ${errorMessage}</strong></p>
            ${helpText}
            <p style="margin-top: 1rem;"><strong>Need more help?</strong> Check the <code>MICROPHONE_FIX_GUIDE.md</code> file for detailed solutions.</p>
        </div>
    `;
    conversationArea.appendChild(messageDiv);
    conversationArea.scrollTop = conversationArea.scrollHeight;
    
    updateStatus('❌ Microphone permission denied - See instructions above');
    
    // Disable continuous button
    if (continuousBtn) {
        continuousBtn.disabled = true;
        continuousBtn.style.opacity = '0.5';
        continuousBtn.style.cursor = 'not-allowed';
    }
}

// Initialize WebSocket connection
function initializeWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;
    
    socket = io(wsUrl, {
        transports: ['websocket', 'polling']
    });
    
    socket.on('connect', () => {
        console.log('✅ Connected to server');
        if (permissionsGranted) {
            updateStatus('Connected - Ready to start');
        }
        if (continuousBtn) {
            continuousBtn.disabled = false;
        }
    });
    
    socket.on('disconnect', () => {
        console.log('❌ Disconnected from server');
        updateStatus('Disconnected - Reconnecting...');
        if (continuousMode) {
            stopContinuousMode();
        }
    });
    
    socket.on('connection_status', (data) => {
        console.log('Connection status:', data);
    });
    
    socket.on('user_message', (data) => {
        addMessage(data.text, true, data.timestamp);
    });
    
    socket.on('assistant_message', (data) => {
        addMessage(data.text, false, data.timestamp);
        if (data.speak && !isSpeaking) {
            speakText(data.text);
        }
    });
    
    socket.on('processing_status', (data) => {
        updateProcessingStatus(data.status);
    });
    
    socket.on('error', (data) => {
        console.error('Socket error:', data);
        updateStatus(`Error: ${data.message}`, 5000);
    });
}

// Update processing status
function updateProcessingStatus(status) {
    isProcessing = status !== 'ready';
    
    switch (status) {
        case 'transcribing':
            updateStatus('🎤 Listening...', 0);
            break;
        case 'thinking':
            updateStatus('🤔 Thinking...', 0);
            break;
        case 'ready':
            if (continuousMode) {
                updateStatus('🎤 Listening - Speak naturally', 0);
            } else {
                updateStatus('Ready');
            }
            break;
    }
}
// Start Continuous Conversation Mode
async function startContinuousMode() {
    if (continuousMode) return;
    
    // Check if permissions already granted
    if (!permissionsGranted) {
        try {
            await requestPermissionsProactively();
            if (!permissionsGranted) {
                alert('Microphone permission is required for continuous conversation mode. Please allow microphone access and try again.');
                return;
            }
        } catch (error) {
            alert('Unable to access microphone. Please check your browser settings and try again.');
            return;
        }
    }
    
    try {
        // Request microphone permission
        currentStream = await navigator.mediaDevices.getUserMedia({ 
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        });
        
        // Initialize audio context for VAD
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        const source = audioContext.createMediaStreamSource(currentStream);
        source.connect(analyser);
        analyser.fftSize = 512;
        
        continuousMode = true;
        
        // Update UI
        continuousBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Listening';
        continuousBtn.classList.add('recording');
        
        // Notify server
        socket.emit('start_continuous_mode');
        
        updateStatus('🎤 Continuous listening active - Speak naturally', 0);
        
        // Start listening loop
        startListeningLoop();
        
    } catch (error) {
        console.error('Failed to start continuous mode:', error);
        showPermissionError(error);
    }
}

// Stop Continuous Conversation Mode
function stopContinuousMode() {
    if (!continuousMode) return;
    
    continuousMode = false;
    
    // Stop recording if active
    if (isRecording) {
        stopRecording();
    }
    
    // Stop audio stream
    if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
        currentStream = null;
    }
    
    // Close audio context
    if (audioContext) {
        audioContext.close();
        audioContext = null;
    }
    
    // Update UI
    continuousBtn.innerHTML = '<i class="fas fa-microphone"></i> Start Continuous Conversation';
    continuousBtn.classList.remove('recording');
    
    // Notify server
    socket.emit('stop_continuous_mode');
    
    updateStatus('Continuous listening stopped');
}

// Listening Loop with Voice Activity Detection
function startListeningLoop() {
    if (!continuousMode) return;
    
    // Check for voice activity
    const checkVoiceActivity = () => {
        if (!continuousMode || isProcessing || isSpeaking) {
            setTimeout(checkVoiceActivity, VAD_CHECK_INTERVAL);
            return;
        }
        
        const volume = getAudioVolume();
        
        if (volume > VOLUME_THRESHOLD) {
            // Voice detected - start recording
            if (!isRecording) {
                startRecording();
            }
            // Reset silence timer
            if (silenceTimer) {
                clearTimeout(silenceTimer);
                silenceTimer = null;
            }
        } else {
            // Silence detected
            if (isRecording && !silenceTimer) {
                // Start silence timer
                silenceTimer = setTimeout(() => {
                    if (isRecording) {
                        stopRecording();
                    }
                    silenceTimer = null;
                }, SILENCE_DURATION);
            }
        }
        
        setTimeout(checkVoiceActivity, VAD_CHECK_INTERVAL);
};

    checkVoiceActivity();
}

// Get current audio volume
function getAudioVolume() {
    if (!analyser) return 0;
    
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);
    
    // Calculate average volume
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
    }
    const average = sum / dataArray.length / 255;
    
    return average;
}

// Start Recording
function startRecording() {
    if (isRecording || !currentStream || isProcessing || isSpeaking) return;
    
    try {
        audioChunks = [];
        mediaRecorder = new MediaRecorder(currentStream);
        
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                audioChunks.push(event.data);
            }
        };
        
        mediaRecorder.onstop = async () => {
            if (audioChunks.length > 0) {
                const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                await sendAudioToServer(audioBlob);
            }
        };
        
        mediaRecorder.start();
        isRecording = true;
        
        console.log('🎤 Recording started');
        
    } catch (error) {
        console.error('Recording error:', error);
    }
}

// Stop Recording
function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    
    try {
        mediaRecorder.stop();
        isRecording = false;
        
        console.log('🎤 Recording stopped');
        
    } catch (error) {
        console.error('Stop recording error:', error);
    }
}

// Send audio to server for processing
async function sendAudioToServer(audioBlob) {
    if (!socket || !continuousMode) return;
    
    // Convert blob to base64
    const reader = new FileReader();
    reader.onloadend = () => {
        const base64Audio = reader.result;
        
        // Prepare data with optional camera frame
        const data = {
            audio: base64Audio,
            include_vision: includeVisionCheck.checked
        };

        // If vision is included, capture frame from client camera
        if (includeVisionCheck.checked && window.cameraCapture && window.cameraCapture.isActive()) {
            const frameBase64 = window.cameraCapture.captureFrame();
            if (frameBase64) {
                data.image = frameBase64;
            }
        }

        // Emit to server via WebSocket
        socket.emit('voice_input', data);
    };
    reader.readAsDataURL(audioBlob);
}

// Speak text using TTS
async function speakText(text) {
    if (isSpeaking) {
        // Queue is handled by waiting for audio to finish
        return;
    }
    
    try {
        isSpeaking = true;
        
        const response = await fetch('/text_to_speech', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (data.success && data.audio) {
            return new Promise((resolve) => {
                const audioSrc = `data:audio/mp3;base64,${data.audio}`;
                ttsAudio.src = audioSrc;
                
                ttsAudio.onended = () => {
                    isSpeaking = false;
                    resolve();
                };
                
                ttsAudio.onerror = () => {
                    isSpeaking = false;
                    resolve();
                };
                
                ttsAudio.play();
            });
        } else {
            isSpeaking = false;
        }
    } catch (error) {
        console.error('TTS error:', error);
        isSpeaking = false;
    }
}

// Add message to conversation
function addMessage(content, isUser = false, timestamp = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user-message' : 'assistant-message'}`;
    
    const iconDiv = document.createElement('div');
    iconDiv.className = 'message-icon';
    iconDiv.innerHTML = isUser ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    // Convert markdown-style formatting to HTML
    let formattedContent = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');
    
    contentDiv.innerHTML = `<p>${formattedContent}</p>`;
    
    if (timestamp) {
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = new Date(timestamp).toLocaleTimeString();
        contentDiv.appendChild(timeDiv);
    }
    
    messageDiv.appendChild(iconDiv);
    messageDiv.appendChild(contentDiv);
    conversationArea.appendChild(messageDiv);
    
    // Scroll to bottom
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

// Update status
function updateStatus(message, duration = 0) {
    statusText.textContent = message;
    if (duration > 0) {
        setTimeout(() => {
            if (continuousMode) {
                statusText.textContent = '🎤 Listening - Speak naturally';
            } else {
                statusText.textContent = 'Ready';
            }
        }, duration);
    }
}

// Toggle continuous mode
function toggleContinuousMode() {
    if (continuousMode) {
        stopContinuousMode();
    } else {
        startContinuousMode();
    }
}

// Export functions for use in other scripts
window.continuousConversation = {
    start: startContinuousMode,
    stop: stopContinuousMode,
    isActive: () => continuousMode,
    toggle: toggleContinuousMode,
    requestPermissions: requestPermissionsProactively
};
