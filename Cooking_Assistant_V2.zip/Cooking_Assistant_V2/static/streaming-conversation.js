/**
 * Streaming Conversation - ChatGPT-Style Real-Time Responses
 * Text appears and voice speaks simultaneously, with interruption capability
 */

// Wrap in IIFE to avoid global conflicts
(function() {
    'use strict';

// Global state (scoped to this module)
let socket = null;
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let conversationActive = false;
let currentAudioStream = null;
let audioContext = null;
let analyser = null;
let isSpeaking = false;
let isProcessing = false;
let canInterrupt = false;

// Audio queue for streaming TTS
let audioQueue = [];
let isPlayingQueue = false;

// Current message being streamed
let currentMessageDiv = null;
let currentMessageText = "";

// Voice Activity Detection config
const VAD_CONFIG = {
    checkInterval: 50,
    volumeThreshold: 0.025,
    silenceDuration: 1800,
    minRecordingTime: 600,
    maxRecordingTime: 30000
};

let vadTimer = null;
let silenceTimer = null;
let recordingStartTime = 0;

// UI Elements
const conversationBtn = document.getElementById('continuousBtn');
const statusText = document.getElementById('statusText');
const conversationArea = document.getElementById('conversationArea');

/**
 * Initialize streaming conversation system
 */
function initializeStreamingConversation() {
    console.log('🎙️ [STREAMING] Initializing streaming conversation system...');
    
    initializeWebSocket();
    
    if (conversationBtn) {
        conversationBtn.addEventListener('click', toggleConversation);
        console.log('✅ [STREAMING] Button handler attached');
    }
    
    // Add interrupt button functionality (press to interrupt)
    document.addEventListener('keydown', (e) => {
        // Press ESC to interrupt
        if (e.key === 'Escape' && canInterrupt) {
            interruptAI();
        }
    });
    
    console.log('✅ [STREAMING] System ready');
}

/**
 * Initialize WebSocket with streaming handlers
 */
function initializeWebSocket() {
    // Check if Socket.IO is loaded
    if (typeof io === 'undefined') {
        console.error('❌ [STREAMING] Socket.IO not loaded yet, retrying...');
        setTimeout(initializeWebSocket, 100);
        return;
    }
        
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;
    
    console.log('🔌 [STREAMING] Connecting to WebSocket:', wsUrl);

    socket = io(wsUrl, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionAttempts: 10
    });
    
    socket.on('connect', () => {
        console.log('✅ [STREAMING] WebSocket connected');
        updateStatus('Connected and ready');
    });
    
    socket.on('disconnect', () => {
        console.log('❌ [STREAMING] Disconnected');
        if (conversationActive) stopConversation();
    });
    
    socket.on('user_message', (data) => {
        console.log('👤 [STREAMING] User:', data.text);
        addUserMessage(data.text);
    });
    
    // STREAMING HANDLERS
    socket.on('streaming_start', () => {
        console.log('📡 [STREAMING] Streaming started');
        startStreamingMessage();
        canInterrupt = true;
    });
    
    socket.on('text_chunk', (data) => {
        console.log('📝 [STREAMING] Text chunk:', data.chunk);
        appendTextChunk(data.chunk);
    });
    
    socket.on('audio_chunk', (data) => {
        console.log('🔊 [STREAMING] Audio chunk:', data.text.substring(0, 30) + '...');
        queueAudioChunk(data.text);
    });
    
    socket.on('streaming_end', (data) => {
        console.log('✅ [STREAMING] Streaming complete');
        finalizeStreamingMessage(data.full_text);
        canInterrupt = false;
    });
    
    socket.on('processing_status', (data) => {
        handleProcessingStatus(data.status);
    });
    
    socket.on('error', (data) => {
        console.error('❌ [STREAMING] Error:', data.message);
        addSystemMessage(`Error: ${data.message}`);
    });
}

/**
 * Toggle conversation
 */
async function toggleConversation() {
    if (conversationActive) {
        stopConversation();
    } else {
        await startConversation();
    }
}

/**
 * Start conversation
 */
async function startConversation() {
    console.log('🚀 [STREAMING] Starting streaming conversation...');
    
    if (conversationActive) return;
    
    try {
        currentAudioStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                sampleRate: 16000
            }
        });
        
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 2048;
        analyser.smoothingTimeConstant = 0.8;
        
        const source = audioContext.createMediaStreamSource(currentAudioStream);
        source.connect(analyser);
        
        conversationActive = true;
        
        conversationBtn.innerHTML = '<i class="fas fa-stop-circle"></i> Stop Conversation';
        conversationBtn.classList.add('recording');
        conversationBtn.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
        
        socket.emit('start_continuous_mode');
        
        const welcomeMsg = "Hi! I'm ready. I can see your camera and I'm listening. Just speak naturally!";
        addAssistantMessage(welcomeMsg);
        speakText(welcomeMsg);
        
        updateStatus('🎤 Listening (vision active)...', 0);
        
        startVoiceActivityDetection();
        
        console.log('✅ [STREAMING] Conversation started');
        
    } catch (error) {
        console.error('❌ [STREAMING] Failed to start:', error);
        alert(`Could not start: ${error.message}`);
    }
}

/**
 * Stop conversation
 */
function stopConversation() {
    console.log('🛑 [STREAMING] Stopping conversation...');
    
    conversationActive = false;
    
    if (vadTimer) clearTimeout(vadTimer);
    if (silenceTimer) clearTimeout(silenceTimer);
    
    if (isRecording) stopRecording();
    
    if (currentAudioStream) {
        currentAudioStream.getTracks().forEach(track => track.stop());
        currentAudioStream = null;
    }
    
    if (audioContext) {
        audioContext.close();
        audioContext = null;
    }
    
    // Stop any playing audio
    stopAllAudio();
    
    conversationBtn.innerHTML = '<i class="fas fa-microphone"></i> Start Conversation';
    conversationBtn.classList.remove('recording');
    conversationBtn.style.background = '';
    
    socket.emit('stop_continuous_mode');
    
    updateStatus('Conversation stopped');
    
    console.log('✅ [STREAMING] Stopped');
}

/**
 * Interrupt AI while speaking
 */
function interruptAI() {
    console.log('⏸️ [STREAMING] Interrupting AI...');
    
    // Stop all audio immediately
    stopAllAudio();
    
    // Clear current streaming message
    if (currentMessageDiv) {
        currentMessageText += " [interrupted]";
        updateMessageContent(currentMessageDiv, currentMessageText);
        currentMessageDiv = null;
    }
    
    canInterrupt = false;
    
    // Show visual feedback
    addSystemMessage("⏸️ Interrupted - You can speak now");
    
    updateStatus('🎤 Listening (vision active)...', 0);
}

/**
 * Stop all audio playback
 */
function stopAllAudio() {
    // Clear audio queue
    audioQueue = [];
    isPlayingQueue = false;
    
    // Stop any currently playing audio
    const audioElements = document.querySelectorAll('audio');
    audioElements.forEach(audio => {
        audio.pause();
        audio.currentTime = 0;
    });
    
    isSpeaking = false;
}

/**
 * Voice Activity Detection
 */
function startVoiceActivityDetection() {
    const checkVoice = () => {
        if (!conversationActive) return;
        
        if (isSpeaking || isProcessing) {
            vadTimer = setTimeout(checkVoice, VAD_CONFIG.checkInterval);
            return;
        }
        
        const volume = getVolumeLevel();
        
        if (volume > VAD_CONFIG.volumeThreshold) {
            if (!isRecording) {
                console.log(`🎤 [STREAMING] Voice detected! Volume: ${volume.toFixed(4)}`);
                
                // If AI is speaking, interrupt it
                if (canInterrupt) {
                    interruptAI();
                }
                
                startRecording();
            }
            
            if (silenceTimer) {
                clearTimeout(silenceTimer);
                silenceTimer = null;
            }
        } else if (isRecording) {
            const duration = Date.now() - recordingStartTime;
            
            if (duration >= VAD_CONFIG.minRecordingTime && !silenceTimer) {
                silenceTimer = setTimeout(() => {
                    stopRecording();
                    silenceTimer = null;
                }, VAD_CONFIG.silenceDuration);
            }
            
            if (duration >= VAD_CONFIG.maxRecordingTime) {
                stopRecording();
            }
        }
        
        vadTimer = setTimeout(checkVoice, VAD_CONFIG.checkInterval);
};

    checkVoice();
}

function getVolumeLevel() {
    if (!analyser) return 0;
    
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);
    
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
        const normalized = dataArray[i] / 255;
        sum += normalized * normalized;
    }
    
    return Math.sqrt(sum / dataArray.length);
}

function startRecording() {
    if (isRecording || !currentAudioStream) return;
    
    try {
        audioChunks = [];
        recordingStartTime = Date.now();
        
        let mimeType = 'audio/webm;codecs=opus';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'audio/webm';
        }
        
        mediaRecorder = new MediaRecorder(currentAudioStream, mimeType ? { mimeType } : {});
        
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = () => {
            if (audioChunks.length > 0) {
                const audioBlob = new Blob(audioChunks, { type: mimeType || 'audio/webm' });
                sendAudioToServer(audioBlob);
            }
        };
        
        mediaRecorder.start();
        isRecording = true;
        
        updateStatus('🔴 Recording...', 0);
        
    } catch (error) {
        console.error('❌ [STREAMING] Recording error:', error);
    }
}

function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    
    mediaRecorder.stop();
    isRecording = false;
    
    if (conversationActive) {
        updateStatus('🎤 Listening (vision active)...', 0);
    }
}

async function sendAudioToServer(audioBlob) {
    if (!socket || !conversationActive) return;
    
    isProcessing = true;
    updateStatus('⚙️ Processing...', 0);
    
    const reader = new FileReader();
    reader.onloadend = async () => {
        const base64Audio = reader.result;
        
        let cameraFrame = null;
        if (window.cameraCapture && window.cameraCapture.isActive()) {
            cameraFrame = window.cameraCapture.captureFrame();
        }
        
        socket.emit('voice_input', {
            audio: base64Audio,
            include_vision: true,
            image: cameraFrame
        });
    };
    
    reader.readAsDataURL(audioBlob);
}

function handleProcessingStatus(status) {
    switch (status) {
        case 'transcribing':
            updateStatus('🎤 Understanding...', 0);
            break;
        case 'thinking':
            updateStatus('🤔 Thinking (with vision)...', 0);
            isProcessing = true;
            break;
        case 'ready':
            if (conversationActive && !isSpeaking) {
                updateStatus('🎤 Listening (vision active)...', 0);
            }
            isProcessing = false;
            break;
    }
}

/**
 * STREAMING MESSAGE HANDLERS
 */

function startStreamingMessage() {
    currentMessageText = "";
    currentMessageDiv = createAssistantMessageDiv();
    conversationArea.appendChild(currentMessageDiv);
    conversationArea.scrollTop = conversationArea.scrollHeight;
    
    updateStatus('💬 AI responding...', 0);
}

function appendTextChunk(chunk) {
    currentMessageText += chunk + " ";
    if (currentMessageDiv) {
        updateMessageContent(currentMessageDiv, currentMessageText);
        conversationArea.scrollTop = conversationArea.scrollHeight;
    }
}

function finalizeStreamingMessage(fullText) {
    if (currentMessageDiv) {
        updateMessageContent(currentMessageDiv, fullText);
        currentMessageDiv = null;
    }
    currentMessageText = "";
}

/**
 * STREAMING AUDIO QUEUE
 */

function queueAudioChunk(text) {
    audioQueue.push(text);
    if (!isPlayingQueue) {
        playNextAudioChunk();
    }
}

async function playNextAudioChunk() {
    if (audioQueue.length === 0) {
        isPlayingQueue = false;
        isSpeaking = false;
        if (conversationActive) {
            updateStatus('🎤 Listening (vision active)...', 0);
        }
        return;
    }
    
    isPlayingQueue = true;
    isSpeaking = true;
    
    const text = audioQueue.shift();
    
    try {
        const response = await fetch('/text_to_speech', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (data.success && data.audio) {
            await playAudio(data.audio);
        }
        
    } catch (error) {
        console.error('❌ [STREAMING] TTS error:', error);
    }
    
    // Play next chunk
    playNextAudioChunk();
}

function playAudio(base64Audio) {
    return new Promise((resolve) => {
        const audio = new Audio(`data:audio/mp3;base64,${base64Audio}`);
        
        audio.onended = () => resolve();
        audio.onerror = () => resolve();
        
        audio.play().catch(() => resolve());
    });
}

function speakText(text) {
    queueAudioChunk(text);
}

/**
 * UI MESSAGE FUNCTIONS
 */

function addUserMessage(text) {
    const div = createMessageDiv('user-message', '<i class="fas fa-user"></i>', text);
    conversationArea.appendChild(div);
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

function addAssistantMessage(text) {
    const div = createMessageDiv('assistant-message', '<i class="fas fa-robot"></i>', text);
    conversationArea.appendChild(div);
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

function addSystemMessage(text) {
    const div = createMessageDiv('assistant-message', '<i class="fas fa-info-circle"></i>', text);
    div.style.borderLeft = '4px solid #f59e0b';
    conversationArea.appendChild(div);
    conversationArea.scrollTop = conversationArea.scrollHeight;
}

function createMessageDiv(className, iconHTML, text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${className}`;
    
    messageDiv.innerHTML = `
        <div class="message-icon">${iconHTML}</div>
        <div class="message-content">
            <p>${formatText(text)}</p>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        </div>
    `;
    
    return messageDiv;
}

function createAssistantMessageDiv() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant-message';
    
    messageDiv.innerHTML = `
        <div class="message-icon"><i class="fas fa-robot"></i></div>
        <div class="message-content">
            <p class="streaming-text"><span class="cursor">▊</span></p>
        </div>
    `;
    
    return messageDiv;
}

function updateMessageContent(messageDiv, text) {
    const contentP = messageDiv.querySelector('.message-content p');
    if (contentP) {
        contentP.innerHTML = formatText(text) + '<span class="cursor">▊</span>';
    }
}

function formatText(text) {
    return text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');
}

function updateStatus(message, duration = 0) {
    if (statusText) {
        statusText.textContent = message;
        
        if (duration > 0) {
            setTimeout(() => {
                if (conversationActive) {
                    statusText.textContent = '🎤 Listening (vision active)...';
                } else {
                    statusText.textContent = 'Ready';
                }
            }, duration);
        }
    }
}

// Add CSS for streaming cursor
const style = document.createElement('style');
style.textContent = `
    .cursor {
        animation: blink 1s infinite;
        color: #10b981;
    }
    @keyframes blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
    }
    .streaming-text {
        color: #1f2937;
    }
`;
document.head.appendChild(style);

// Initialize
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        // Wait a bit for Socket.IO to load
        setTimeout(initializeStreamingConversation, 500);
    });
} else {
    setTimeout(initializeStreamingConversation, 500);
}

// Export public API
window.streamingConversation = {
    start: startConversation,
    stop: stopConversation,
    interrupt: interruptAI,
    isActive: () => conversationActive
};

console.log('✅ [STREAMING] Module loaded');
console.log('💡 [STREAMING] Press ESC to interrupt AI while speaking');

})(); // End IIFE
