#!/usr/bin/env python3
"""
Test script to verify OpenAI API connectivity
"""

import os
from dotenv import load_dotenv
import requests

# Load environment variables
load_dotenv()

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

def test_openai_api():
    """Test OpenAI API connection"""
    print("Testing OpenAI API connection...")
    print("=" * 60)
    
    if not OPENAI_API_KEY:
        print("❌ ERROR: OPENAI_API_KEY not found in environment")
        print("\nPlease set your API key:")
        print("1. Copy .env.example to .env")
        print("2. Edit .env and add your API key")
        print("3. Get API key from: https://platform.openai.com/api-keys")
        return False
    
    if OPENAI_API_KEY == 'your_openai_api_key_here':
        print("❌ ERROR: Please replace the placeholder API key in .env")
        print("Edit .env and add your actual OpenAI API key")
        return False
    
    print(f"✅ API Key found (length: {len(OPENAI_API_KEY)} chars)")
    
    # Test API with a simple request
    print("\nTesting API with simple chat request...")
    
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    data = {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "Say 'API test successful'"}],
        "max_tokens": 20
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            message = result['choices'][0]['message']['content']
            print(f"✅ API Response: {message}")
            print("\n✅ OpenAI API test PASSED!")
            return True
        elif response.status_code == 401:
            print(f"❌ ERROR: Invalid API key (401 Unauthorized)")
            print("Please check your API key is correct")
            return False
        elif response.status_code == 429:
            print(f"❌ ERROR: Rate limit exceeded or no credits (429)")
            print("Check your OpenAI account has available credits")
            return False
        else:
            print(f"❌ ERROR: API returned status {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except requests.exceptions.Timeout:
        print("❌ ERROR: Request timed out")
        print("Check your internet connection")
        return False
    except requests.exceptions.ConnectionError:
        print("❌ ERROR: Could not connect to OpenAI API")
        print("Check your internet connection")
        return False
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        return False

if __name__ == "__main__":
    import sys
    success = test_openai_api()
    sys.exit(0 if success else 1)
