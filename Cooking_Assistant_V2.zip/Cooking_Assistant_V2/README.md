# 🍳 Cooking Assistant for Visually Impaired People

A comprehensive AI-powered cooking assistant designed specifically for visually impaired individuals. This application uses computer vision, speech-to-text (STT), and text-to-speech (TTS) to provide real-time cooking guidance, safety monitoring, and recipe assistance through a Raspberry Pi with webcam.

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0.0-green.svg)
![OpenCV](https://img.shields.io/badge/OpenCV-4.8+-red.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## 🌟 Features

### 🎥 Real-Time Video Analysis
- Live camera feed showing the cooking area
- AI-powered scene analysis using GPT-4 Vision
- Automatic identification of ingredients, utensils, and cooking activities
- Safety hazard detection (hot surfaces, sharp objects, spills)

### 🎤 Voice Interaction (STT)
- Hands-free operation with voice commands
- High-accuracy speech recognition using OpenAI Whisper
- Natural conversation with the AI assistant
- Press-and-hold microphone button for voice input

### 🔊 Audio Responses (TTS)
- Natural-sounding text-to-speech responses
- Automatic reading of AI responses
- Clear, descriptive audio guidance
- Toggle auto-speak on/off

### 🤖 Intelligent Cooking Assistance
- Step-by-step recipe instructions adapted for visual impairment
- Ingredient identification and quantity estimation
- Cooking technique explanations with sensory cues
- Real-time cooking progress monitoring
- Safety checks and warnings
- Timer assistance and doneness checking
- Ingredient substitution suggestions

### 💬 Interactive Chat Interface
- Beautiful, accessible web interface
- Real-time conversation with AI
- Quick action buttons for common tasks
- Conversation history tracking
- Option to include camera vision in responses

## 🔧 Hardware Requirements

- **Raspberry Pi 4** (16GB RAM recommended)
- **USB Webcam** or Raspberry Pi Camera Module
- **Microphone** (USB or built-in)
- **Speakers** or headphones for audio output
- **Internet connection** (for AI API access)

## 📋 Prerequisites

- Python 3.8 or higher
- OpenAI API key (for GPT-4 Vision, Whisper STT, and TTS)
- Raspberry Pi OS (Bullseye or later) or any Linux distribution

## 🚀 Installation

### Step 1: Clone the Repository

```bash
cd ~
git clone <repository-url>
cd cooking-assistant
```

Or if starting from scratch, create the directory structure:

```bash
mkdir -p cooking-assistant/{services,templates,static}
cd cooking-assistant
```

### Step 2: Install System Dependencies

```bash
# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Python and pip
sudo apt-get install python3 python3-pip python3-venv -y

# Install OpenCV dependencies
sudo apt-get install libopencv-dev python3-opencv -y
sudo apt-get install libatlas-base-dev libjasper-dev libqtgui4 libqt4-test -y

# Install audio dependencies
sudo apt-get install portaudio19-dev python3-pyaudio -y
sudo apt-get install alsa-utils pulseaudio -y
```

### Step 3: Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 4: Install Python Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 5: Configure Environment Variables

```bash
# Copy the example environment file
cp .env.example .env

# Edit the .env file and add your OpenAI API key
nano .env
```

Add your OpenAI API key:
```
OPENAI_API_KEY=sk-your-actual-api-key-here
```

Save and exit (Ctrl+X, then Y, then Enter)

### Step 6: Test Camera Access

```bash
# Test if camera is detected
ls /dev/video*

# Should show: /dev/video0 (or similar)
```

## 🎯 Usage

### Starting the Application

```bash
# Activate virtual environment (if not already activated)
source venv/bin/activate

# Run the application
python3 app.py
```

You should see:
```
============================================================
🍳 COOKING ASSISTANT FOR VISUALLY IMPAIRED
============================================================
Starting Flask server...
Access the application at: http://localhost:5000
============================================================
```

### Accessing the Application

1. **On Raspberry Pi**: Open browser and go to `http://localhost:5000`
2. **From another device on same network**: Go to `http://<raspberry-pi-ip>:5000`

To find your Raspberry Pi's IP address:
```bash
hostname -I
```

### Using the Application

#### 🎥 Camera View (Left Panel)
- Shows live camera feed of your cooking area
- Click **"Analyze Scene"** to get AI description of what's visible
- Click **"Capture"** to take a snapshot for reference
- Position camera to show stovetop, ingredients, and workspace

#### 💬 Chat Interface (Right Panel)

**Quick Actions:**
- 📖 **Recipe** - Get step-by-step cooking instructions
- 🥕 **Ingredients** - Identify ingredients in camera view
- ⚠️ **Safety** - Check for safety hazards
- ⏰ **Timer** - Get help with cooking timers

**Text Input:**
- Type your question or request
- Check "Include camera view" to analyze what's visible
- Press Enter or click Send button

**Voice Input:**
- Hold down the microphone button
- Speak your question clearly
- Release button when done
- Your speech will be transcribed and sent automatically

#### 🔊 Audio Responses
- Responses are automatically spoken if "Auto-speak" is enabled
- Toggle auto-speak on/off using the checkbox
- Adjust system volume as needed

## 💡 Example Interactions

### Getting Recipe Help
**User**: "How do I make scrambled eggs?"
**Assistant**: Provides step-by-step instructions with sensory cues

### Safety Check
**User**: *clicks Safety button*
**Assistant**: "I can see the stove is on with a pot on the front burner. There's a knife on the left side of the cutting board. Please be careful reaching across the burner."

### Ingredient Identification
**User**: *clicks Ingredients button*
**Assistant**: "I can see three eggs in the center, a bowl on the right, butter in a small dish on the left, and a whisk near the bowl."

### Checking Doneness
**User**: "Are my eggs done cooking?"
**Assistant**: "The eggs appear golden yellow and fluffy with no liquid remaining. They look properly cooked. You can turn off the heat now."

## 🔐 Security & Privacy

- All video processing happens in real-time (no storage)
- Images are only sent to OpenAI API when you request analysis
- Conversation history stored in memory only (cleared on restart)
- No user data is permanently saved
- Use .env file for secure API key storage

## ⚙️ Configuration

### Camera Settings
Edit `app.py` to adjust camera resolution:
```python
self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
self.video.set(cv2.CAP_PROP_FPS, 30)
```

### TTS Voice
Edit `services/speech_service.py` to change voice:
```python
# Available voices: alloy, echo, fable, onyx, nova, shimmer
voice="alloy"
```

## 🐛 Troubleshooting

### Camera Not Working
```bash
# Check if camera is detected
ls /dev/video*

# Test camera with Python
python3 -c "import cv2; cap = cv2.VideoCapture(0); print('Camera OK' if cap.isOpened() else 'Camera Error')"

# Try different camera index if needed (change 0 to 1, 2, etc.)
```

### Microphone Not Working
```bash
# List audio devices
arecord -l

# Test microphone
arecord -d 5 test.wav
aplay test.wav

# Adjust microphone volume
alsamixer
```

### API Errors
- Verify your OpenAI API key is correct in `.env`
- Check API key has credits available
- Ensure internet connection is stable
- Check OpenAI API status at https://status.openai.com

### Performance Issues
- Reduce camera resolution in `app.py`
- Close other applications
- Ensure adequate cooling for Raspberry Pi
- Consider using Raspberry Pi 4 with 8GB+ RAM

## 🌐 Network Access

### Access from Other Devices
```bash
# Find your IP address
hostname -I

# Application is accessible at: http://<ip-address>:5000
```

### Auto-Start on Boot
Create systemd service:
```bash
sudo nano /etc/systemd/system/cooking-assistant.service
```

Add:
```ini
[Unit]
Description=Cooking Assistant for Visually Impaired
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/cooking-assistant
Environment="PATH=/home/pi/cooking-assistant/venv/bin"
ExecStart=/home/pi/cooking-assistant/venv/bin/python3 app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable cooking-assistant
sudo systemctl start cooking-assistant
```

## 📊 API Usage & Costs

This application uses OpenAI APIs:
- **GPT-4 Vision**: ~$0.01 per image analysis
- **Whisper STT**: ~$0.006 per minute of audio
- **TTS**: ~$0.015 per 1000 characters

Estimated cost for typical cooking session (1 hour):
- 10 scene analyses: ~$0.10
- 20 voice commands: ~$0.02
- 50 TTS responses: ~$0.15
- **Total: ~$0.27 per session**

## 🤝 Contributing

Contributions are welcome! Areas for improvement:
- Additional language support
- Offline mode capabilities
- Recipe database integration
- Nutritional information
- Meal planning features
- Kitchen equipment tutorials

## 📄 License

MIT License - See LICENSE file for details

## 🙏 Acknowledgments

- OpenAI for GPT-4 Vision, Whisper, and TTS APIs
- OpenCV community for computer vision tools
- Flask framework developers
- Accessibility advocates and testers

## 📞 Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Contact: [your-email@example.com]

## 🎯 Roadmap

- [ ] Offline mode with local models
- [ ] Multi-language support
- [ ] Recipe favorites and history
- [ ] Shopping list generation
- [ ] Nutritional tracking
- [ ] Integration with smart kitchen devices
- [ ] Mobile app version
- [ ] Voice-only mode (no screen needed)

---

**Made with ❤️ for the visually impaired community**

*Empowering independence in the kitchen through AI technology*
