# 🎤 Continuous Conversation Mode - User Guide

## Overview

The Cooking Assistant now features **Continuous Conversation Mode** - a revolutionary hands-free experience designed specifically for visually impaired users. This mode allows you to have natural, flowing conversations with the assistant while cooking, without needing to press buttons or interact with the screen.

---

## 🌟 Key Features

### 1. **Completely Hands-Free**
- No need to hold buttons
- No need to touch the screen
- Just speak naturally while cooking

### 2. **Automatic Speech Detection**
- Detects when you start speaking
- Automatically starts listening
- Stops when you finish speaking

### 3. **Real-Time Voice Responses**
- Assistant responds with voice automatically
- Natural conversation flow
- No interruption to your cooking

### 4. **Context-Aware**
- Remembers your conversation
- Understands follow-up questions
- Can reference previous steps

### 5. **Safety-Focused**
- Can analyze scene for hazards while you talk
- Provides warnings with voice
- Always prioritizes your safety

---

## 🚀 How to Use

### Starting Continuous Mode

1. **Open the Cooking Assistant** in your web browser
2. **Click the green button** that says "Start Continuous Conversation"
   - Or press **SPACEBAR** on your keyboard
3. **Listen for the welcome message**: "Hello! I'm your cooking assistant. I'm listening continuously..."
4. **Start speaking naturally!**

### Using Continuous Mode

Once active, simply:
- **Speak your questions or requests**
- **Wait for the assistant to respond with voice**
- **Continue the conversation naturally**
- **No need to press anything!**

### Example Conversation

**You:** "What ingredients do I need for scrambled eggs?"

**Assistant:** "For scrambled eggs, you'll need eggs, butter, milk, salt, and pepper. How many servings would you like to make?"

**You:** "Two servings."

**Assistant:** "Perfect! For two servings, you'll need 4 eggs, 2 tablespoons of butter, 2 tablespoons of milk, and salt and pepper to taste. Would you like step-by-step instructions?"

**You:** "Yes, please."

**Assistant:** "Great! Let's start. First, crack the four eggs into a bowl..."

### Stopping Continuous Mode

When you're done cooking, you can stop in three ways:

1. **Say one of these phrases:**
   - "Stop listening"
   - "Stop conversation"
   - "Goodbye"
   - "That's all"

2. **Click the red button** that says "Stop Listening"

3. **Press SPACEBAR** on your keyboard

---

## 💡 Tips for Best Experience

### Voice Input Tips

1. **Speak clearly** but naturally
2. **Wait for responses** - don't interrupt the assistant
3. **Use simple questions** for better understanding
4. **Pause between sentences** to help detection

### Environment Setup

1. **Reduce background noise** when possible
2. **Position microphone** about 1-2 feet away
3. **Test your setup** before cooking
4. **Keep ventilation fan noise minimal**

### Optimal Usage

1. **Start conversation before cooking** to get instructions
2. **Ask questions as you go** - the assistant remembers context
3. **Request safety checks** frequently while cooking
4. **Use ingredient identification** to verify items

---

## 🎯 Common Use Cases

### 1. Recipe Guidance

**You:** "How do I make pasta carbonara?"

**Assistant:** Provides complete recipe with step-by-step instructions

**You:** "What's the next step?"

**Assistant:** Continues from where you left off

### 2. Ingredient Identification

**You:** "What ingredients do you see on the counter?"

**Assistant:** Analyzes camera and describes each ingredient

**You:** "Which one is the olive oil?"

**Assistant:** "The olive oil is in the bottle on your left"

### 3. Safety Monitoring

**You:** "Check for safety hazards"

**Assistant:** Analyzes scene and warns about hot surfaces, sharp objects, etc.

**You:** "Is it safe to reach for the pot?"

**Assistant:** Provides specific guidance on safety

### 4. Cooking Progress

**You:** "Are the eggs cooked?"

**Assistant:** Analyzes eggs and provides doneness feedback

**You:** "How much longer?"

**Assistant:** Estimates time based on visual appearance

### 5. Measurements & Quantities

**You:** "How much flour do I need?"

**Assistant:** Provides measurement

**You:** "How can I measure it without seeing?"

**Assistant:** Provides tactile measurement techniques

---

## 🔧 Technical Details

### How It Works

1. **Voice Activity Detection (VAD)**
   - Constantly monitors audio levels
   - Detects when you start speaking
   - Automatically starts recording

2. **Speech-to-Text (STT)**
   - Converts your speech to text using OpenAI Whisper
   - High accuracy, understands various accents
   - Works with natural speech patterns

3. **AI Processing**
   - Sends your text to GPT-4 for understanding
   - Can include camera vision if needed
   - Maintains conversation context

4. **Text-to-Speech (TTS)**
   - Converts response to natural voice
   - Plays automatically
   - Clear, easy-to-understand audio

5. **Real-Time Communication**
   - Uses WebSocket for instant responses
   - No page refreshes needed
   - Seamless conversation flow

### System Requirements

- **Modern web browser** (Chrome, Firefox, Edge, Safari)
- **Microphone access** enabled
- **Stable internet connection** (for AI processing)
- **Speakers or headphones** for audio output

---

## ⚙️ Configuration Options

### Enable/Disable Camera Vision

Check or uncheck **"Include camera view in message"**
- ✅ Checked: Assistant can see what you're cooking
- ☐ Unchecked: Voice-only conversation (faster)

### When to Use Camera Vision

**Enable for:**
- Identifying ingredients
- Safety checks
- Checking if food is done
- Verifying recipe steps

**Disable for:**
- General cooking questions
- Recipe instructions
- Timing questions
- Ingredient substitutions

---

## 🐛 Troubleshooting

### Assistant Isn't Hearing Me

**Solutions:**
1. Check microphone permissions in browser
2. Increase microphone volume in system settings
3. Reduce background noise
4. Speak louder or move closer to microphone
5. Test microphone with another application

### Assistant Stops Listening Too Soon

**Solutions:**
1. Speak with shorter pauses
2. Adjust silence detection (in .env: increase SILENCE_DURATION)
3. Speak continuously without long pauses

### Assistant Keeps Listening When I'm Done

**Solutions:**
1. Say "stop listening" clearly
2. Click the stop button
3. Be silent for a few seconds to let it auto-stop

### Responses Are Slow

**Solutions:**
1. Check internet connection speed
2. Disable camera vision if not needed
3. Use shorter questions
4. Check API status at https://status.openai.com

### Voice Output Not Working

**Solutions:**
1. Check speaker/headphone connections
2. Increase system volume
3. Check browser audio permissions
4. Try refreshing the page

### Poor Recognition Accuracy

**Solutions:**
1. Reduce background noise (fans, music)
2. Speak more clearly
3. Use simpler language
4. Test with manual voice button first

---

## 🔐 Privacy & Security

### What's Recorded

- **Voice input** is sent to OpenAI Whisper for transcription
- **Camera images** are only sent when you request vision analysis
- **Conversation text** is sent to GPT-4 for responses
- **Audio responses** are generated by OpenAI TTS

### What's NOT Stored

- ✅ No voice recordings saved permanently
- ✅ No camera images stored
- ✅ Conversation history cleared on restart
- ✅ No personal data collected

### Security Best Practices

1. Use the application on a **trusted network**
2. **Close the browser** when done cooking
3. **Don't share sensitive information** in conversations
4. Keep your **OpenAI API key secure**

---

## 📊 Cost Considerations

### API Usage Per Session

**Typical 30-minute cooking session:**
- 20 voice inputs: ~$0.10 (Whisper STT)
- 20 AI responses: ~$0.15 (GPT-4)
- 20 voice outputs: ~$0.10 (TTS)
- 5 vision analyses: ~$0.05 (GPT-4 Vision)

**Total: ~$0.40 per session**

### Cost Reduction Tips

1. Use `gpt-4o-mini` instead of `gpt-4o` (10x cheaper)
2. Disable camera vision when not needed
3. Ask combined questions instead of multiple small ones
4. Use text input for non-urgent questions

---

## 🎓 Best Practices

### For New Users

1. **Start with simple recipes** you know
2. **Test in non-cooking situations** first
3. **Practice starting/stopping** the mode
4. **Learn voice commands** that work well
5. **Build confidence gradually**

### For Experienced Users

1. **Chain multiple questions** for efficiency
2. **Use vision selectively** for important checks
3. **Develop your own phrases** that work best
4. **Combine with quick action buttons** for speed
5. **Set up shortcuts** for frequently used recipes

### For Caregivers

1. **Test the system** with the user
2. **Help position camera** optimally
3. **Adjust microphone placement** for best results
4. **Create emergency stop procedure**
5. **Monitor initial sessions** for safety

---

## 🆘 Emergency Procedures

### If You Need to Stop Immediately

1. **Say "stop listening" firmly**
2. **Press SPACEBAR** multiple times
3. **Click anywhere** on the stop button area
4. **Close the browser** if unresponsive

### If Assistant Gives Incorrect Information

1. **Stop and verify** before proceeding
2. **Ask for clarification** if unsure
3. **Use manual vision check** for confirmation
4. **Trust your instincts** and other senses

### Kitchen Safety Priority

**The assistant provides guidance, but YOU are responsible for:**
- Turning off stoves and appliances
- Handling hot items safely
- Using sharp objects carefully
- Monitoring cooking progress
- Responding to emergencies

---

## 📞 Support & Feedback

### Getting Help

1. Check this guide first
2. Review README.md for setup issues
3. Test individual components (camera, microphone)
4. Check API status and credits
5. Contact support if issues persist

### Providing Feedback

We want to improve! Let us know:
- What works well
- What's confusing
- Features you'd like
- Accessibility improvements needed
- Safety concerns

---

## 🔄 Updates & Improvements

### Recent Enhancements

- ✅ Continuous conversation mode
- ✅ Voice activity detection
- ✅ Automatic silence detection
- ✅ Real-time WebSocket communication
- ✅ Context-aware responses

### Coming Soon

- 🔜 Wake word detection ("Hey Assistant")
- 🔜 Multi-language support
- 🔜 Offline mode with local models
- 🔜 Custom voice selection
- 🔜 Recipe favorites and history

---

## ✅ Quick Reference Card

**Print this section for easy reference:**

```
=======================================================
🎤 COOKING ASSISTANT - CONTINUOUS MODE QUICK GUIDE
=======================================================

START:
  Click green button OR press SPACEBAR

USE:
  Just speak naturally!
  Wait for voice responses
  No buttons needed!

STOP:
  Say "stop listening"
  OR click red button
  OR press SPACEBAR

TIPS:
  ✓ Speak clearly
  ✓ Reduce background noise
  ✓ Ask for safety checks often
  ✓ Trust your other senses

EMERGENCY:
  Say "stop listening" immediately
  Close browser if needed

SUPPORT:
  Check CONTINUOUS_CONVERSATION_GUIDE.md
  Review troubleshooting section
=======================================================
```

---

**Enjoy hands-free cooking with your AI assistant!** 🍳

*Empowering independence in the kitchen through continuous conversation technology.*
