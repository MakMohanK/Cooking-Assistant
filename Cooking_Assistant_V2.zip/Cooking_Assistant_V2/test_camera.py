#!/usr/bin/env python3
"""
Test script to verify camera functionality
"""

import cv2
import sys

def test_camera(camera_index=0):
    """Test camera capture"""
    print(f"Testing camera at index {camera_index}...")
    
    cap = cv2.VideoCapture(camera_index)
    
    if not cap.isOpened():
        print(f"❌ ERROR: Could not open camera at index {camera_index}")
        print("\nTroubleshooting:")
        print("1. Check if camera is connected: ls /dev/video*")
        print("2. Try different camera index: python3 test_camera.py 1")
        print("3. Check camera permissions")
        return False
    
    # Get camera properties
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    fps = cap.get(cv2.CAP_PROP_FPS)
    
    print(f"✅ Camera opened successfully!")
    print(f"   Resolution: {int(width)}x{int(height)}")
    print(f"   FPS: {int(fps)}")
    
    # Try to capture a frame
    ret, frame = cap.read()
    
    if ret:
        print(f"✅ Frame captured successfully!")
        print(f"   Frame shape: {frame.shape}")
        
        # Save test image
        cv2.imwrite('test_frame.jpg', frame)
        print(f"✅ Test image saved as 'test_frame.jpg'")
    else:
        print(f"❌ ERROR: Could not capture frame")
        return False
    
    cap.release()
    print("\n✅ Camera test PASSED!")
    return True

if __name__ == "__main__":
    camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    success = test_camera(camera_index)
    sys.exit(0 if success else 1)
