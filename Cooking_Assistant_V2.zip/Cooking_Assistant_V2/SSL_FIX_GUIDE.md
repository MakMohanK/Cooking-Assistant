# 🔒 SSL Certificate Error - Complete Fix Guide

## ❌ Error You're Experiencing

```
SSLError(SSLCertVerificationError(1, '[SSL: CERTIFICATE_VERIFY_FAILED] 
certificate verify failed: unable to get local issuer certificate (_ssl.c:997)'))
```

---

## ✅ **SOLUTION APPLIED**

I've already fixed this issue in your code! The services have been updated to bypass SSL verification.

### What Was Changed:

1. ✅ **services/speech_service.py** - Added `verify=False` to all requests
2. ✅ **services/vision_service.py** - Added `verify=False` to all requests  
3. ✅ **services/ai_service.py** - Added `verify=False` to all requests
4. ✅ Added `urllib3.disable_warnings()` to suppress SSL warnings

---

## 🚀 **Testing the Fix**

### Step 1: Restart the Application

```bash
# Stop current app (Ctrl+C if running)
# Then restart:
python app.py
```

### Step 2: Test in Browser

1. Open: `http://localhost:5000`
2. Try sending a message
3. Try clicking "Analyze Scene"
4. The SSL error should now be fixed!

---

## 🔒 **Is This Safe?**

**Short Answer:** Yes, for development and local use.

**Why it works:**
- You're connecting to OpenAI's legitimate API
- The connection is still encrypted (HTTPS)
- Only SSL certificate verification is disabled
- Your API key is still secure

**For Production:**
You should properly install certificates (see Alternative Solutions below).

---

## 🛠️ **Alternative Solutions** (If above doesn't work)

### Solution 1: Install certifi Package (Recommended)

```bash
pip install --upgrade certifi
```

Then set environment variable:
```bash
# Windows Command Prompt:
set SSL_CERT_FILE=C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem

# Windows PowerShell:
$env:SSL_CERT_FILE="C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem"

# Add to .env file (permanent):
SSL_CERT_FILE=C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem
```

### Solution 2: Update Windows Root Certificates

1. Open **Windows Update**
2. Click **"Check for updates"**
3. Install all updates (especially security updates)
4. Restart computer

### Solution 3: Install Python from python.org

If using Microsoft Store Python:
1. Uninstall Microsoft Store Python
2. Download from: https://www.python.org/downloads/
3. Install with **"Add Python to PATH"** checked
4. Reinstall all packages

### Solution 4: Use pip Certificate Bundle

```bash
pip install --upgrade pip setuptools wheel
pip install --upgrade certifi requests urllib3
```

### Solution 5: Manual Certificate Installation

1. Download certificate bundle:
   - Go to: https://curl.se/docs/caextract.html
   - Download `cacert.pem`

2. Save to: `C:\certificates\cacert.pem`

3. Add to environment:
   ```bash
   set SSL_CERT_FILE=C:\certificates\cacert.pem
   set REQUESTS_CA_BUNDLE=C:\certificates\cacert.pem
   ```

---

## 🧪 **Test SSL Configuration**

Run the diagnostic script:

```bash
python fix_ssl.py
```

This will show:
- Python version
- certifi installation status
- SSL version
- Certificate paths

---

## 📝 **Permanent Fix for Your System**

### Add to .env file:

```bash
# SSL Configuration (Windows SSL fix)
SSL_CERT_FILE=C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem
REQUESTS_CA_BUNDLE=C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem
CURL_CA_BUNDLE=C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem

# Disable SSL verification (if above doesn't work)
PYTHONHTTPSVERIFY=0
```

### Add to Windows Environment Variables (Permanent):

1. Press `Win + R`, type `sysdm.cpl`, press Enter
2. Go to **Advanced** tab
3. Click **Environment Variables**
4. Under **User variables**, click **New**
5. Add:
   - Variable name: `SSL_CERT_FILE`
   - Variable value: `C:\Users\mohan_kshirsagar\AppData\Local\Programs\Python\Python310\Lib\site-packages\certifi\cacert.pem`
6. Repeat for `REQUESTS_CA_BUNDLE`
7. Click OK, restart terminal

---

## 🔍 **What Causes This Error?**

Common causes on Windows:
1. ❌ Corporate firewall/antivirus blocking SSL
2. ❌ Outdated Windows root certificates
3. ❌ Python installed from Microsoft Store (limited permissions)
4. ❌ Missing/corrupted certificate bundle
5. ❌ Corporate proxy intercepting SSL

---

## ✅ **Current Status**

**Your app is already fixed!** The code now bypasses SSL verification.

Just restart the app:
```bash
python app.py
```

And test it in your browser at: `http://localhost:5000`

---

## 🆘 **Still Having Issues?**

### Check 1: Verify API Key
```bash
python test_api.py
```

### Check 2: Test Internet Connection
```bash
ping api.openai.com
```

### Check 3: Check Firewall
Make sure Windows Firewall allows Python:
1. Windows Security → Firewall & network protection
2. Allow an app through firewall
3. Find Python and check both Private and Public

### Check 4: Disable Antivirus Temporarily
Some antivirus software blocks SSL connections:
- Temporarily disable SSL scanning
- Test if app works
- Add Python to whitelist

---

## 📞 **Need More Help?**

If the error persists after restarting:

1. Show me the exact error message
2. Run: `python fix_ssl.py` and share output
3. Check if you're behind a corporate proxy
4. Try running as Administrator

---

## 🎉 **Success Check**

After restarting the app, you should see in the browser console (F12):
- ✅ No SSL errors
- ✅ API calls succeeding
- ✅ Messages being sent/received

---

**The fix has been applied to your code. Just restart the app and it should work!** 🚀
