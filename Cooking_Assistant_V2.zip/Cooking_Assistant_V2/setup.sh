#!/bin/bash

# Cooking Assistant for Visually Impaired - Setup Script for Raspberry Pi
# This script automates the installation process

echo "============================================================"
echo "🍳 Cooking Assistant Setup for Raspberry Pi"
echo "============================================================"
echo ""

# Check if running on Raspberry Pi
if [ ! -f /proc/device-tree/model ] || ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
    echo "⚠️  Warning: This doesn't appear to be a Raspberry Pi"
    echo "The script will continue, but some features may not work correctly."
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update system
echo "📦 Updating system packages..."
sudo apt-get update
sudo apt-get upgrade -y

# Install Python and pip
echo "🐍 Installing Python dependencies..."
sudo apt-get install python3 python3-pip python3-venv -y

# Install OpenCV dependencies
echo "📷 Installing OpenCV dependencies..."
sudo apt-get install libopencv-dev python3-opencv -y
sudo apt-get install libatlas-base-dev libjasper-dev libqtgui4 libqt4-test -y

# Install audio dependencies
echo "🔊 Installing audio dependencies..."
sudo apt-get install portaudio19-dev python3-pyaudio -y
sudo apt-get install alsa-utils pulseaudio -y

# Install video4linux for camera
echo "📹 Installing camera support..."
sudo apt-get install v4l-utils -y

# Create virtual environment
echo "🔧 Creating Python virtual environment..."
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "⬆️  Upgrading pip..."
pip install --upgrade pip

# Install Python packages
echo "📚 Installing Python packages..."
pip install -r requirements.txt

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo ""
    echo "⚠️  IMPORTANT: You need to add your OpenAI API key to the .env file"
    echo "Edit .env and add your API key:"
    echo "  nano .env"
    echo ""
fi

# Test camera
echo "📷 Testing camera..."
if ls /dev/video* 1> /dev/null 2>&1; then
    echo "✅ Camera device detected: $(ls /dev/video*)"
else
    echo "❌ No camera detected. Please connect a camera and try again."
fi

# Test microphone
echo "🎤 Testing microphone..."
if arecord -l | grep -q "card"; then
    echo "✅ Microphone detected"
else
    echo "⚠️  No microphone detected. Voice input may not work."
fi

echo ""
echo "============================================================"
echo "✅ Setup Complete!"
echo "============================================================"
echo ""
echo "Next steps:"
echo "1. Add your OpenAI API key to .env file:"
echo "   nano .env"
echo ""
echo "2. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "3. Start the application:"
echo "   python3 app.py"
echo ""
echo "4. Access the application at:"
echo "   http://localhost:5000"
echo ""
echo "5. Or from another device on your network:"
echo "   http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "For more information, see README.md"
echo "============================================================"
